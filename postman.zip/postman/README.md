# Postman Collection for Envoy Gateway Agent API

This folder contains Postman collection and environment files for testing the Envoy Gateway Agent API.

## Files

| File | Description |
|------|-------------|
| `envoy-agent-api.postman_collection.json` | Complete API collection with all endpoints |
| `envoy-agent-local.postman_environment.json` | Environment for local development |
| `envoy-agent-dev.postman_environment.json` | Environment for Fargate deployment |
| `TESTING_GUIDE.md` | **Comprehensive testing scenarios and workflows** |

## Testing Guide

See **[TESTING_GUIDE.md](./TESTING_GUIDE.md)** for complete step-by-step testing scenarios:

| Scenario | Description |
|----------|-------------|
| Scenario 1 | Basic HTTP Route with Backend |
| Scenario 2 | HTTP Route with Rate Limiting |
| Scenario 3 | Secure API with JWT Authentication |
| Scenario 4 | API with CORS and Multiple Policies |
| Scenario 5 | External Service with TLS Backend |
| Scenario 6 | gRPC Service Setup |
| Scenario 7 | IP-Based Access Control |
| Scenario 8 | API Key Authentication |
| Scenario 9 | OpenAPI Import Workflow |
| Scenario 10 | Complete Production Setup |
| Scenario 11 | API Management — Create, Update, Delete APIs with policies |

## Import Instructions

### Using Postman Desktop App

1. Open Postman
2. Click **Import** button (top left)
3. Drag and drop all `.json` files, or click **Upload Files**
4. Select the collection and environment files
5. Click **Import**

### Using Postman Web

1. Go to [Postman Web](https://web.postman.co/)
2. Click **Import** in your workspace
3. Upload the collection and environment files

## Configuration

### Variables

The collection uses these variables:

| Variable | Description | Default |
|----------|-------------|---------|
| `baseUrl` | API base URL | `http://localhost:9080` |
| `targetGateway` | Target gateway identifier | `us-envoy-1` |

### Switching Environments

1. Click the environment dropdown (top right)
2. Select the appropriate environment:
   - **Envoy Agent - Local**: For local development
   - **Envoy Agent - Dev (Fargate)**: For Fargate deployment

## Collection Structure

```
Envoy Gateway Agent API
├── Health & Info
│   ├── Health Check
│   ├── API Information
│   └── AWS Identity
├── Gateways
│   ├── List Available Gateways
│   └── Get Gateway Details
├── Routes
│   ├── HTTP Routes
│   │   ├── Create HTTPRoute
│   │   ├── List HTTPRoutes
│   │   ├── Get HTTPRoute
│   │   ├── Update HTTPRoute
│   │   └── Delete HTTPRoute
│   ├── gRPC Routes
│   ├── TLS Routes
│   ├── TCP Routes
│   └── UDP Routes
├── Backends
│   ├── Services
│   └── Backend CRD
├── Policies
│   ├── Backend Traffic Policy
│   │   ├── Rate Limit
│   │   ├── Circuit Breaker
│   │   └── Retry
│   ├── Security Policy
│   │   ├── JWT
│   │   ├── CORS
│   │   ├── API Key
│   │   ├── Basic Auth
│   │   ├── IP Allowlist
│   │   ├── IP Blocklist
│   │   └── External Auth
│   ├── Client Traffic Policy
│   │   ├── TLS
│   │   └── Timeout
│   ├── Envoy Extension Policy
│   │   ├── WASM
│   │   └── External Processor
│   ├── Envoy Patch Policy
│   └── Logging
│       ├── Access Log
│       └── OTLP
├── Secrets
│   ├── Generic Secret
│   ├── TLS Secret
│   ├── Basic Auth Secret
│   ├── OIDC Secret
│   └── API Key Secret
├── OpenAPI Import
│   ├── Import from JSON Spec
│   ├── Import from URL
│   ├── List Imported Routes
│   └── Delete Imported Routes
└── API Management
    ├── Create API — Basic (no policies)
    ├── Create API — All 10 Policies
    ├── List APIs
    ├── List APIs by Path
    ├── Get API
    ├── Update API — All Policies
    ├── Update API — Few Policies
    ├── Update API — Remove All Policies
    └── Delete API
```

## Quick Start

### 1. Check API Health

```
GET /health
```

### 2. List Available Gateways

```
GET /api/v1/gateways
```

### 3. Create an HTTPRoute

```
POST /api/v1/routes/http
{
  "name": "my-api",
  "targetGateway": "us-envoy-1",
  "path": "/api/v1/users",
  "backendName": "users-service",
  "backendPort": 9080
}
```

### 4. Apply Rate Limiting

```
POST /api/v1/policies/backend-traffic/rate-limit?targetGateway=us-envoy-1
{
  "name": "rate-limit",
  "targetRoute": "my-api",
  "requests": 100,
  "unit": "Minute"
}
```

## Tips

1. **Use Variables**: The collection uses `{{baseUrl}}` and `{{targetGateway}}` variables. Set these in your environment.

2. **Check Required Parameters**: Most endpoints require `targetGateway` as a query parameter.

3. **Dry Run**: Use `dryRun: true` in OpenAPI import to preview routes without creating them.

4. **Create Backend First**: HTTPRoutes require an existing backend service. Use `/backends/services/external` or `/backends/fqdn` to create backends before creating routes.

## Troubleshooting

### Connection Refused
- Verify the API is running
- Check the `baseUrl` in your environment

### 400 Bad Request - Unknown Gateway
- Verify `targetGateway` value exists
- Check available gateways: `GET /api/v1/gateways`

### 401/403 Errors
- Check AWS credentials
- Verify IAM role has EKS permissions
