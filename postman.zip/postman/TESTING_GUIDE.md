# Envoy Gateway Agent API - Testing Guide

This guide provides step-by-step testing scenarios using Postman for the Envoy Gateway Agent API.

---

## Table of Contents

1. [Prerequisites](#prerequisites)
2. [Scenario 1: Basic HTTP Route with Backend](#scenario-1-basic-http-route-with-backend)
3. [Scenario 2: HTTP Route with Rate Limiting](#scenario-2-http-route-with-rate-limiting)
4. [Scenario 3: Secure API with JWT Authentication](#scenario-3-secure-api-with-jwt-authentication)
5. [Scenario 4: API with CORS and Multiple Policies](#scenario-4-api-with-cors-and-multiple-policies)
6. [Scenario 5: External Service with TLS Backend](#scenario-5-external-service-with-tls-backend)
7. [Scenario 6: gRPC Service Setup](#scenario-6-grpc-service-setup)
8. [Scenario 7: IP-Based Access Control](#scenario-7-ip-based-access-control)
9. [Scenario 8: API Key Authentication](#scenario-8-api-key-authentication)
10. [Scenario 9: OpenAPI Import Workflow](#scenario-9-openapi-import-workflow)
11. [Scenario 10: Complete Production Setup](#scenario-10-complete-production-setup)
12. [Cleanup Procedures](#cleanup-procedures)

---

## Prerequisites

### 1. Import Collection and Environment

1. Import `envoy-agent-api.postman_collection.json`
2. Import `envoy-agent-local.postman_environment.json` or `envoy-agent-dev.postman_environment.json`
3. Select the appropriate environment

### 2. Verify API is Running

**Request:** `GET {{baseUrl}}/health`

**Expected Response:**
```json
{
  "status": "healthy",
  "version": "1.0.0",
  "kubernetes_connected": true,
  "cluster_name": "envoy-eks-cluster",
  "timestamp": "2026-02-06T12:00:00Z"
}
```

### 3. List Available Gateways

**Request:** `GET {{baseUrl}}/api/v1/gateways`

**Expected Response:**
```json
{
  "gateways": [
    {
      "name": "us-envoy-1",
      "region": "us-east-1",
      "cluster": "envoy-eks-cluster",
      "namespace": "envoy-test",
      "gatewayName": "envoy-gateway"
    },
    {
      "name": "eu-envoy-1",
      "region": "eu-central-1",
      "cluster": "envoy-eks-cluster",
      "namespace": "envoy-test",
      "gatewayName": "envoy-gateway"
    }
  ],
  "total": 2
}
```

---

## Scenario 1: Basic HTTP Route with Backend

**Objective:** Create a simple HTTP route that proxies requests to a backend service.

### Step 1.1: Create ExternalName Service Backend

**Request:** `POST {{baseUrl}}/api/v1/backends/services/external?targetGateway=us-envoy-1`

**Body:**
```json
{
  "name": "users-api-backend",
  "url": "https://jsonplaceholder.typicode.com",
  "port": 443
}
```

### Step 1.2: Create HTTP Route

**Request:** `POST {{baseUrl}}/api/v1/routes/http`

**Body:**
```json
{
  "name": "users-api",
  "targetGateway": "us-envoy-1",
  "path": "/api/v1/users",
  "backendName": "users-api-backend",
  "backendPort": 443,
  "hostnames": ["api.example.com"],
  "timeout": "30s"
}
```

**Expected Response (201 Created):**
```json
{
  "status": "created",
  "message": "HTTPRoute 'users-api' created successfully",
  "resource_name": "users-api",
  "namespace": "envoy-test",
  "resource_type": "HTTPRoute",
  "details": {
    "backend": "users-api-backend",
    "targetGateway": "us-envoy-1"
  }
}
```

### Step 1.3: Verify Route Created

**Request:** `GET {{baseUrl}}/api/v1/routes/http/users-api?targetGateway=us-envoy-1`

**Expected Response (200 OK):**
```json
{
  "apiVersion": "gateway.networking.k8s.io/v1",
  "kind": "HTTPRoute",
  "metadata": {
    "name": "users-api",
    "namespace": "envoy-test",
    "labels": {
      "envoy-agent.io/target-gateway": "us-envoy-1",
      "envoy-agent.io/backend": "users-api-backend"
    }
  },
  "spec": {
    "parentRefs": [{"name": "envoy-gateway"}],
    "hostnames": ["api.example.com"],
    "rules": [...]
  }
}
```

### Step 1.4: List All HTTP Routes

**Request:** `GET {{baseUrl}}/api/v1/routes/http?targetGateway=us-envoy-1`

**Expected Response:**
```json
{
  "items": [...],
  "total": 1,
  "target_gateway": "us-envoy-1",
  "namespace": "envoy-test"
}
```

### Step 1.5: Cleanup

**Request:** `DELETE {{baseUrl}}/api/v1/routes/http/users-api?targetGateway=us-envoy-1`
**Request:** `DELETE {{baseUrl}}/api/v1/backends/services/users-api-backend?targetGateway=us-envoy-1`

---

## Scenario 2: HTTP Route with Rate Limiting

**Objective:** Create an API with rate limiting to prevent abuse.

### Step 2.1: Create Backend Service

**Request:** `POST {{baseUrl}}/api/v1/backends/services/external?targetGateway=us-envoy-1`

**Body:**
```json
{
  "name": "public-api-backend",
  "url": "https://httpbin.org",
  "port": 443
}
```

### Step 2.2: Create the HTTP Route

**Request:** `POST {{baseUrl}}/api/v1/routes/http`

**Body:**
```json
{
  "name": "public-api",
  "targetGateway": "us-envoy-1",
  "path": "/api/public",
  "backendName": "public-api-backend",
  "backendPort": 443
}
```

### Step 2.3: Apply Rate Limit Policy

**Request:** `POST {{baseUrl}}/api/v1/policies/backend-traffic/rate-limit?targetGateway=us-envoy-1`

**Body:**
```json
{
  "name": "public-api-rate-limit",
  "targetRoute": "public-api",
  "requests": 100,
  "unit": "Minute"
}
```

**Expected Response (201 Created):**
```json
{
  "status": "created",
  "message": "Rate limit policy 'public-api-rate-limit' created",
  "resource_name": "public-api-rate-limit",
  "namespace": "envoy-test",
  "resource_type": "BackendTrafficPolicy",
  "details": {
    "requests": 100,
    "unit": "Minute",
    "targetGateway": "us-envoy-1"
  }
}
```

### Step 2.4: Verify Policy Applied

**Request:** `GET {{baseUrl}}/api/v1/policies/backend-traffic/public-api-rate-limit?targetGateway=us-envoy-1`

### Step 2.5: Cleanup

```
DELETE /api/v1/policies/backend-traffic/public-api-rate-limit?targetGateway=us-envoy-1
DELETE /api/v1/routes/http/public-api?targetGateway=us-envoy-1
DELETE /api/v1/backends/services/public-api-backend?targetGateway=us-envoy-1
```

---

## Scenario 3: Secure API with JWT Authentication

**Objective:** Protect an API endpoint with JWT token validation.

### Step 3.1: Create Backend Service

**Request:** `POST {{baseUrl}}/api/v1/backends/services/external?targetGateway=us-envoy-1`

**Body:**
```json
{
  "name": "secure-api-backend",
  "url": "https://httpbin.org",
  "port": 443
}
```

### Step 3.2: Create the HTTP Route

**Request:** `POST {{baseUrl}}/api/v1/routes/http`

**Body:**
```json
{
  "name": "secure-api",
  "targetGateway": "us-envoy-1",
  "path": "/api/secure",
  "backendName": "secure-api-backend",
  "backendPort": 443
}
```

### Step 3.3: Create JWT Security Policy

**Request:** `POST {{baseUrl}}/api/v1/policies/security/jwt?targetGateway=us-envoy-1`

**Body:**
```json
{
  "name": "jwt-auth-policy",
  "targetRoute": "secure-api",
  "issuer": "https://auth.example.com",
  "jwksUri": "https://auth.example.com/.well-known/jwks.json",
  "audiences": ["api.example.com"],
  "claimToHeaders": {
    "sub": "x-user-id",
    "email": "x-user-email",
    "roles": "x-user-roles"
  }
}
```

**Expected Response (201 Created):**
```json
{
  "status": "created",
  "message": "JWT policy 'jwt-auth-policy' created",
  "resource_name": "jwt-auth-policy",
  "namespace": "envoy-test",
  "resource_type": "SecurityPolicy",
  "details": {
    "targetGateway": "us-envoy-1"
  }
}
```

### Step 3.4: List Security Policies

**Request:** `GET {{baseUrl}}/api/v1/policies/security?targetGateway=us-envoy-1`

### Step 3.5: Cleanup

```
DELETE /api/v1/policies/security/jwt-auth-policy?targetGateway=us-envoy-1
DELETE /api/v1/routes/http/secure-api?targetGateway=us-envoy-1
DELETE /api/v1/backends/services/secure-api-backend?targetGateway=us-envoy-1
```

---

## Scenario 4: API with CORS and Multiple Policies

**Objective:** Create a frontend-facing API with CORS, rate limiting, and retry policies.

### Step 4.1: Create Backend Service

**Request:** `POST {{baseUrl}}/api/v1/backends/services/external?targetGateway=us-envoy-1`

**Body:**
```json
{
  "name": "frontend-api-backend",
  "url": "https://api.backend.internal",
  "port": 443
}
```

### Step 4.2: Create the HTTP Route

**Request:** `POST {{baseUrl}}/api/v1/routes/http`

**Body:**
```json
{
  "name": "frontend-api",
  "targetGateway": "us-envoy-1",
  "path": "/api/frontend",
  "backendName": "frontend-api-backend",
  "backendPort": 443,
  "hostnames": ["api.myapp.com"]
}
```

### Step 4.3: Apply CORS Policy

**Request:** `POST {{baseUrl}}/api/v1/policies/security/cors?targetGateway=us-envoy-1`

**Body:**
```json
{
  "name": "frontend-cors",
  "targetRoute": "frontend-api",
  "allowedOrigins": [
    "https://myapp.com",
    "https://admin.myapp.com",
    "http://localhost:3000"
  ],
  "allowedMethods": ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
  "allowedHeaders": ["Authorization", "Content-Type", "X-Request-ID"],
  "exposeHeaders": ["X-Request-ID", "X-RateLimit-Remaining"],
  "allowCredentials": true,
  "maxAge": "86400s"
}
```

### Step 4.4: Apply Rate Limit Policy

**Request:** `POST {{baseUrl}}/api/v1/policies/backend-traffic/rate-limit?targetGateway=us-envoy-1`

**Body:**
```json
{
  "name": "frontend-rate-limit",
  "targetRoute": "frontend-api",
  "requests": 1000,
  "unit": "Hour"
}
```

### Step 4.5: Apply Retry Policy

**Request:** `POST {{baseUrl}}/api/v1/policies/backend-traffic/retry?targetGateway=us-envoy-1`

**Body:**
```json
{
  "name": "frontend-retry",
  "targetRoute": "frontend-api",
  "numRetries": 3,
  "perRetryTimeout": "5s",
  "retryOn5xx": true,
  "retryOnConnectFailure": true
}
```

### Step 4.6: Verify All Policies

**Request:** `GET {{baseUrl}}/api/v1/policies/security?targetGateway=us-envoy-1`
**Request:** `GET {{baseUrl}}/api/v1/policies/backend-traffic?targetGateway=us-envoy-1`

### Step 4.7: Cleanup

```
DELETE /api/v1/policies/security/frontend-cors?targetGateway=us-envoy-1
DELETE /api/v1/policies/backend-traffic/frontend-rate-limit?targetGateway=us-envoy-1
DELETE /api/v1/policies/backend-traffic/frontend-retry?targetGateway=us-envoy-1
DELETE /api/v1/routes/http/frontend-api?targetGateway=us-envoy-1
DELETE /api/v1/backends/services/frontend-api-backend?targetGateway=us-envoy-1
```

---

## Scenario 5: External Service with TLS Backend

**Objective:** Connect to an external HTTPS service with custom TLS configuration.

### Step 5.1: Create TLS Certificate Secret

**Request:** `POST {{baseUrl}}/api/v1/secrets/tls?targetGateway=us-envoy-1`

**Body:**
```json
{
  "name": "external-ca-cert",
  "tlsCrt": "-----BEGIN CERTIFICATE-----\nMIIC...(certificate content)...\n-----END CERTIFICATE-----",
  "tlsKey": "-----BEGIN PRIVATE KEY-----\nMIIE...(key content)...\n-----END PRIVATE KEY-----"
}
```

### Step 5.2: Create FQDN Backend with TLS

**Request:** `POST {{baseUrl}}/api/v1/backends/fqdn?targetGateway=us-envoy-1`

**Body:**
```json
{
  "name": "external-payment-service",
  "hostname": "payments.external-provider.com",
  "port": 443,
  "protocol": "HTTPS",
  "enableTls": true,
  "caSecretName": "external-ca-cert"
}
```

### Step 5.3: Create Route Using Backend

**Request:** `POST {{baseUrl}}/api/v1/routes/http`

**Body:**
```json
{
  "name": "payment-route",
  "targetGateway": "us-envoy-1",
  "path": "/api/payments",
  "backendName": "external-payment-service",
  "backendPort": 443
}
```

### Step 5.4: Cleanup

```
DELETE /api/v1/routes/http/payment-route?targetGateway=us-envoy-1&deleteBackend=false
DELETE /api/v1/backends/external-payment-service?targetGateway=us-envoy-1
DELETE /api/v1/secrets/external-ca-cert?targetGateway=us-envoy-1
```

---

## Scenario 6: gRPC Service Setup

**Objective:** Configure routing for a gRPC service.

### Step 6.1: Create gRPC Route

**Request:** `POST {{baseUrl}}/api/v1/routes/grpc`

**Body:**
```json
{
  "name": "grpc-user-service",
  "targetGateway": "us-envoy-1",
  "backendUrl": "grpc-server.internal.svc.cluster.local",
  "backendPort": 50051,
  "service": "user.UserService",
  "method": "GetUser",
  "hostnames": ["grpc.myapp.com"],
  "backendTls": {
    "enabled": false
  }
}
```

**Expected Response (201 Created):**
```json
{
  "status": "created",
  "message": "GRPCRoute 'grpc-user-service' and backend created",
  "route_name": "grpc-user-service",
  "backend_name": "grpc-user-service-backend",
  "namespace": "envoy-test",
  "target_gateway": "us-envoy-1"
}
```

### Step 6.2: List gRPC Routes

**Request:** `GET {{baseUrl}}/api/v1/routes/grpc?targetGateway=us-envoy-1`

### Step 6.3: Cleanup

```
DELETE /api/v1/routes/grpc/grpc-user-service?targetGateway=us-envoy-1&deleteBackend=true
```

---

## Scenario 7: IP-Based Access Control

**Objective:** Restrict API access to specific IP ranges.

### Step 7.1: Create Backend Service

**Request:** `POST {{baseUrl}}/api/v1/backends/services/external?targetGateway=us-envoy-1`

**Body:**
```json
{
  "name": "admin-api-backend",
  "url": "http://admin-service.internal",
  "port": 9080
}
```

### Step 7.2: Create Admin API Route

**Request:** `POST {{baseUrl}}/api/v1/routes/http`

**Body:**
```json
{
  "name": "admin-api",
  "targetGateway": "us-envoy-1",
  "path": "/api/admin",
  "backendName": "admin-api-backend",
  "backendPort": 9080
}
```

### Step 7.3: Apply IP Allowlist (Allow Only Internal IPs)

**Request:** `POST {{baseUrl}}/api/v1/policies/security/ip-allowlist?targetGateway=us-envoy-1`

**Body:**
```json
{
  "name": "admin-ip-allowlist",
  "targetRoute": "admin-api",
  "allowedCidrs": [
    "10.0.0.0/8",
    "172.16.0.0/12",
    "192.168.0.0/16",
    "203.0.113.50/32"
  ]
}
```

**Expected Response:**
```json
{
  "status": "created",
  "message": "IP allowlist policy 'admin-ip-allowlist' created",
  "resource_name": "admin-ip-allowlist",
  "details": {
    "allowed_cidrs": ["10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16", "203.0.113.50/32"],
    "targetGateway": "us-envoy-1"
  }
}
```

### Step 7.4: Alternative - Apply IP Blocklist

**Request:** `POST {{baseUrl}}/api/v1/policies/security/ip-blocklist?targetGateway=us-envoy-1`

**Body:**
```json
{
  "name": "public-api-blocklist",
  "targetRoute": "public-api",
  "blockedCidrs": [
    "1.2.3.0/24",
    "5.6.7.0/24",
    "192.0.2.0/24"
  ]
}
```

### Step 7.5: Cleanup

```
DELETE /api/v1/policies/security/admin-ip-allowlist?targetGateway=us-envoy-1
DELETE /api/v1/routes/http/admin-api?targetGateway=us-envoy-1
DELETE /api/v1/backends/services/admin-api-backend?targetGateway=us-envoy-1
```

---

## Scenario 8: API Key Authentication

**Objective:** Protect an API with API key authentication.

### Step 8.1: Create API Key Secret

**Request:** `POST {{baseUrl}}/api/v1/secrets/api-keys?targetGateway=us-envoy-1`

**Body:**
```json
{
  "name": "partner-api-keys",
  "apiKeys": {
    "partner-alpha": "sk_live_abc123def456",
    "partner-beta": "sk_live_xyz789uvw012",
    "partner-gamma": "sk_live_mno345pqr678",
    "internal-service": "sk_internal_999888777"
  }
}
```

**Expected Response:**
```json
{
  "status": "created",
  "message": "API Key Secret 'partner-api-keys' created",
  "resource_name": "partner-api-keys",
  "details": {
    "type": "Opaque",
    "purpose": "api-keys",
    "key_count": 4,
    "targetGateway": "us-envoy-1"
  }
}
```

### Step 8.2: Create Backend Service

**Request:** `POST {{baseUrl}}/api/v1/backends/services/external?targetGateway=us-envoy-1`

**Body:**
```json
{
  "name": "partner-api-backend",
  "url": "http://partner-service.internal",
  "port": 9080
}
```

### Step 8.3: Create Protected Route

**Request:** `POST {{baseUrl}}/api/v1/routes/http`

**Body:**
```json
{
  "name": "partner-api",
  "targetGateway": "us-envoy-1",
  "path": "/api/partner",
  "backendName": "partner-api-backend",
  "backendPort": 9080
}
```

### Step 8.4: Apply API Key Policy

**Request:** `POST {{baseUrl}}/api/v1/policies/security/api-key?targetGateway=us-envoy-1`

**Body:**
```json
{
  "name": "partner-api-key-auth",
  "targetRoute": "partner-api",
  "headerName": "X-API-Key",
  "apiKeysSecret": "partner-api-keys"
}
```

### Step 8.5: Test the Configuration

To test, you would call the API with the header:
```
curl -H "X-API-Key: sk_live_abc123def456" https://gateway/api/partner/endpoint
```

### Step 8.6: Cleanup

```
DELETE /api/v1/policies/security/partner-api-key-auth?targetGateway=us-envoy-1
DELETE /api/v1/routes/http/partner-api?targetGateway=us-envoy-1
DELETE /api/v1/backends/services/partner-api-backend?targetGateway=us-envoy-1
DELETE /api/v1/secrets/partner-api-keys?targetGateway=us-envoy-1
```

---

## Scenario 9: OpenAPI Import Workflow

**Objective:** Import routes from an OpenAPI specification.

### Step 9.1: Import from OpenAPI Spec (Dry Run First)

**Request:** `POST {{baseUrl}}/api/v1/openapi/import`

**Body:**
```json
{
  "targetGateway": "us-envoy-1",
  "spec": {
    "openapi": "3.0.0",
    "info": {
      "title": "Pet Store API",
      "version": "1.0.0"
    },
    "paths": {
      "/pets": {
        "get": {
          "summary": "List all pets",
          "operationId": "listPets",
          "tags": ["pets"]
        },
        "post": {
          "summary": "Create a pet",
          "operationId": "createPet",
          "tags": ["pets"]
        }
      },
      "/pets/{petId}": {
        "get": {
          "summary": "Get pet by ID",
          "operationId": "getPetById",
          "tags": ["pets"]
        },
        "put": {
          "summary": "Update a pet",
          "operationId": "updatePet",
          "tags": ["pets"]
        },
        "delete": {
          "summary": "Delete a pet",
          "operationId": "deletePet",
          "tags": ["pets"]
        }
      },
      "/pets/{petId}/photos": {
        "get": {
          "summary": "Get pet photos",
          "operationId": "getPetPhotos",
          "tags": ["photos"]
        },
        "post": {
          "summary": "Upload pet photo",
          "operationId": "uploadPetPhoto",
          "tags": ["photos"]
        }
      }
    }
  },
  "backendUrl": "petstore.swagger.io",
  "backendPort": 443,
  "backendTlsEnabled": true,
  "routePrefix": "petstore",
  "hostnames": ["api.petstore.com"],
  "dryRun": true
}
```

**Expected Response (Dry Run):**
```json
{
  "status": "success",
  "message": "Imported 4 routes from OpenAPI spec",
  "spec_title": "Pet Store API",
  "spec_version": "1.0.0",
  "routes_created": 4,
  "routes_skipped": 0,
  "routes": [
    {"name": "petstore-pets", "path": "/pets", "methods": ["GET", "POST"]},
    {"name": "petstore-pets-petid", "path": "/pets/{petId}", "methods": ["GET", "PUT", "DELETE"]},
    {"name": "petstore-pets-petid-photos", "path": "/pets/{petId}/photos", "methods": ["GET", "POST"]}
  ],
  "dry_run": true
}
```

### Step 9.2: Import for Real

Change `"dryRun": false` and send again.

### Step 9.3: List Imported Routes

**Request:** `GET {{baseUrl}}/api/v1/openapi/routes?targetGateway=us-envoy-1`

**Expected Response:**
```json
{
  "routes": [
    {
      "name": "petstore-pets",
      "namespace": "envoy-test",
      "path": "/pets",
      "apiTitle": "pet-store-api",
      "backend": "petstore-backend"
    },
    ...
  ],
  "total": 4,
  "targetGateway": "us-envoy-1"
}
```

### Step 9.4: Import from URL

**Request:** `POST {{baseUrl}}/api/v1/openapi/import/url`

**Body:**
```json
{
  "targetGateway": "us-envoy-1",
  "specUrl": "https://petstore.swagger.io/v2/swagger.json",
  "backendUrl": "petstore.swagger.io",
  "backendPort": 443,
  "backendTlsEnabled": true,
  "routePrefix": "swagger-petstore",
  "dryRun": true
}
```

### Step 9.5: Cleanup All Routes for an API

**Request:** `DELETE {{baseUrl}}/api/v1/openapi/routes/pet-store-api?targetGateway=us-envoy-1&deleteBackend=true`

**Expected Response:**
```json
{
  "status": "success",
  "message": "Deleted 4 routes",
  "deletedRoutes": ["petstore-pets", "petstore-pets-petid", "petstore-pets-petid-photos", "..."],
  "backendDeleted": true
}
```

---

## Scenario 10: Complete Production Setup

**Objective:** Set up a production-ready API with all security and traffic policies.

### Step 10.1: Create TLS Secret for HTTPS

**Request:** `POST {{baseUrl}}/api/v1/secrets/tls?targetGateway=us-envoy-1`

**Body:**
```json
{
  "name": "prod-api-tls",
  "tlsCrt": "-----BEGIN CERTIFICATE-----\n...\n-----END CERTIFICATE-----",
  "tlsKey": "-----BEGIN PRIVATE KEY-----\n...\n-----END PRIVATE KEY-----",
  "caCrt": "-----BEGIN CERTIFICATE-----\n...\n-----END CERTIFICATE-----"
}
```

### Step 10.2: Create Backend Service

**Request:** `POST {{baseUrl}}/api/v1/backends/services/external?targetGateway=us-envoy-1`

**Body:**
```json
{
  "name": "prod-api-backend",
  "url": "http://api-service.production.svc.cluster.local",
  "port": 9080
}
```

### Step 10.3: Create Production API Route

**Request:** `POST {{baseUrl}}/api/v1/routes/http`

**Body:**
```json
{
  "name": "prod-api",
  "targetGateway": "us-envoy-1",
  "path": "/api/v1",
  "backendName": "prod-api-backend",
  "backendPort": 9080,
  "hostnames": ["api.production.com"],
  "timeout": "60s"
}
```

### Step 10.4: Apply JWT Authentication

**Request:** `POST {{baseUrl}}/api/v1/policies/security/jwt?targetGateway=us-envoy-1`

**Body:**
```json
{
  "name": "prod-jwt-auth",
  "targetRoute": "prod-api",
  "issuer": "https://auth.production.com",
  "jwksUri": "https://auth.production.com/.well-known/jwks.json",
  "audiences": ["api.production.com"],
  "claimToHeaders": {
    "sub": "x-user-id",
    "tenant": "x-tenant-id"
  }
}
```

### Step 10.5: Apply CORS Policy

**Request:** `POST {{baseUrl}}/api/v1/policies/security/cors?targetGateway=us-envoy-1`

**Body:**
```json
{
  "name": "prod-cors",
  "targetRoute": "prod-api",
  "allowedOrigins": ["https://app.production.com", "https://admin.production.com"],
  "allowedMethods": ["GET", "POST", "PUT", "PATCH", "DELETE"],
  "allowedHeaders": ["Authorization", "Content-Type", "X-Request-ID"],
  "allowCredentials": true,
  "maxAge": "86400s"
}
```

### Step 10.6: Apply Rate Limiting

**Request:** `POST {{baseUrl}}/api/v1/policies/backend-traffic/rate-limit?targetGateway=us-envoy-1`

**Body:**
```json
{
  "name": "prod-rate-limit",
  "targetRoute": "prod-api",
  "requests": 10000,
  "unit": "Hour"
}
```

### Step 10.7: Apply Circuit Breaker

**Request:** `POST {{baseUrl}}/api/v1/policies/backend-traffic/circuit-breaker?targetGateway=us-envoy-1`

**Body:**
```json
{
  "name": "prod-circuit-breaker",
  "targetRoute": "prod-api",
  "maxConnections": 1000,
  "maxPendingRequests": 500,
  "maxParallelRequests": 100
}
```

### Step 10.8: Apply Retry Policy

**Request:** `POST {{baseUrl}}/api/v1/policies/backend-traffic/retry?targetGateway=us-envoy-1`

**Body:**
```json
{
  "name": "prod-retry",
  "targetRoute": "prod-api",
  "numRetries": 3,
  "perRetryTimeout": "10s",
  "retryOn5xx": true,
  "retryOnConnectFailure": true
}
```

### Step 10.9: Configure Access Logging

**Request:** `POST {{baseUrl}}/api/v1/policies/logging/access-log?targetGateway=us-envoy-1`

**Body:**
```json
{
  "name": "prod-access-log",
  "enabled": true,
  "format": "JSON",
  "output": "/dev/stdout",
  "includeHeaders": ["X-Request-ID", "X-User-ID", "X-Tenant-ID"]
}
```

### Step 10.10: Verify All Resources

```
GET /api/v1/routes/http?targetGateway=us-envoy-1
GET /api/v1/policies/security?targetGateway=us-envoy-1
GET /api/v1/policies/backend-traffic?targetGateway=us-envoy-1
GET /api/v1/policies/logging?targetGateway=us-envoy-1
GET /api/v1/secrets?targetGateway=us-envoy-1
```

### Step 10.11: Cleanup (In Reverse Order)

```
DELETE /api/v1/policies/logging/prod-access-log?targetGateway=us-envoy-1
DELETE /api/v1/policies/backend-traffic/prod-retry?targetGateway=us-envoy-1
DELETE /api/v1/policies/backend-traffic/prod-circuit-breaker?targetGateway=us-envoy-1
DELETE /api/v1/policies/backend-traffic/prod-rate-limit?targetGateway=us-envoy-1
DELETE /api/v1/policies/security/prod-cors?targetGateway=us-envoy-1
DELETE /api/v1/policies/security/prod-jwt-auth?targetGateway=us-envoy-1
DELETE /api/v1/routes/http/prod-api?targetGateway=us-envoy-1
DELETE /api/v1/backends/services/prod-api-backend?targetGateway=us-envoy-1
DELETE /api/v1/secrets/prod-api-tls?targetGateway=us-envoy-1
```

---

## Cleanup Procedures

### Delete All Resources for a Gateway

Execute these requests in order:

```bash
# 1. Delete all policies
DELETE /api/v1/policies/backend-traffic/{name}?targetGateway=us-envoy-1
DELETE /api/v1/policies/security/{name}?targetGateway=us-envoy-1
DELETE /api/v1/policies/client-traffic/{name}?targetGateway=us-envoy-1
DELETE /api/v1/policies/envoy-extension/{name}?targetGateway=us-envoy-1
DELETE /api/v1/policies/envoy-patch/{name}?targetGateway=us-envoy-1
DELETE /api/v1/policies/logging/{name}?targetGateway=us-envoy-1

# 2. Delete all routes (with backends)
DELETE /api/v1/routes/http/{name}?targetGateway=us-envoy-1&deleteBackend=true
DELETE /api/v1/routes/grpc/{name}?targetGateway=us-envoy-1&deleteBackend=true
DELETE /api/v1/routes/tls/{name}?targetGateway=us-envoy-1&deleteBackend=true
DELETE /api/v1/routes/tcp/{name}?targetGateway=us-envoy-1&deleteBackend=true
DELETE /api/v1/routes/udp/{name}?targetGateway=us-envoy-1&deleteBackend=true

# 3. Delete remaining backends
DELETE /api/v1/backends/{name}?targetGateway=us-envoy-1
DELETE /api/v1/backends/services/{name}?targetGateway=us-envoy-1

# 4. Delete secrets
DELETE /api/v1/secrets/{name}?targetGateway=us-envoy-1
```

---

## Troubleshooting

### Common Errors

| Error | Cause | Solution |
|-------|-------|----------|
| 400 - Unknown gateway | Invalid `targetGateway` | Check available gateways: `GET /api/v1/gateways` |
| 409 - Already exists | Resource with same name exists | Delete existing or use different name |
| 404 - Not found | Resource doesn't exist | Verify resource exists with GET/LIST |
| 422 - Validation error | Invalid payload format | Check request body schema |
| 500 - Internal error | K8s API error | Check API logs, verify K8s connectivity |

### Debugging Tips

1. **Check Health First:**
   ```
   GET /health
   GET /info
   ```

2. **Verify Gateway:**
   ```
   GET /api/v1/gateways/{targetGateway}
   ```

3. **List Resources Before Delete:**
   ```
   GET /api/v1/routes/http?targetGateway=us-envoy-1
   ```

4. **Use Dry Run for OpenAPI Import:**
   Always test with `"dryRun": true` first.

---

## Quick Reference

### Required Query Parameter

Most endpoints require `targetGateway` as a query parameter:
```
?targetGateway=us-envoy-1
```

### Common Patterns

| Action | Endpoint Pattern |
|--------|-----------------|
| Create | `POST /api/v1/{resource}` |
| List | `GET /api/v1/{resource}?targetGateway=xxx` |
| Get | `GET /api/v1/{resource}/{name}?targetGateway=xxx` |
| Update | `PUT /api/v1/{resource}/{name}?targetGateway=xxx` |
| Delete | `DELETE /api/v1/{resource}/{name}?targetGateway=xxx` |

### Policy Dependencies

When deleting, remove in this order:
1. Extension Policies → 2. Security Policies → 3. Traffic Policies → 4. Routes → 5. Backends → 6. Secrets
