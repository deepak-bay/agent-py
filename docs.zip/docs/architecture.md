# Envoy Gateway Agent API - Architecture Diagrams

## 1. High-Level Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                           ENVOY GATEWAY AGENT API                            │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  ┌──────────────┐    ┌──────────────┐    ┌──────────────┐    ┌────────────┐ │
│  │   Clients    │    │   Swagger    │    │    ReDoc     │    │  OpenAPI   │ │
│  │  (REST API)  │    │     UI       │    │     UI       │    │   Spec     │ │
│  └──────┬───────┘    └──────┬───────┘    └──────┬───────┘    └─────┬──────┘ │
│         │                   │                   │                  │        │
│         └───────────────────┴───────────────────┴──────────────────┘        │
│                                     │                                        │
│                                     ▼                                        │
│  ┌──────────────────────────────────────────────────────────────────────┐   │
│  │                         FastAPI Application                           │   │
│  │                         (app/main.py)                                 │   │
│  └──────────────────────────────────┬───────────────────────────────────┘   │
│                                     │                                        │
│         ┌───────────┬───────────────┼───────────────┬───────────┐           │
│         │           │               │               │           │           │
│         ▼           ▼               ▼               ▼           ▼           │
│  ┌───────────┐ ┌───────────┐ ┌───────────┐ ┌───────────┐ ┌───────────┐    │
│  │  Routers  │ │ AI Gateway│ │  Models   │ │AI Gateway │ │ Services  │    │
│  │           │ │  Router   │ │ (Pydantic)│ │  Models   │ │           │    │
│  └───────────┘ └───────────┘ └───────────┘ └───────────┘ └───────────┘    │
│                                                                              │
└──────────────────────────────────────┬──────────────────────────────────────┘
                                       │
                                       ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                              KUBERNETES / EKS                                │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  ┌───────────────┐  ┌───────────────┐  ┌───────────────┐  ┌──────────────┐  │
│  │  HTTPRoutes   │  │   Backends    │  │   Policies    │  │   Secrets    │  │
│  │  GRPCRoutes   │  │   Services    │  │               │  │              │  │
│  │  TLS/TCP/UDP  │  │               │  │               │  │              │  │
│  └───────────────┘  └───────────────┘  └───────────────┘  └──────────────┘  │
│                                                                              │
│  ┌──────────────────────────────────────────────────────────────────────┐   │
│  │                         ENVOY GATEWAY                                 │   │
│  │                    (Processes all resources)                          │   │
│  └──────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

## 2. API Components Structure

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                              API STRUCTURE                                   │
└─────────────────────────────────────────────────────────────────────────────┘

                              ┌─────────────┐
                              │   main.py   │
                              │  (FastAPI)  │
                              └──────┬──────┘
                                     │
        ┌────────────────────────────┼────────────────────────────┐
        │                            │                            │
        ▼                            ▼                            ▼
┌───────────────┐           ┌───────────────┐           ┌───────────────┐
│    ROUTERS    │           │    MODELS     │           │   SERVICES    │
├───────────────┤           ├───────────────┤           ├───────────────┤
│               │           │               │           │               │
│ • routes.py   │           │ • common.py   │           │ • k8s_client  │
│ • backends.py │           │ • routes.py   │           │ • resource_   │
│ • policies.py │           │ • backends.py │           │   manager     │
│ • secrets.py  │           │ • secrets.py  │           │ • openapi_    │
│ • openapi_    │           │ • openapi_    │           │   parser      │
│   import.py   │           │   import.py   │           │               │
│ • ai_gateway  │           │ • ai_gateway  │           │               │
│   .py         │           │   .py         │           │               │
│               │           │ • policies/   │           └───────┬───────┘
└───────────────┘           │   ├─backend   │                   │
                            │   ├─security  │                   │
                            │   ├─client    │                   ▼
                            │   └─extension │           ┌───────────────┐
                            └───────────────┘           │  Kubernetes   │
                                                        │     API       │
                                                        └───────────────┘
```

## 3. Request Flow

```
┌──────────────────────────────────────────────────────────────────────────────┐
│                              REQUEST FLOW                                     │
└──────────────────────────────────────────────────────────────────────────────┘

  Client                API                    Services              Kubernetes
    │                    │                        │                      │
    │  POST /routes/http │                        │                      │
    │───────────────────>│                        │                      │
    │                    │                        │                      │
    │                    │  Validate (Pydantic)   │                      │
    │                    │──────────┐             │                      │
    │                    │          │             │                      │
    │                    │<─────────┘             │                      │
    │                    │                        │                      │
    │                    │  create_http_route()   │                      │
    │                    │───────────────────────>│                      │
    │                    │                        │                      │
    │                    │                        │  get_k8s_client()    │
    │                    │                        │─────────┐            │
    │                    │                        │         │            │
    │                    │                        │<────────┘            │
    │                    │                        │                      │
    │                    │                        │  create_custom_      │
    │                    │                        │  resource()          │
    │                    │                        │─────────────────────>│
    │                    │                        │                      │
    │                    │                        │    HTTPRoute CRD     │
    │                    │                        │<─────────────────────│
    │                    │                        │                      │
    │                    │   ResourceResponse     │                      │
    │                    │<───────────────────────│                      │
    │                    │                        │                      │
    │   201 Created      │                        │                      │
    │<───────────────────│                        │                      │
    │                    │                        │                      │
```

## 4. Envoy Gateway Resources Managed

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                        ENVOY GATEWAY RESOURCES                               │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│                              ROUTES                                          │
├─────────────────┬─────────────────┬─────────────────┬───────────────────────┤
│                 │                 │                 │                       │
│   HTTPRoute     │    GRPCRoute    │    TLSRoute     │   TCPRoute/UDPRoute   │
│                 │                 │                 │                       │
│  ┌───────────┐  │  ┌───────────┐  │  ┌───────────┐  │  ┌───────────┐        │
│  │   path    │  │  │  service  │  │  │ hostnames │  │  │  backend  │        │
│  │  gateway  │  │  │  method   │  │  │  backend  │  │  │   port    │        │
│  │  backend  │  │  │  backend  │  │  │           │  │  │           │        │
│  │  timeout  │  │  │           │  │  │           │  │  │           │        │
│  └───────────┘  │  └───────────┘  │  └───────────┘  │  └───────────┘        │
│                 │                 │                 │                       │
└─────────────────┴─────────────────┴─────────────────┴───────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│                              POLICIES                                        │
├───────────────────────────────────┬─────────────────────────────────────────┤
│                                   │                                         │
│      BackendTrafficPolicy         │           SecurityPolicy                │
│                                   │                                         │
│  ┌─────────────────────────────┐  │  ┌─────────────────────────────┐        │
│  │  • Rate Limiting            │  │  │  • JWT Authentication       │        │
│  │  • Circuit Breaker          │  │  │  • OIDC Authentication      │        │
│  │  • Retry Policy             │  │  │  • Basic Auth               │        │
│  │  • Timeout Configuration    │  │  │  • API Key Auth             │        │
│  │  • Health Check             │  │  │  • CORS Configuration       │        │
│  │  • Load Balancing           │  │  │  • External Auth            │        │
│  │  • Connection Settings      │  │  │  • IP Allowlist/Blocklist   │        │
│  └─────────────────────────────┘  │  │  • Authorization Rules      │        │
│                                   │  └─────────────────────────────┘        │
│                                   │                                         │
├───────────────────────────────────┼─────────────────────────────────────────┤
│                                   │                                         │
│      ClientTrafficPolicy          │        EnvoyExtensionPolicy             │
│                                   │                                         │
│  ┌─────────────────────────────┐  │  ┌─────────────────────────────┐        │
│  │  • TLS Settings             │  │  │  • WASM Extensions          │        │
│  │  • HTTP/2 Configuration     │  │  │  • External Processors      │        │
│  │  • Connection Timeouts      │  │  │                             │        │
│  │  • Header Settings          │  │  │                             │        │
│  │  • Client IP Detection      │  │  │                             │        │
│  └─────────────────────────────┘  │  └─────────────────────────────┘        │
│                                   │                                         │
├───────────────────────────────────┼─────────────────────────────────────────┤
│                                   │                                         │
│      EnvoyProxy (Logging)         │        HTTPRoute (Headers)              │
│                                   │                                         │
│  ┌─────────────────────────────┐  │  ┌─────────────────────────────┐        │
│  │  • Access Logging (File)    │  │  │  • Request Header Add/Set   │        │
│  │  • JSON Logging             │  │  │  • Request Header Remove    │        │
│  │  • OpenTelemetry (OTLP)     │  │  │  • Response Header Add/Set  │        │
│  │  • Custom Log Formats       │  │  │  • Response Header Remove   │        │
│  └─────────────────────────────┘  │  └─────────────────────────────┘        │
│                                   │                                         │
└───────────────────────────────────┴─────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│                          BACKENDS & SECRETS                                  │
├─────────────────────────────────────┬───────────────────────────────────────┤
│                                     │                                       │
│           Backends                  │              Secrets                  │
│                                     │                                       │
│  ┌───────────────────────────────┐  │  ┌───────────────────────────────┐    │
│  │  • Kubernetes Services        │  │  │  • TLS Certificates           │    │
│  │  • ExternalName Services      │  │  │  • Basic Auth Credentials     │    │
│  │  • Backend CRD (FQDN)         │  │  │  • OIDC Client Secrets        │    │
│  │                               │  │  │  • API Keys                   │    │
│  └───────────────────────────────┘  │  └───────────────────────────────┘    │
│                                     │                                       │
└─────────────────────────────────────┴───────────────────────────────────────┘
```

## 5. API Endpoints Map

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                           API ENDPOINTS                                      │
└─────────────────────────────────────────────────────────────────────────────┘

/api/v1
│
├── /routes
│   ├── /http ─────────────── POST   Create HTTPRoute
│   │   │                     GET    List HTTPRoutes
│   │   ├── /{name} ───────── GET    Get HTTPRoute
│   │   │                     PUT    Update HTTPRoute
│   │   │                     DELETE Delete HTTPRoute
│   │   └── /with-backend ─── POST   Create HTTPRoute + Backend Service
│   │
│   ├── /grpc ─────────────── POST   Create GRPCRoute
│   │   │                     GET    List GRPCRoutes
│   │   └── /{name} ───────── DELETE Delete GRPCRoute
│   │
│   ├── /tls ──────────────── POST   Create TLSRoute
│   │   │                     GET    List TLSRoutes
│   │   └── /{name} ───────── DELETE Delete TLSRoute
│   │
│   ├── /tcp ──────────────── POST   Create TCPRoute
│   │   │                     GET    List TCPRoutes
│   │   └── /{name} ───────── DELETE Delete TCPRoute
│   │
│   └── /udp ──────────────── POST   Create UDPRoute
│       │                     GET    List UDPRoutes
│       └── /{name} ───────── DELETE Delete UDPRoute
│
├── /backends
│   ├── / ─────────────────── POST   Create Backend (CRD)
│   │   │                     GET    List Backends
│   │   └── /{name} ───────── GET    Get Backend
│   │                         PUT    Update Backend
│   │                         DELETE Delete Backend
│   │
│   ├── /fqdn ─────────────── POST   Create FQDN Backend
│   │
│   └── /services
│       ├── / ─────────────── POST   Create Service
│       │   │                 GET    List Services
│       │   └── /{name} ───── GET    Get Service
│       │                     PUT    Update Service
│       │                     DELETE Delete Service
│       │
│       └── /external ─────── POST   Create ExternalName Service
│
├── /policies
│   ├── /backend-traffic
│   │   ├── / ─────────────── POST   Create BackendTrafficPolicy
│   │   │   │                 GET    List Policies
│   │   │   └── /{name} ───── GET    Get Policy
│   │   │                     PUT    Update Policy
│   │   │                     DELETE Delete Policy
│   │   │
│   │   ├── /rate-limit ───── POST   Create Rate Limit Policy
│   │   ├── /circuit-breaker  POST   Create Circuit Breaker Policy
│   │   └── /retry ────────── POST   Create Retry Policy
│   │
│   ├── /security
│   │   ├── / ─────────────── POST   Create SecurityPolicy
│   │   │   │                 GET    List Policies
│   │   │   └── /{name} ───── GET/PUT/DELETE
│   │   │
│   │   ├── /jwt ──────────── POST   Create JWT Policy
│   │   ├── /cors ─────────── POST   Create CORS Policy
│   │   ├── /api-key ──────── POST   Create API Key Policy
│   │   ├── /basic-auth ───── POST   Create Basic Auth Policy
│   │   ├── /ip-allowlist ─── POST   Create IP Allowlist Policy
│   │   ├── /ip-blocklist ─── POST   Create IP Blocklist Policy
│   │   └── /external-auth ── POST   Create External Auth Policy
│   │
│   ├── /client-traffic
│   │   ├── / ─────────────── POST   Create ClientTrafficPolicy
│   │   │   │                 GET    List Policies
│   │   │   └── /{name} ───── GET/DELETE
│   │   │
│   │   ├── /tls ──────────── POST   Create TLS Policy
│   │   └── /timeout ──────── POST   Create Timeout Policy
│   │
│   ├── /envoy-patch
│   │   ├── / ─────────────── POST   Create EnvoyPatchPolicy
│   │   │                     GET    List Policies
│   │   └── /{name} ───────── DELETE Delete Policy
│   │
│   ├── /envoy-extension
│   │   ├── / ─────────────── POST   Create EnvoyExtensionPolicy
│   │   │                     GET    List Policies
│   │   ├── /{name} ───────── DELETE Delete Policy
│   │   │
│   │   ├── /wasm ─────────── POST   Create WASM Extension
│   │   └── /ext-proc ─────── POST   Create External Processor
│   │
│   └── /logging
│       ├── / ─────────────── GET    List Logging Configs (EnvoyProxy)
│       ├── /{name} ───────── DELETE Delete Logging Config
│       ├── /access-log ───── POST   Create Access Logging Config
│       └── /otlp ─────────── POST   Create OpenTelemetry Logging
│
├── /secrets
│   ├── / ─────────────────── POST   Create Secret
│   │   │                     GET    List Secrets
│   │   └── /{name} ───────── GET    Get Secret
│   │                         DELETE Delete Secret
│   │
│   ├── /tls ──────────────── POST   Create TLS Secret
│   ├── /basic-auth ───────── POST   Create Basic Auth Secret
│   ├── /oidc ─────────────── POST   Create OIDC Secret
│   └── /api-keys ─────────── POST   Create API Key Secret
│
├── /api ─────────────── POST   Create API (route + backend + policies)
│
├── /apis ────────────── GET    List all managed APIs
│   └── /{pathName} ──── GET    List APIs by path (without leading /)
│
├── /api/{name} ──────── GET    Get API details
│                        PUT    Update API (diff-based)
│                        DELETE Delete API and all resources
│
├── /ai-gateway
│   ├── /backends
│   │   ├── / ─────────────── POST   Create AI Backend (OpenAI/Azure/Bedrock/Custom)
│   │   │   │                 GET    List AI Backends
│   │   │   └── /{name} ───── GET    Get AI Backend
│   │   │                     DELETE Delete AI Backend
│   │
│   ├── /routes
│   │   ├── / ─────────────── POST   Create AI Route
│   │   │   │                 GET    List AI Routes
│   │   │   └── /{name} ───── GET    Get AI Route
│   │   │                     DELETE Delete AI Route
│   │   │
│   │   └── /model-routing ── POST   Create Model-Based Routing
│   │
│   └── /policies
│       ├── / ─────────────── GET    List AI Policies
│       ├── /{name} ───────── DELETE Delete AI Policy
│       ├── /token-rate-limit  POST  Create Token Rate Limit
│       └── /api-key-auth ──── POST  Create API Key Auth
│
└── /openapi
    ├── /import ─────────────── POST   Import routes from OpenAPI JSON
    ├── /import/url ─────────── POST   Import routes from OpenAPI URL
    ├── /import/file ────────── POST   Import routes from OpenAPI file
    ├── /routes ─────────────── GET    List imported routes
    └── /routes/{api} ───────── DELETE Delete all routes for an API
```

## 6. Deployment Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                         DEPLOYMENT ARCHITECTURE                              │
└─────────────────────────────────────────────────────────────────────────────┘

                           ┌─────────────────────┐
                           │    Load Balancer    │
                           │    (Optional)       │
                           └──────────┬──────────┘
                                      │
                                      ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                              EKS CLUSTER                                     │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  ┌───────────────────────────────────────────────────────────────────────┐  │
│  │                    Envoy Agent API Namespace                          │  │
│  │                                                                        │  │
│  │   ┌─────────────────────────────────────────────────────────────┐     │  │
│  │   │              Envoy Agent API Deployment                      │     │  │
│  │   │                                                              │     │  │
│  │   │   ┌─────────────┐  ┌─────────────┐  ┌─────────────┐         │     │  │
│  │   │   │   Pod 1     │  │   Pod 2     │  │   Pod 3     │         │     │  │
│  │   │   │             │  │             │  │             │         │     │  │
│  │   │   │ ┌─────────┐ │  │ ┌─────────┐ │  │ ┌─────────┐ │         │     │  │
│  │   │   │ │  API    │ │  │ │  API    │ │  │ │  API    │ │         │     │  │
│  │   │   │ │ :9080   │ │  │ │ :9080   │ │  │ │ :9080   │ │         │     │  │
│  │   │   │ └─────────┘ │  │ └─────────┘ │  │ └─────────┘ │         │     │  │
│  │   │   └─────────────┘  └─────────────┘  └─────────────┘         │     │  │
│  │   │                                                              │     │  │
│  │   └──────────────────────────┬───────────────────────────────────┘     │  │
│  │                              │                                         │  │
│  │                              │  Service Account                        │  │
│  │                              │  (IRSA)                                 │  │
│  │                              ▼                                         │  │
│  └──────────────────────────────┼────────────────────────────────────────┘  │
│                                 │                                           │
│  ┌──────────────────────────────┼────────────────────────────────────────┐  │
│  │              Envoy Gateway System Namespace                           │  │
│  │                              │                                         │  │
│  │                              ▼                                         │  │
│  │   ┌─────────────────────────────────────────────────────────────┐     │  │
│  │   │                    Envoy Gateway                             │     │  │
│  │   │                                                              │     │  │
│  │   │  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐     │     │  │
│  │   │  │ Gateway  │  │ Routes   │  │ Policies │  │ Backends │     │     │  │
│  │   │  │ Class    │  │          │  │          │  │          │     │     │  │
│  │   │  └──────────┘  └──────────┘  └──────────┘  └──────────┘     │     │  │
│  │   │                                                              │     │  │
│  │   │  ┌───────────────────────────────────────────────────────┐  │     │  │
│  │   │  │              Envoy Proxy Pods                          │  │     │  │
│  │   │  │                                                        │  │     │  │
│  │   │  │   ┌─────────┐   ┌─────────┐   ┌─────────┐             │  │     │  │
│  │   │  │   │ Envoy   │   │ Envoy   │   │ Envoy   │             │  │     │  │
│  │   │  │   │ Proxy   │   │ Proxy   │   │ Proxy   │             │  │     │  │
│  │   │  │   └─────────┘   └─────────┘   └─────────┘             │  │     │  │
│  │   │  └───────────────────────────────────────────────────────┘  │     │  │
│  │   └──────────────────────────────────────────────────────────────┘     │  │
│  │                                                                         │  │
│  └─────────────────────────────────────────────────────────────────────────┘  │
│                                                                              │
└──────────────────────────────────────────────────────────────────────────────┘
```

## 7. Data Flow Example: Creating an API Route with Rate Limiting

```
┌─────────────────────────────────────────────────────────────────────────────┐
│            EXAMPLE: Create API Route with Rate Limiting                      │
└─────────────────────────────────────────────────────────────────────────────┘

Step 1: Create Backend Service
──────────────────────────────

    POST /api/v1/backends/services/external
    {
      "name": "users-api",
      "url": "https://users.internal.example.com",
      "port": 443
    }
                    │
                    ▼
    ┌───────────────────────────────┐
    │  ExternalName Service         │
    │  name: users-api              │
    │  externalName: users.internal │
    │  port: 443                    │
    └───────────────────────────────┘


Step 2: Create HTTPRoute
────────────────────────

    POST /api/v1/routes/http
    {
      "name": "users-route",
      "path": "/api/v1/users",
      "gatewayName": "prod-gateway",
      "backendName": "users-api",
      "backendPort": 443,
      "timeout": "30s"
    }
                    │
                    ▼
    ┌───────────────────────────────┐
    │  HTTPRoute                    │
    │  name: users-route            │
    │  path: /api/v1/users          │
    │  gateway: prod-gateway        │
    │  backend: users-api:443       │
    └───────────────────────────────┘


Step 3: Apply Rate Limiting
───────────────────────────

    POST /api/v1/policies/backend-traffic/rate-limit
    {
      "name": "users-rate-limit",
      "targetRoute": "users-route",
      "requests": 100,
      "unit": "Minute"
    }
                    │
                    ▼
    ┌───────────────────────────────┐
    │  BackendTrafficPolicy         │
    │  name: users-rate-limit       │
    │  target: users-route          │
    │  limit: 100 req/min           │
    └───────────────────────────────┘


Step 4: Add JWT Authentication
──────────────────────────────

    POST /api/v1/policies/security/jwt
    {
      "name": "users-jwt",
      "targetRoute": "users-route",
      "issuer": "https://auth.example.com",
      "jwksUri": "https://auth.example.com/.well-known/jwks.json"
    }
                    │
                    ▼
    ┌───────────────────────────────┐
    │  SecurityPolicy               │
    │  name: users-jwt              │
    │  target: users-route          │
    │  jwt.issuer: auth.example.com │
    └───────────────────────────────┘


Final Result:
─────────────

    ┌─────────────────────────────────────────────────────────────────────┐
    │                         Traffic Flow                                 │
    │                                                                      │
    │   Client                                                             │
    │     │                                                                │
    │     │  GET /api/v1/users                                             │
    │     │  Authorization: Bearer <jwt>                                   │
    │     ▼                                                                │
    │   ┌─────────────────────────────────────────────────────────────┐   │
    │   │                    Envoy Gateway                             │   │
    │   │                                                              │   │
    │   │   1. Match HTTPRoute (path: /api/v1/users)                   │   │
    │   │   2. Validate JWT (SecurityPolicy)                           │   │
    │   │   3. Check Rate Limit (BackendTrafficPolicy)                 │   │
    │   │   4. Forward to Backend                                      │   │
    │   │                                                              │   │
    │   └─────────────────────────────────────────────────────────────┘   │
    │     │                                                                │
    │     ▼                                                                │
    │   ┌─────────────────────────────────────────────────────────────┐   │
    │   │  users.internal.example.com:443                              │   │
    │   └─────────────────────────────────────────────────────────────┘   │
    │                                                                      │
    └─────────────────────────────────────────────────────────────────────┘
```

## 8. AI Gateway Data Flow Example

```
┌─────────────────────────────────────────────────────────────────────────────┐
│          EXAMPLE: AI Gateway - Route to OpenAI with Token Rate Limit       │
└─────────────────────────────────────────────────────────────────────────────┘

Step 1: Create AI Backend (OpenAI)
──────────────────────────────────

    POST /api/v1/ai-gateway/backends
    {
      "name": "openai-backend",
      "provider": "openai",
      "apiVersion": "v1"
    }
                    │
                    ▼
    ┌───────────────────────────────┐
    │  Backend CRD                  │
    │  name: openai-backend         │
    │  hostname: api.openai.com     │
    │  port: 443                    │
    │  protocol: HTTPS              │
    └───────────────────────────────┘


Step 2: Create AI Route
───────────────────────

    POST /api/v1/ai-gateway/routes
    {
      "name": "openai-chat-route",
      "path": "/v1/chat/completions",
      "backendName": "openai-backend",
      "aiModel": "gpt-4o",
      "timeout": "120s"
    }
                    │
                    ▼
    ┌───────────────────────────────┐
    │  HTTPRoute                    │
    │  name: openai-chat-route      │
    │  path: /v1/chat/completions   │
    │  backend: openai-backend:443  │
    │  header: x-ai-model: gpt-4o  │
    │  timeout: 120s                │
    └───────────────────────────────┘


Step 3: Apply Token Rate Limiting
─────────────────────────────────

    POST /api/v1/ai-gateway/policies/token-rate-limit
    {
      "name": "openai-token-limit",
      "targetRouteName": "openai-chat-route",
      "requestsPerUnit": 60,
      "tokensPerUnit": 100000,
      "unit": "Minute"
    }
                    │
                    ▼
    ┌───────────────────────────────┐
    │  BackendTrafficPolicy         │
    │  name: openai-token-limit     │
    │  target: openai-chat-route    │
    │  limit: 60 req/min            │
    │  tokens: 100K/min             │
    └───────────────────────────────┘


Step 4: Apply API Key Authentication
─────────────────────────────────────

    POST /api/v1/ai-gateway/policies/api-key-auth
    {
      "name": "openai-api-key-auth",
      "targetRouteName": "openai-chat-route",
      "headerName": "x-api-key",
      "secretName": "ai-api-keys"
    }
                    │
                    ▼
    ┌───────────────────────────────┐
    │  SecurityPolicy               │
    │  name: openai-api-key-auth    │
    │  target: openai-chat-route    │
    │  header: x-api-key            │
    │  secret: ai-api-keys          │
    └───────────────────────────────┘


Final Result: AI Gateway Traffic Flow
─────────────────────────────────────

    ┌─────────────────────────────────────────────────────────────────────┐
    │                      AI Gateway Traffic Flow                        │
    │                                                                      │
    │   AI Client                                                          │
    │     │                                                                │
    │     │  POST /v1/chat/completions                                     │
    │     │  x-api-key: sk-abc123                                          │
    │     │  {"model": "gpt-4o", "messages": [...]}                        │
    │     ▼                                                                │
    │   ┌─────────────────────────────────────────────────────────────┐   │
    │   │                    Envoy Gateway                             │   │
    │   │                                                              │   │
    │   │   1. Match HTTPRoute (path: /v1/chat/completions)            │   │
    │   │   2. Validate API Key (SecurityPolicy)                       │   │
    │   │   3. Check Token Rate Limit (BackendTrafficPolicy)           │   │
    │   │   4. Inject x-ai-model header                                │   │
    │   │   5. Forward to AI Backend                                   │   │
    │   │                                                              │   │
    │   └─────────────────────────────────────────────────────────────┘   │
    │     │                                                                │
    │     ▼                                                                │
    │   ┌─────────────────────────────────────────────────────────────┐   │
    │   │  api.openai.com:443 (Backend CRD: openai-backend)           │   │
    │   └─────────────────────────────────────────────────────────────┘   │
    │                                                                      │
    └─────────────────────────────────────────────────────────────────────┘
```
