# Envoy Agent API - cURL Examples

Complete cURL commands for all API endpoints with example payloads.

**Base URL**: `http://localhost:9080`

**Note**: All endpoints require `targetGateway` query parameter to specify which cluster to operate on.

---

## Table of Contents

1. [Health Check](#health-check)
2. [Available Gateways](#available-gateways)
3. [API Management](#api-management)
4. [AI Gateway](#ai-gateway)
5. [HTTPRoute](#httproute)
6. [Header Injection/Removal](#header-injectionremoval)
7. [Backends](#backends)
8. [BackendTrafficPolicy](#backendtrafficpolicy)
9. [SecurityPolicy](#securitypolicy)
10. [IP Allowlist/Blocklist](#ip-allowlistblocklist)
11. [CORS](#cors)
12. [External Auth](#external-auth)
13. [ClientTrafficPolicy](#clienttrafficpolicy)
14. [Access Logging](#access-logging)
15. [EnvoyExtensionPolicy](#envoyextensionpolicy)
16. [Secrets](#secrets)
17. [OpenAPI Import](#openapi-import)

---

## Health Check

```bash
# Check API health
curl http://localhost:9080/health
```

---

## Available Gateways

```bash
# List all available target gateways
curl http://localhost:9080/api/v1/routes/gateways
```

**Response:**
```json
{
  "gateways": [
    {
      "name": "us-envoy-1",
      "region": "us-east-1",
      "cluster": "envoy-eks-cluster",
      "namespace": "envoy-test",
      "gatewayName": "envoy-gateway"
    },
    {
      "name": "eu-envoy-1",
      "region": "eu-central-1",
      "cluster": "envoy-eks-cluster",
      "namespace": "envoy-test",
      "gatewayName": "envoy-gateway"
    }
  ],
  "total": 2
}
```

---

## API Management

Higher-level API abstraction that orchestrates routes, backends, and policies in a single operation.

**Key behaviors:**
- Policy names are auto-prefixed with the API name (e.g., `my-jwt` on API `petstore-api` → `petstore-api-my-jwt`)
- Each API path must be unique per target gateway (409 if path is already taken)
- Updates are diff-based — only changed fields are applied
- Swagger/OpenAPI paths are consolidated as additional rules within the single main HTTPRoute (not one K8s resource per path)

### Create API — Basic (no policies)

```bash
curl -X POST http://localhost:9080/api/v1/api \
  -H "Content-Type: application/json" \
  -d '{
    "api-gateway": {
      "name": "my-api",
      "description": "A simple API",
      "api-type": "http",
      "upstream": {"url": "http://my-backend.internal:8080"},
      "target-gateway": "us-envoy-1",
      "path": "/my-api"
    }
  }'
```

### Create API — With All 10 Policies

```bash
curl -X POST http://localhost:9080/api/v1/api \
  -H "Content-Type: application/json" \
  -d '{
    "api-gateway": {
      "name": "full-policy-api",
      "description": "API with all 10 policy types",
      "api-type": "http",
      "policy-payload": [
        {"type": "JWT-validation", "name": "my-jwt", "issuer": "https://auth.example.com", "jwksUri": "https://auth.example.com/.well-known/jwks.json", "audiences": ["api.example.com"], "claimToHeaders": {"sub": "x-user-id", "email": "x-user-email"}},
        {"type": "cors", "name": "my-cors", "allowedOrigins": ["https://app.example.com"], "allowedMethods": ["GET", "POST", "PUT", "DELETE", "OPTIONS"], "allowedHeaders": ["Content-Type", "Authorization"], "allowCredentials": true, "maxAge": "24h"},
        {"type": "api-key", "name": "my-api-key", "headerName": "X-API-Key", "apiKeysSecret": "api-keys-secret"},
        {"type": "basic-auth", "name": "my-basic", "usersSecret": "basic-auth-users"},
        {"type": "ip-allow", "name": "office-ips", "allowedCidrs": ["10.0.0.0/8", "192.168.1.0/24"]},
        {"type": "ip-block", "name": "bad-actors", "blockedCidrs": ["1.2.3.0/24"]},
        {"type": "external-auth", "name": "my-ext-auth", "authServiceName": "auth-service", "authServicePort": 9000, "authPath": "/authorize"},
        {"type": "rate-limit", "name": "my-rl", "requests": 100, "unit": "Minute"},
        {"type": "circuit-breaker", "name": "my-cb", "maxConnections": 1024, "maxPendingRequests": 128, "maxParallelRequests": 128},
        {"type": "retry", "name": "my-retry", "numRetries": 3, "perRetryTimeout": "5s", "retryOn5xx": true, "retryOnConnectFailure": true}
      ],
      "tags": ["production"],
      "upstream": {"url": "https://backend.example.com", "tls-certificate": "backend-tls-cert"},
      "target-gateway": "us-envoy-1",
      "path": "/full-policy"
    }
  }'
```

### Create API with Swagger/OpenAPI Spec

When an OpenAPI/Swagger spec is provided, all spec paths are consolidated as additional rules
within the single main HTTPRoute (one K8s resource instead of one per path).

```bash
curl -X POST http://localhost:9080/api/v1/api \
  -H "Content-Type: application/json" \
  -d '{
    "api-gateway": {
      "name": "petstore-api",
      "description": "Pet Store API with swagger import",
      "api-type": "http",
      "policy-payload": [
        {"type": "rate-limit", "name": "my-rl", "requests": 100, "unit": "Minute"}
      ],
      "upstream": {"url": "https://petstore.example.com"},
      "target-gateway": "us-envoy-1",
      "path": "/petstore"
    },
    "swagger": {
      "openapi": "3.0.0",
      "info": {"title": "Pet Store API", "version": "1.0.0"},
      "paths": {
        "/pets": {
          "get": {"summary": "List all pets"},
          "post": {"summary": "Create a pet"}
        },
        "/pets/{petId}": {
          "get": {"summary": "Get pet by ID"},
          "put": {"summary": "Update a pet"},
          "delete": {"summary": "Delete a pet"}
        }
      }
    }
  }'
```

**Result:** A single HTTPRoute is created with:
- Rule 0: main API path (`/petstore` PathPrefix)
- Rule 1+: one rule per OpenAPI spec path (`/pets`, `/pets/{petId}`, etc.)
- Annotation `envoy-agent.io/swagger-imported: "true"` tracks the import

### List APIs

```bash
curl "http://localhost:9080/api/v1/apis?targetGateway=us-envoy-1"
```

### List APIs by Path

Search for APIs by their path (without the leading `/`):

```bash
# Find APIs with path /petstore
curl "http://localhost:9080/api/v1/apis/petstore?targetGateway=us-envoy-1"

# Find APIs with path /my-api
curl "http://localhost:9080/api/v1/apis/my-api?targetGateway=us-envoy-1"
```

### Get API Details

```bash
curl "http://localhost:9080/api/v1/api/full-policy-api?targetGateway=us-envoy-1"
```

### Update API (diff-based)

```bash
curl -X PUT http://localhost:9080/api/v1/api/full-policy-api \
  -H "Content-Type: application/json" \
  -d '{
    "api-gateway": {
      "name": "full-policy-api",
      "description": "Updated description — only changed fields applied",
      "api-type": "http",
      "policy-payload": [
        {"type": "JWT-validation", "name": "my-jwt", "issuer": "https://auth.example.com", "jwksUri": "https://auth.example.com/.well-known/jwks.json"},
        {"type": "rate-limit", "name": "updated-rl", "requests": 200, "unit": "Minute"}
      ],
      "upstream": {"url": "https://new-backend.example.com"},
      "target-gateway": "us-envoy-1",
      "path": "/full-policy"
    }
  }'
```

### Delete API

```bash
curl -X DELETE "http://localhost:9080/api/v1/api/full-policy-api?targetGateway=us-envoy-1"
```

---

## AI Gateway

Manage AI/LLM service backends, routes, and policies for providers like OpenAI, Azure OpenAI, AWS Bedrock, and custom AI services.

### Create OpenAI Backend

```bash
curl -X POST http://localhost:9080/api/v1/ai-gateway/backends \
  -H "Content-Type: application/json" \
  -d '{
    "name": "openai-backend",
    "targetGateway": "us-envoy-1",
    "provider": "openai"
  }'
```

**Response:**
```json
{
  "status": "created",
  "message": "AI Backend 'openai-backend' created for openai",
  "backendName": "openai-backend",
  "namespace": "envoy-test",
  "targetGateway": "us-envoy-1",
  "provider": "openai",
  "apiEndpoint": "api.openai.com",
  "details": {"port": 443, "tls": true}
}
```

### Create Azure OpenAI Backend

```bash
curl -X POST http://localhost:9080/api/v1/ai-gateway/backends \
  -H "Content-Type: application/json" \
  -d '{
    "name": "azure-openai-backend",
    "targetGateway": "us-envoy-1",
    "provider": "azure-openai",
    "azureDeploymentName": "my-gpt4-deployment",
    "azureApiVersion": "2024-02-01"
  }'
```

### Create AWS Bedrock Backend

```bash
curl -X POST http://localhost:9080/api/v1/ai-gateway/backends \
  -H "Content-Type: application/json" \
  -d '{
    "name": "bedrock-backend",
    "targetGateway": "us-envoy-1",
    "provider": "aws-bedrock",
    "awsRegion": "us-west-2"
  }'
```

### Create Custom AI Backend

```bash
curl -X POST http://localhost:9080/api/v1/ai-gateway/backends \
  -H "Content-Type: application/json" \
  -d '{
    "name": "custom-llm-backend",
    "targetGateway": "us-envoy-1",
    "provider": "custom",
    "apiEndpoint": "https://my-llm-api.internal.example.com",
    "port": 8443
  }'
```

### List AI Backends

```bash
curl "http://localhost:9080/api/v1/ai-gateway/backends?targetGateway=us-envoy-1"
```

### Get AI Backend

```bash
curl "http://localhost:9080/api/v1/ai-gateway/backends/openai-backend?targetGateway=us-envoy-1"
```

### Delete AI Backend

```bash
curl -X DELETE "http://localhost:9080/api/v1/ai-gateway/backends/openai-backend?targetGateway=us-envoy-1"
```

### Create AI Route (Chat Completions)

```bash
curl -X POST http://localhost:9080/api/v1/ai-gateway/routes \
  -H "Content-Type: application/json" \
  -d '{
    "name": "openai-chat-route",
    "targetGateway": "us-envoy-1",
    "backendName": "openai-backend",
    "backendPort": 443,
    "path": "/v1/chat/completions",
    "model": "gpt-4o",
    "timeout": "120s"
  }'
```

### Create AI Route with Multiple Paths

```bash
curl -X POST http://localhost:9080/api/v1/ai-gateway/routes \
  -H "Content-Type: application/json" \
  -d '{
    "name": "openai-multi-route",
    "targetGateway": "us-envoy-1",
    "backendName": "openai-backend",
    "backendPort": 443,
    "path": "/v1/chat/completions",
    "additionalPaths": ["/v1/embeddings", "/v1/models"],
    "timeout": "120s"
  }'
```

### List AI Routes

```bash
curl "http://localhost:9080/api/v1/ai-gateway/routes?targetGateway=us-envoy-1"
```

### Delete AI Route

```bash
curl -X DELETE "http://localhost:9080/api/v1/ai-gateway/routes/openai-chat-route?targetGateway=us-envoy-1"
```

### Create Token Rate Limit for AI

```bash
curl -X POST http://localhost:9080/api/v1/ai-gateway/policies/token-rate-limit \
  -H "Content-Type: application/json" \
  -d '{
    "name": "openai-token-limit",
    "targetGateway": "us-envoy-1",
    "targetRoute": "openai-chat-route",
    "totalTokensPerMinute": 100000,
    "inputTokensPerMinute": 80000,
    "outputTokensPerMinute": 20000,
    "requestsPerMinute": 60
  }'
```

### Create AI API Key Authentication

```bash
curl -X POST http://localhost:9080/api/v1/ai-gateway/policies/api-key-auth \
  -H "Content-Type: application/json" \
  -d '{
    "name": "ai-api-key-auth",
    "targetGateway": "us-envoy-1",
    "targetRoute": "openai-chat-route",
    "apiKeysSecret": "ai-api-keys",
    "headerName": "x-api-key"
  }'
```

### Create Model-Based Routing

```bash
curl -X POST http://localhost:9080/api/v1/ai-gateway/routes/model-routing \
  -H "Content-Type: application/json" \
  -d '{
    "name": "ai-model-router",
    "targetGateway": "us-envoy-1",
    "path": "/v1/chat/completions",
    "rules": [
      {"model": "gpt-4o", "backendName": "openai-backend", "backendPort": 443},
      {"model": "claude-3.5-sonnet", "backendName": "anthropic-backend", "backendPort": 443}
    ],
    "defaultBackendName": "openai-backend",
    "defaultBackendPort": 443,
    "timeout": "120s"
  }'
```

### List AI Policies

```bash
curl "http://localhost:9080/api/v1/ai-gateway/policies?targetGateway=us-envoy-1"
```

### Delete AI Policy

```bash
curl -X DELETE "http://localhost:9080/api/v1/ai-gateway/policies/openai-token-limit?targetGateway=us-envoy-1"
```

### Complete AI Gateway Setup Example

```bash
# 1. Create backend pointing to OpenAI
curl -X POST http://localhost:9080/api/v1/ai-gateway/backends \
  -H "Content-Type: application/json" \
  -d '{"name": "openai-backend", "targetGateway": "us-envoy-1", "provider": "openai"}'

# 2. Create route for chat completions
curl -X POST http://localhost:9080/api/v1/ai-gateway/routes \
  -H "Content-Type: application/json" \
  -d '{
    "name": "openai-chat-route",
    "targetGateway": "us-envoy-1",
    "backendName": "openai-backend",
    "backendPort": 443,
    "path": "/v1/chat/completions",
    "model": "gpt-4o",
    "timeout": "120s"
  }'

# 3. Add token rate limiting
curl -X POST http://localhost:9080/api/v1/ai-gateway/policies/token-rate-limit \
  -H "Content-Type: application/json" \
  -d '{
    "name": "openai-limit",
    "targetGateway": "us-envoy-1",
    "targetRoute": "openai-chat-route",
    "totalTokensPerMinute": 100000,
    "requestsPerMinute": 60
  }'

# 4. Secure with API key auth
curl -X POST http://localhost:9080/api/v1/ai-gateway/policies/api-key-auth \
  -H "Content-Type: application/json" \
  -d '{
    "name": "ai-auth",
    "targetGateway": "us-envoy-1",
    "targetRoute": "openai-chat-route",
    "apiKeysSecret": "ai-api-keys"
  }'
```

---

## HTTPRoute

Two options for creating HTTPRoutes:
1. **Simple Route** (`/http/simple`) - Create route with an existing backend
2. **Route with Backend** (`/http`) - Automatically create backend and route together

### Option 1: Create Simple HTTPRoute (with existing backend)

```bash
curl -X POST "http://localhost:9080/api/v1/routes/http/simple" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "users-route",
    "targetGateway": "us-envoy-1",
    "path": "/api/v1/users",
    "backendName": "users-service",
    "backendPort": 9080
  }'
```

### Option 2: Create HTTPRoute with Automatic Backend (US Region)

```bash
curl -X POST http://localhost:9080/api/v1/routes/http \
  -H "Content-Type: application/json" \
  -d '{
    "name": "users-api",
    "targetGateway": "us-envoy-1",
    "path": "/api/v1/users",
    "backendUrl": "users-service.internal.example.com",
    "backendPort": 443,
    "backendTls": {
      "enabled": true
    }
  }'
```

### Create HTTPRoute (EU Region)

```bash
curl -X POST http://localhost:9080/api/v1/routes/http \
  -H "Content-Type: application/json" \
  -d '{
    "name": "orders-api",
    "targetGateway": "eu-envoy-1",
    "path": "/api/v1/orders",
    "backendUrl": "orders-service.eu.example.com",
    "backendPort": 9080
  }'
```

### Create HTTPRoute with Full Options

```bash
curl -X POST http://localhost:9080/api/v1/routes/http \
  -H "Content-Type: application/json" \
  -d '{
    "name": "products-api",
    "targetGateway": "us-envoy-1",
    "path": "/api/v1/products",
    "pathType": "PathPrefix",
    "backendUrl": "products.internal.example.com",
    "backendPort": 443,
    "backendTls": {
      "enabled": true,
      "insecureSkipVerify": false
    },
    "hostnames": ["api.example.com"],
    "methods": ["GET", "POST", "PUT", "DELETE"],
    "timeout": "30s",
    "labels": {
      "team": "platform",
      "env": "production"
    }
  }'
```

### List HTTPRoutes

```bash
# List routes for US gateway
curl "http://localhost:9080/api/v1/routes/http?targetGateway=us-envoy-1"

# List routes for EU gateway
curl "http://localhost:9080/api/v1/routes/http?targetGateway=eu-envoy-1"
```

### Get HTTPRoute by Name

```bash
curl "http://localhost:9080/api/v1/routes/http/users-api?targetGateway=us-envoy-1"
```

### Update HTTPRoute

```bash
curl -X PUT "http://localhost:9080/api/v1/routes/http/users-api?targetGateway=us-envoy-1" \
  -H "Content-Type: application/json" \
  -d '{
    "path": "/api/v2/users",
    "timeout": "60s"
  }'
```

### Delete HTTPRoute (with backend)

```bash
# Delete route and its backend service
curl -X DELETE "http://localhost:9080/api/v1/routes/http/users-api?targetGateway=us-envoy-1&deleteBackend=true"

# Delete route only, keep backend
curl -X DELETE "http://localhost:9080/api/v1/routes/http/users-api?targetGateway=us-envoy-1&deleteBackend=false"
```

---

## Header Injection/Removal

Header modification is included in the route creation payload.

### Create Route with Request Header Injection

```bash
curl -X POST http://localhost:9080/api/v1/routes/http \
  -H "Content-Type: application/json" \
  -d '{
    "name": "api-with-headers",
    "targetGateway": "us-envoy-1",
    "path": "/api/v1",
    "backendUrl": "api-service.internal.example.com",
    "backendPort": 443,
    "backendTls": {"enabled": true},
    "requestHeadersToAdd": [
      {"name": "X-Request-ID", "value": "%REQ_ID%"},
      {"name": "X-Gateway-Region", "value": "us-east-1"}
    ],
    "requestHeadersToSet": [
      {"name": "X-Forwarded-Proto", "value": "https"}
    ],
    "requestHeadersToRemove": [
      "X-Debug-Header"
    ]
  }'
```

### Create Route with Security Response Headers

```bash
curl -X POST http://localhost:9080/api/v1/routes/http \
  -H "Content-Type: application/json" \
  -d '{
    "name": "secure-api",
    "targetGateway": "us-envoy-1",
    "path": "/api/secure",
    "backendUrl": "secure-service.internal.example.com",
    "backendPort": 443,
    "backendTls": {"enabled": true},
    "responseHeadersToAdd": [
      {"name": "X-Content-Type-Options", "value": "nosniff"},
      {"name": "X-Frame-Options", "value": "DENY"},
      {"name": "Strict-Transport-Security", "value": "max-age=31536000; includeSubDomains"},
      {"name": "X-XSS-Protection", "value": "1; mode=block"}
    ],
    "responseHeadersToRemove": [
      "Server",
      "X-Powered-By"
    ]
  }'
```

---

## Backends

### List Backends

```bash
curl "http://localhost:9080/api/v1/backends?targetGateway=us-envoy-1"
```

### Get Backend

```bash
curl "http://localhost:9080/api/v1/backends/users-api-backend?targetGateway=us-envoy-1"
```

### Create FQDN Backend

```bash
curl -X POST "http://localhost:9080/api/v1/backends/fqdn?targetGateway=us-envoy-1" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "external-api-backend",
    "hostname": "api.external-service.com",
    "port": 443,
    "protocol": "HTTPS",
    "enableTls": true,
    "caSecretName": "external-ca-cert"
  }'
```

### Create ExternalName Service

```bash
curl -X POST "http://localhost:9080/api/v1/backends/services/external?targetGateway=us-envoy-1" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "external-svc",
    "url": "https://api.example.com",
    "port": 443
  }'
```

### List Services

```bash
curl "http://localhost:9080/api/v1/backends/services?targetGateway=us-envoy-1"
```

### Delete Backend

```bash
curl -X DELETE "http://localhost:9080/api/v1/backends/external-api-backend?targetGateway=us-envoy-1"
```

---

## BackendTrafficPolicy

### Create Rate Limit Policy

```bash
curl -X POST "http://localhost:9080/api/v1/policies/backend-traffic/rate-limit?targetGateway=us-envoy-1" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "api-rate-limit",
    "targetRoute": "users-api",
    "requests": 100,
    "unit": "Minute"
  }'
```

### Create Circuit Breaker Policy

```bash
curl -X POST "http://localhost:9080/api/v1/policies/backend-traffic/circuit-breaker?targetGateway=us-envoy-1" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "api-circuit-breaker",
    "targetRoute": "users-api",
    "maxConnections": 1000,
    "maxPendingRequests": 100,
    "maxParallelRequests": 100
  }'
```

### Create Retry Policy

```bash
curl -X POST "http://localhost:9080/api/v1/policies/backend-traffic/retry?targetGateway=us-envoy-1" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "api-retry",
    "targetRoute": "users-api",
    "numRetries": 3,
    "perRetryTimeout": "5s",
    "retryOn5xx": true,
    "retryOnConnectFailure": true
  }'
```

### List BackendTrafficPolicies

```bash
curl "http://localhost:9080/api/v1/policies/backend-traffic?targetGateway=us-envoy-1"
```

### Get BackendTrafficPolicy

```bash
curl "http://localhost:9080/api/v1/policies/backend-traffic/api-rate-limit?targetGateway=us-envoy-1"
```

### Delete BackendTrafficPolicy

```bash
curl -X DELETE "http://localhost:9080/api/v1/policies/backend-traffic/api-rate-limit?targetGateway=us-envoy-1"
```

---

## SecurityPolicy

### Create JWT Policy

```bash
curl -X POST "http://localhost:9080/api/v1/policies/security/jwt?targetGateway=us-envoy-1" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "jwt-auth-policy",
    "targetRoute": "users-api",
    "issuer": "https://auth.example.com",
    "jwksUri": "https://auth.example.com/.well-known/jwks.json",
    "audiences": ["api.example.com"],
    "claimToHeaders": {
      "sub": "X-User-ID",
      "email": "X-User-Email"
    }
  }'
```

### Create API Key Policy

```bash
curl -X POST "http://localhost:9080/api/v1/policies/security/api-key?targetGateway=us-envoy-1" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "api-key-policy",
    "targetRoute": "users-api",
    "headerName": "X-API-Key",
    "apiKeysSecret": "api-keys-secret"
  }'
```

### Create Basic Auth Policy

```bash
curl -X POST "http://localhost:9080/api/v1/policies/security/basic-auth?targetGateway=us-envoy-1" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "basic-auth-policy",
    "targetRoute": "admin-api",
    "usersSecret": "htpasswd-secret"
  }'
```

### List SecurityPolicies

```bash
curl "http://localhost:9080/api/v1/policies/security?targetGateway=us-envoy-1"
```

### Get SecurityPolicy

```bash
curl "http://localhost:9080/api/v1/policies/security/jwt-auth-policy?targetGateway=us-envoy-1"
```

### Delete SecurityPolicy

```bash
curl -X DELETE "http://localhost:9080/api/v1/policies/security/jwt-auth-policy?targetGateway=us-envoy-1"
```

---

## IP Allowlist/Blocklist

### Create IP Allowlist Policy

```bash
curl -X POST "http://localhost:9080/api/v1/policies/security/ip-allowlist?targetGateway=us-envoy-1" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "office-only-access",
    "targetRoute": "internal-api",
    "allowedCidrs": [
      "10.0.0.0/8",
      "192.168.1.0/24",
      "203.0.113.50/32"
    ]
  }'
```

### Create IP Blocklist Policy

```bash
curl -X POST "http://localhost:9080/api/v1/policies/security/ip-blocklist?targetGateway=us-envoy-1" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "block-bad-actors",
    "targetRoute": "public-api",
    "blockedCidrs": [
      "192.0.2.0/24",
      "198.51.100.0/24"
    ]
  }'
```

---

## CORS

### Create CORS Policy

```bash
curl -X POST "http://localhost:9080/api/v1/policies/security/cors?targetGateway=us-envoy-1" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "api-cors-policy",
    "targetRoute": "frontend-api",
    "allowedOrigins": ["https://app.example.com", "https://www.example.com"],
    "allowedMethods": ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    "allowedHeaders": ["Content-Type", "Authorization", "X-Request-ID"],
    "allowCredentials": true,
    "maxAge": "24h"
  }'
```

---

## External Auth

### Create External Auth Policy

```bash
curl -X POST "http://localhost:9080/api/v1/policies/security/external-auth?targetGateway=us-envoy-1" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "ext-auth-policy",
    "targetRoute": "protected-api",
    "authServiceName": "auth-service",
    "authServicePort": 9001,
    "authPath": "/auth/verify",
    "headersToAuth": ["Authorization", "Cookie", "X-API-Key"],
    "failureMode": "FailClosed"
  }'
```

---

## ClientTrafficPolicy

### Create TLS Policy

```bash
curl -X POST "http://localhost:9080/api/v1/policies/client-traffic/tls?targetGateway=us-envoy-1" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "secure-tls-policy",
    "targetGateway": "envoy-gateway",
    "minVersion": "1.2",
    "maxVersion": "1.3",
    "ciphers": [
      "ECDHE-RSA-AES256-GCM-SHA384",
      "ECDHE-RSA-AES128-GCM-SHA256"
    ]
  }'
```

### Create Timeout Policy

```bash
curl -X POST "http://localhost:9080/api/v1/policies/client-traffic/timeout?targetGateway=us-envoy-1" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "api-timeout-policy",
    "targetGateway": "envoy-gateway",
    "connectTimeout": "10s",
    "requestTimeout": "30s",
    "idleTimeout": "300s"
  }'
```

### List ClientTrafficPolicies

```bash
curl "http://localhost:9080/api/v1/policies/client-traffic?targetGateway=us-envoy-1"
```

### Delete ClientTrafficPolicy

```bash
curl -X DELETE "http://localhost:9080/api/v1/policies/client-traffic/api-timeout-policy?targetGateway=us-envoy-1"
```

---

## Access Logging

### Enable JSON Access Logging

```bash
curl -X POST "http://localhost:9080/api/v1/policies/logging/access-log?targetGateway=us-envoy-1" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "json-access-log",
    "enabled": true,
    "format": "JSON",
    "output": "/dev/stdout",
    "includeHeaders": ["X-Request-ID", "X-Forwarded-For", "User-Agent"]
  }'
```

### Configure OpenTelemetry Logging

```bash
curl -X POST "http://localhost:9080/api/v1/policies/logging/otlp?targetGateway=us-envoy-1" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "otlp-logging",
    "otlpHost": "otel-collector.monitoring.svc.cluster.local",
    "otlpPort": 4317,
    "serviceName": "envoy-gateway"
  }'
```

### List Logging Configurations

```bash
curl "http://localhost:9080/api/v1/policies/logging?targetGateway=us-envoy-1"
```

### Delete Logging Configuration

```bash
curl -X DELETE "http://localhost:9080/api/v1/policies/logging/json-access-log?targetGateway=us-envoy-1"
```

---

## EnvoyExtensionPolicy

### Create WASM Extension

```bash
curl -X POST "http://localhost:9080/api/v1/policies/envoy-extension/wasm?targetGateway=us-envoy-1" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "custom-wasm-filter",
    "targetRoute": "api-route",
    "wasmName": "my-filter",
    "wasmUrl": "oci://ghcr.io/myorg/my-wasm-filter:v1.0.0",
    "wasmConfig": {"key": "value"},
    "failOpen": true
  }'
```

### Create External Processor

```bash
curl -X POST "http://localhost:9080/api/v1/policies/envoy-extension/ext-proc?targetGateway=us-envoy-1" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "request-processor",
    "targetRoute": "api-route",
    "serviceName": "ext-processor",
    "servicePort": 9000,
    "processRequestHeaders": true,
    "processRequestBody": true,
    "processResponseHeaders": true,
    "processResponseBody": false,
    "failureMode": "close"
  }'
```

### List EnvoyExtensionPolicies

```bash
curl "http://localhost:9080/api/v1/policies/envoy-extension?targetGateway=us-envoy-1"
```

### Delete EnvoyExtensionPolicy

```bash
curl -X DELETE "http://localhost:9080/api/v1/policies/envoy-extension/custom-wasm-filter?targetGateway=us-envoy-1"
```

---

## EnvoyPatchPolicy

### List EnvoyPatchPolicies

```bash
curl "http://localhost:9080/api/v1/policies/envoy-patch?targetGateway=us-envoy-1"
```

### Delete EnvoyPatchPolicy

```bash
curl -X DELETE "http://localhost:9080/api/v1/policies/envoy-patch/custom-patch?targetGateway=us-envoy-1"
```

---

## Secrets

### Create Generic Secret

```bash
curl -X POST "http://localhost:9080/api/v1/secrets?targetGateway=us-envoy-1" \
  -H "Content-Type: application/json" \
  -d '{
    "metadata": {
      "name": "my-secret"
    },
    "type": "Opaque",
    "stringData": {
      "key1": "value1",
      "key2": "value2"
    }
  }'
```

### Create TLS Secret

```bash
curl -X POST "http://localhost:9080/api/v1/secrets/tls?targetGateway=us-envoy-1" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "api-tls-cert",
    "tlsCrt": "LS0tLS1CRUdJTi...(base64-encoded cert)...",
    "tlsKey": "LS0tLS1CRUdJTi...(base64-encoded key)..."
  }'
```

### Create Basic Auth Secret (htpasswd)

```bash
curl -X POST "http://localhost:9080/api/v1/secrets/basic-auth?targetGateway=us-envoy-1" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "api-users",
    "username": "admin",
    "password": "secure-password"
  }'
```

### Create OIDC Secret

```bash
curl -X POST "http://localhost:9080/api/v1/secrets/oidc?targetGateway=us-envoy-1" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "oidc-client-secret",
    "clientId": "my-client-id",
    "clientSecret": "my-client-secret"
  }'
```

### Create API Keys Secret

```bash
curl -X POST "http://localhost:9080/api/v1/secrets/api-keys?targetGateway=us-envoy-1" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "api-keys-secret",
    "apiKeys": {
      "client1": "api-key-for-client-1",
      "client2": "api-key-for-client-2"
    }
  }'
```

### List Secrets

```bash
curl "http://localhost:9080/api/v1/secrets?targetGateway=us-envoy-1"
```

### Get Secret

```bash
curl "http://localhost:9080/api/v1/secrets/api-tls-cert?targetGateway=us-envoy-1"
```

### Delete Secret

```bash
curl -X DELETE "http://localhost:9080/api/v1/secrets/api-tls-cert?targetGateway=us-envoy-1"
```

---

## OpenAPI Import

Import routes directly from OpenAPI/Swagger specifications.

### Import from JSON Body

```bash
curl -X POST "http://localhost:9080/api/v1/openapi/import" \
  -H "Content-Type: application/json" \
  -d '{
    "targetGateway": "us-envoy-1",
    "spec": {
      "openapi": "3.0.0",
      "info": {"title": "Users API", "version": "1.0.0"},
      "paths": {
        "/users": {
          "get": {"summary": "List users"},
          "post": {"summary": "Create user"}
        },
        "/users/{id}": {
          "get": {"summary": "Get user"},
          "put": {"summary": "Update user"},
          "delete": {"summary": "Delete user"}
        }
      }
    },
    "backendUrl": "users-api.internal.example.com",
    "backendPort": 443,
    "backendTlsEnabled": true,
    "routePrefix": "users",
    "hostnames": ["api.example.com"]
  }'
```

### Import from URL

```bash
curl -X POST "http://localhost:9080/api/v1/openapi/import/url" \
  -H "Content-Type: application/json" \
  -d '{
    "targetGateway": "us-envoy-1",
    "specUrl": "https://petstore.swagger.io/v2/swagger.json",
    "backendUrl": "petstore.internal.example.com",
    "backendPort": 443,
    "backendTlsEnabled": true,
    "routePrefix": "petstore"
  }'
```

### Import from File (multipart form)

```bash
curl -X POST "http://localhost:9080/api/v1/openapi/import/file" \
  -F "file=@openapi.yaml" \
  -F "targetGateway=us-envoy-1" \
  -F "backendUrl=api.internal.example.com" \
  -F "backendPort=443" \
  -F "backendTlsEnabled=true" \
  -F "routePrefix=myapi"
```

### Dry Run (Preview without creating)

```bash
curl -X POST "http://localhost:9080/api/v1/openapi/import" \
  -H "Content-Type: application/json" \
  -d '{
    "targetGateway": "us-envoy-1",
    "spec": {...},
    "backendUrl": "api.example.com",
    "backendPort": 443,
    "dryRun": true
  }'
```

### List Imported Routes

```bash
curl "http://localhost:9080/api/v1/openapi/routes?targetGateway=us-envoy-1"
```

### Delete All Routes for an API

```bash
curl -X DELETE "http://localhost:9080/api/v1/openapi/routes/users-api?targetGateway=us-envoy-1&deleteBackend=true"
```

### OpenAPI Import Response

```json
{
  "status": "success",
  "message": "Imported 5 routes from OpenAPI spec",
  "specTitle": "Users API",
  "specVersion": "1.0.0",
  "routesCreated": 5,
  "routesSkipped": 0,
  "routes": [
    {"name": "users-users-get", "path": "/users", "methods": ["GET"]},
    {"name": "users-users-post", "path": "/users", "methods": ["POST"]},
    {"name": "users-users-id-get", "path": "/users/{id}", "methods": ["GET"]}
  ],
  "errors": [],
  "targetGateway": "us-envoy-1",
  "namespace": "envoy-test",
  "dryRun": false
}
```

---

## GRPCRoute

### Create GRPCRoute

```bash
curl -X POST http://localhost:9080/api/v1/routes/grpc \
  -H "Content-Type: application/json" \
  -d '{
    "name": "grpc-users-route",
    "targetGateway": "us-envoy-1",
    "service": "users.UserService",
    "method": "GetUser",
    "backendUrl": "grpc-users.internal.example.com",
    "backendPort": 50051,
    "hostnames": ["grpc.example.com"]
  }'
```

### List GRPCRoutes

```bash
curl "http://localhost:9080/api/v1/routes/grpc?targetGateway=us-envoy-1"
```

---

## TLSRoute

### Create TLSRoute

```bash
curl -X POST http://localhost:9080/api/v1/routes/tls \
  -H "Content-Type: application/json" \
  -d '{
    "name": "tls-passthrough",
    "targetGateway": "us-envoy-1",
    "hostnames": ["secure.example.com"],
    "backendUrl": "secure-backend.internal.example.com",
    "backendPort": 443,
    "backendTls": {"enabled": true}
  }'
```

---

## TCPRoute

### Create TCPRoute

```bash
curl -X POST http://localhost:9080/api/v1/routes/tcp \
  -H "Content-Type: application/json" \
  -d '{
    "name": "tcp-database",
    "targetGateway": "us-envoy-1",
    "backendUrl": "database.internal.example.com",
    "backendPort": 5432
  }'
```

---

## UDPRoute

### Create UDPRoute

```bash
curl -X POST http://localhost:9080/api/v1/routes/udp \
  -H "Content-Type: application/json" \
  -d '{
    "name": "udp-dns",
    "targetGateway": "us-envoy-1",
    "backendUrl": "dns.internal.example.com",
    "backendPort": 53
  }'
```

---

## Complete End-to-End Example

### Setup a Protected API in US Region

```bash
# 1. Create the HTTPRoute with backend and headers
curl -X POST http://localhost:9080/api/v1/routes/http \
  -H "Content-Type: application/json" \
  -d '{
    "name": "protected-api",
    "targetGateway": "us-envoy-1",
    "path": "/api/v1",
    "backendUrl": "api-service.internal.example.com",
    "backendPort": 443,
    "backendTls": {"enabled": true},
    "timeout": "30s",
    "requestHeadersToAdd": [{"name": "X-Gateway-ID", "value": "prod-gw-1"}],
    "responseHeadersToAdd": [
      {"name": "X-Content-Type-Options", "value": "nosniff"},
      {"name": "X-Frame-Options", "value": "DENY"}
    ],
    "responseHeadersToRemove": ["Server"]
  }'

# 2. Apply rate limiting
curl -X POST "http://localhost:9080/api/v1/policies/backend-traffic/rate-limit?targetGateway=us-envoy-1" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "api-rate-limit",
    "targetRoute": "protected-api",
    "requests": 1000,
    "unit": "Hour"
  }'

# 3. Add JWT authentication
curl -X POST "http://localhost:9080/api/v1/policies/security/jwt?targetGateway=us-envoy-1" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "api-jwt-auth",
    "targetRoute": "protected-api",
    "issuer": "https://auth.example.com",
    "jwksUri": "https://auth.example.com/.well-known/jwks.json",
    "audiences": ["api.example.com"]
  }'

# 4. Configure CORS
curl -X POST "http://localhost:9080/api/v1/policies/security/cors?targetGateway=us-envoy-1" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "api-cors",
    "targetRoute": "protected-api",
    "allowedOrigins": ["https://app.example.com"],
    "allowedMethods": ["GET", "POST", "PUT", "DELETE"],
    "allowCredentials": true
  }'

# 5. Enable access logging
curl -X POST "http://localhost:9080/api/v1/policies/logging/access-log?targetGateway=us-envoy-1" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "api-logging",
    "enabled": true,
    "format": "JSON",
    "output": "/dev/stdout"
  }'
```

---

## Response Formats

### Success Response (Route Creation)

```json
{
  "status": "created",
  "message": "HTTPRoute 'users-api' and backend created successfully",
  "routeName": "users-api",
  "backendName": "users-api-backend",
  "namespace": "envoy-test",
  "targetGateway": "us-envoy-1",
  "cluster": "envoy-eks-cluster",
  "region": "us-east-1"
}
```

### Success Response (Policy Creation)

```json
{
  "status": "created",
  "message": "Rate limit policy 'api-rate-limit' created",
  "resourceName": "api-rate-limit",
  "namespace": "envoy-test",
  "resourceType": "BackendTrafficPolicy",
  "details": {
    "requests": 100,
    "unit": "Minute",
    "targetGateway": "us-envoy-1"
  }
}
```

### Error Response

```json
{
  "detail": "Unknown target gateway: 'invalid-gateway'. Available: us-envoy-1, eu-envoy-1, ap-envoy-1"
}
```

### List Response

```json
{
  "items": [...],
  "total": 5,
  "namespace": "envoy-test"
}
```
