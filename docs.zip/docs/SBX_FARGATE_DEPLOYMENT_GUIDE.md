# SBX Environment - AWS Fargate Deployment Guide

Complete step-by-step guide to deploy the Envoy Agent API to AWS Fargate for the **SBX (Sandbox)** environment using GitHub Actions.

## Architecture Overview

```
                                    AWS Cloud (us-east-1)
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│  ┌─────────────────┐     ┌─────────────────────────────────────────────┐   │
│  │   GitHub        │     │              ECS Fargate                    │   │
│  │   Actions       │────►│  Cluster: envoy-agent-sbx                   │   │
│  │   (CI/CD)       │     │  ┌─────────────────────────────────────┐   │   │
│  └─────────────────┘     │  │    Service: envoy-agent-service-sbx │   │   │
│                          │  │    Tasks: 1 (configurable)          │   │   │
│  ┌─────────────────┐     │  │    Port: 9080                       │   │   │
│  │   Amazon ECR    │     │  └─────────────────────────────────────┘   │   │
│  │   envoy-agent   │     │                    │                        │   │
│  └─────────────────┘     └────────────────────┼────────────────────────┘   │
│                                               │                             │
│  ┌─────────────────┐                          ▼                             │
│  │ CloudWatch Logs │     ┌─────────────────────────────────────────────┐   │
│  │ /ecs/envoy-     │     │    Application Load Balancer               │   │
│  │   agent-sbx     │     │    envoy-agent-alb-sbx                      │   │
│  └─────────────────┘     │    Port: 80/443                             │   │
│                          └─────────────────────────────────────────────┘   │
│                                               │                             │
│                                               ▼                             │
│                          ┌─────────────────────────────────────────────┐   │
│                          │         EKS Cluster                         │   │
│                          │    envoy-eks-cluster-sbx                    │   │
│                          │    Namespace: envoy-sbx                     │   │
│                          └─────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────────────────┘
```

## AWS Resource Names & Values

| Resource | Name/Value |
|----------|------------|
| **ECS Cluster** | `envoy-agent-sbx` |
| **ECS Service** | `envoy-agent-service-sbx` |
| **Task Definition** | `envoy-agent-sbx` |
| **ECR Repository** | `envoy-agent` |
| **ALB Name** | `envoy-agent-alb-sbx` |
| **Target Group** | `envoy-agent-tg-sbx` |
| **CloudWatch Log Group** | `/ecs/envoy-agent-sbx` |
| **Task Execution Role** | `envoy-agent-execution-role-sbx` |
| **Task Role** | `envoy-agent-task-role-sbx` |
| **ALB Security Group** | `envoy-agent-alb-sg-sbx` |
| **Task Security Group** | `envoy-agent-task-sg-sbx` |
| **EKS Cluster** | `envoy-eks-cluster-sbx` |
| **K8s Namespace** | `envoy-sbx` |
| **AWS Region** | `us-east-1` |
| **Container Port** | `9080` |
| **Environment** | `sbx` |

---

## Prerequisites

- [ ] AWS Account with appropriate permissions
- [ ] AWS CLI installed and configured
- [ ] Docker installed locally
- [ ] GitHub repository with Actions enabled
- [ ] kubectl configured for EKS access
- [ ] VPC and Subnets available in us-east-1

---

## Step 1: Initial AWS Setup (One-time)

### 1.1 Create ECR Repository

```bash
aws ecr create-repository \
  --repository-name envoy-agent \
  --region us-east-1 \
  --profile ocelot-np
```

### 1.2 Create IAM OIDC Identity Provider for GitHub Actions

Go to AWS Console → IAM → Identity providers → Add provider:

- **Provider type**: OpenID Connect
- **Provider URL**: `https://token.actions.githubusercontent.com`
- **Audience**: `sts.amazonaws.com`

Or use AWS CLI:

```bash
aws iam create-open-id-connect-provider \
  --url https://token.actions.githubusercontent.com \
  --client-id-list sts.amazonaws.com \
  --thumbprint-list 6938fd4d98bab03faadb97b34396831e3780aea1 \
  --region us-east-1 \
  --profile ocelot-np
```

### 1.3 Create GitHub Actions Deployment Role

Create a file `github-actions-role-sbx.json`:

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Principal": {
        "Federated": "arn:aws:iam::YOUR_ACCOUNT_ID:oidc-provider/token.actions.githubusercontent.com"
      },
      "Action": "sts:AssumeRoleWithWebIdentity",
      "Condition": {
        "StringEquals": {
          "token.actions.githubusercontent.com:aud": "sts.amazonaws.com"
        },
        "StringLike": {
          "token.actions.githubusercontent.com:sub": "repo:YOUR_ORG/envoy-agent:*"
        }
      }
    }
  ]
}
```

Create the role:

```bash
# Replace YOUR_ACCOUNT_ID and YOUR_ORG with actual values
ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text --profile ocelot-np)

# Create trust policy file
cat > /tmp/github-actions-trust-policy.json << EOF
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Principal": {
        "Federated": "arn:aws:iam::${ACCOUNT_ID}:oidc-provider/token.actions.githubusercontent.com"
      },
      "Action": "sts:AssumeRoleWithWebIdentity",
      "Condition": {
        "StringEquals": {
          "token.actions.githubusercontent.com:aud": "sts.amazonaws.com"
        },
        "StringLike": {
          "token.actions.githubusercontent.com:sub": "repo:YOUR_ORG/envoy-agent:*"
        }
      }
    }
  ]
}
EOF

# Create the role
aws iam create-role \
  --role-name github-actions-envoy-agent-sbx \
  --assume-role-policy-document file:///tmp/github-actions-trust-policy.json \
  --profile ocelot-np

# Attach required policies
aws iam attach-role-policy \
  --role-name github-actions-envoy-agent-sbx \
  --policy-arn arn:aws:iam::aws:policy/AmazonECS_FullAccess \
  --profile ocelot-np

aws iam attach-role-policy \
  --role-name github-actions-envoy-agent-sbx \
  --policy-arn arn:aws:iam::aws:policy/AmazonEC2ContainerRegistryFullAccess \
  --profile ocelot-np

aws iam attach-role-policy \
  --role-name github-actions-envoy-agent-sbx \
  --policy-arn arn:aws:iam::aws:policy/CloudWatchLogsFullAccess \
  --profile ocelot-np
```

---

## Step 2: Deploy Infrastructure with CloudFormation

### 2.1 Get VPC and Subnet Information

```bash
# List VPCs
aws ec2 describe-vpcs \
  --query 'Vpcs[*].[VpcId,Tags[?Key==`Name`].Value|[0]]' \
  --output table \
  --profile ocelot-np \
  --region us-east-1

# List Subnets (choose at least 2 in different AZs for HA)
aws ec2 describe-subnets \
  --query 'Subnets[*].[SubnetId,AvailabilityZone,Tags[?Key==`Name`].Value|[0]]' \
  --output table \
  --profile ocelot-np \
  --region us-east-1
```

### 2.2 Deploy the CloudFormation Stack

```bash
cd infrastructure

# Deploy the stack (replace with your VPC and subnet IDs)
./deploy.sh sbx vpc-XXXXXXXX subnet-AAAA,subnet-BBBB
```

Or manually:

```bash
aws cloudformation deploy \
  --profile ocelot-np \
  --region us-east-1 \
  --stack-name envoy-agent-sbx \
  --template-file cloudformation.yaml \
  --parameter-overrides \
    Environment=sbx \
    VpcId=vpc-XXXXXXXX \
    SubnetIds=subnet-AAAA,subnet-BBBB \
    DesiredCount=1 \
  --capabilities CAPABILITY_NAMED_IAM \
  --no-fail-on-empty-changeset
```

### 2.3 Get Stack Outputs

```bash
aws cloudformation describe-stacks \
  --stack-name envoy-agent-sbx \
  --query 'Stacks[0].Outputs' \
  --output table \
  --profile ocelot-np \
  --region us-east-1
```

Expected outputs:
- **LoadBalancerURL**: `http://envoy-agent-alb-sbx-XXXXXXX.us-east-1.elb.amazonaws.com`
- **TaskRoleArn**: `arn:aws:iam::ACCOUNT_ID:role/envoy-agent-task-role-sbx`

---

## Step 3: Configure EKS Access

### 3.1 Apply Kubernetes RBAC

```bash
# Ensure kubectl is configured for your EKS cluster
aws eks update-kubeconfig \
  --region us-east-1 \
  --name envoy-eks-cluster-sbx \
  --profile ocelot-np

# Apply RBAC configuration
kubectl apply -f infrastructure/eks-rbac.yaml
```

### 3.2 Update aws-auth ConfigMap

```bash
# Get the Task Role ARN from CloudFormation outputs
TASK_ROLE_ARN=$(aws cloudformation describe-stacks \
  --stack-name envoy-agent-sbx \
  --query "Stacks[0].Outputs[?OutputKey=='TaskRoleArn'].OutputValue" \
  --output text \
  --profile ocelot-np \
  --region us-east-1)

# Update aws-auth
./infrastructure/update-aws-auth.sh $TASK_ROLE_ARN envoy-eks-cluster-sbx
```

Or manually edit:

```bash
kubectl edit configmap aws-auth -n kube-system
```

Add the following to `mapRoles`:

```yaml
- rolearn: arn:aws:iam::ACCOUNT_ID:role/envoy-agent-task-role-sbx
  username: envoy-agent
  groups:
    - envoy-agent-group
```

---

## Step 4: Configure GitHub Actions

### 4.1 Add GitHub Secrets

Go to your GitHub repository → Settings → Secrets and variables → Actions

Add the following secrets:

| Secret Name | Value |
|-------------|-------|
| `AWS_ROLE_ARN_SBX` | `arn:aws:iam::YOUR_ACCOUNT_ID:role/github-actions-envoy-agent-sbx` |

**Alternative (IAM Keys method - less secure):**

| Secret Name | Value |
|-------------|-------|
| `AWS_ACCESS_KEY_ID` | Your IAM access key ID |
| `AWS_SECRET_ACCESS_KEY` | Your IAM secret access key |

### 4.2 GitHub Actions Workflow

The workflow file is already configured at `.github/workflows/deploy-sbx.yaml`.

**Automatic Deployment Triggers:**
- Push to `sbx` branch
- Push to `develop` branch (with changes in `app/`, `requirements.txt`, or `infrastructure/Dockerfile`)

**Manual Deployment:**
1. Go to GitHub → Actions → "Deploy to SBX Environment"
2. Click "Run workflow"
3. Optionally set the number of tasks
4. Click "Run workflow"

---

## Step 5: First Deployment

### Option A: Using GitHub Actions (Recommended)

```bash
# Push to sbx branch to trigger deployment
git checkout -b sbx
git push origin sbx

# Or trigger manually using GitHub CLI
gh workflow run deploy-sbx.yaml -f desired_count=1
```

### Option B: Using deploy.sh Script

```bash
cd infrastructure
./deploy.sh sbx vpc-XXXXXXXX subnet-AAAA,subnet-BBBB
```

---

## Step 6: Verify Deployment

### 6.1 Check ECS Service

```bash
aws ecs describe-services \
  --cluster envoy-agent-sbx \
  --services envoy-agent-service-sbx \
  --query 'services[0].{Status:status,DesiredCount:desiredCount,RunningCount:runningCount,Deployments:deployments[0].status}' \
  --output table \
  --profile ocelot-np \
  --region us-east-1
```

### 6.2 Check Running Tasks

```bash
aws ecs list-tasks \
  --cluster envoy-agent-sbx \
  --service-name envoy-agent-service-sbx \
  --profile ocelot-np \
  --region us-east-1
```

### 6.3 Test the API

```bash
# Get the ALB URL
ALB_URL=$(aws cloudformation describe-stacks \
  --stack-name envoy-agent-sbx \
  --query "Stacks[0].Outputs[?OutputKey=='LoadBalancerURL'].OutputValue" \
  --output text \
  --profile ocelot-np \
  --region us-east-1)

# Health check
curl ${ALB_URL}/health

# API Info
curl ${ALB_URL}/info

# Swagger UI (open in browser)
echo "Swagger UI: ${ALB_URL}/docs"
```

---

## Useful Commands

### View Logs

```bash
# Tail logs
aws logs tail /ecs/envoy-agent-sbx --follow --profile ocelot-np --region us-east-1

# View last 30 minutes
aws logs tail /ecs/envoy-agent-sbx --since 30m --profile ocelot-np --region us-east-1
```

### Scale Service

```bash
# Scale to 2 tasks
aws ecs update-service \
  --cluster envoy-agent-sbx \
  --service envoy-agent-service-sbx \
  --desired-count 2 \
  --profile ocelot-np \
  --region us-east-1
```

### Force New Deployment

```bash
aws ecs update-service \
  --cluster envoy-agent-sbx \
  --service envoy-agent-service-sbx \
  --force-new-deployment \
  --profile ocelot-np \
  --region us-east-1
```

### Delete Stack (Cleanup)

```bash
aws cloudformation delete-stack \
  --stack-name envoy-agent-sbx \
  --profile ocelot-np \
  --region us-east-1
```

---

## Troubleshooting

### Task Failing to Start

```bash
# Check task stopped reason
aws ecs describe-tasks \
  --cluster envoy-agent-sbx \
  --tasks $(aws ecs list-tasks --cluster envoy-agent-sbx --desired-status STOPPED --query 'taskArns[0]' --output text --profile ocelot-np --region us-east-1) \
  --profile ocelot-np \
  --region us-east-1
```

### Health Check Failing

1. Check if security groups allow traffic on port 9080
2. Verify the container starts correctly (check CloudWatch logs)
3. Test health endpoint: `curl http://localhost:9080/health`

### EKS Access Issues

```bash
# Verify the task role can describe EKS cluster
aws eks describe-cluster \
  --name envoy-eks-cluster-sbx \
  --query 'cluster.endpoint' \
  --output text \
  --profile ocelot-np \
  --region us-east-1
```

---

## Environment Variables

| Variable | Value | Description |
|----------|-------|-------------|
| `ENVOY_AGENT_ENV` | `sbx` | Environment name |
| `ENVOY_AGENT_PORT` | `9080` | API port |
| `ENVOY_AGENT_DEBUG` | `true` | Enable debug mode |
| `ENVOY_AGENT_LOG_LEVEL` | `DEBUG` | Log level |

---

## Resource Sizing

**SBX Environment (Default):**
- CPU: 256 (0.25 vCPU)
- Memory: 512 MB
- Tasks: 1

**To change sizing**, update `infrastructure/task-definition-sbx.json` or CloudFormation parameters.

---

## Cost Estimation (SBX)

| Resource | Estimated Cost |
|----------|---------------|
| Fargate (1 task, 0.25 vCPU, 512MB) | ~$10/month |
| ALB | ~$16/month |
| CloudWatch Logs | ~$1/month |
| **Total** | **~$27/month** |

---

## Next Steps

After successfully deploying to SBX:

1. Test all API endpoints
2. Verify EKS connectivity
3. Monitor CloudWatch logs for errors
4. Promote to DEV environment when ready
