# Envoy Gateway Agent API - Mermaid Diagrams

These diagrams can be rendered in GitHub, GitLab, or any Mermaid-compatible viewer.

## 1. System Architecture

```mermaid
flowchart TB
    subgraph Clients
        CLI[CLI Tools]
        UI[Web UI]
        AUTO[Automation]
    end

    subgraph API["Envoy Agent API"]
        FW[FastAPI]
        
        subgraph Routers
            RR[Routes Router]
            BR[Backends Router]
            PR[Policies Router]
            SR[Secrets Router]
            OR[OpenAPI Router]
            AM[API Management Router]
        end
        
        subgraph Services
            K8S[K8s Client]
            RM[Resource Manager]
        end
    end

    subgraph Kubernetes["Kubernetes / EKS"]
        subgraph Resources
            RT[Routes]
            BK[Backends]
            PL[Policies]
            SC[Secrets]
        end
        
        EG[Envoy Gateway]
        EP[Envoy Proxies]
    end

    CLI --> FW
    UI --> FW
    AUTO --> FW
    
    FW --> RR
    FW --> BR
    FW --> PR
    FW --> SR
    FW --> OR
    FW --> AM
    
    RR --> RM
    BR --> RM
    PR --> RM
    SR --> RM
    OR --> RM
    AM --> RM
    
    RM --> K8S
    K8S --> Resources
    
    Resources --> EG
    EG --> EP
```

## 2. Request Flow

```mermaid
sequenceDiagram
    participant C as Client
    participant A as API
    participant V as Validator
    participant R as Router
    participant S as Service
    participant K as Kubernetes

    C->>A: POST /api/v1/routes/http
    A->>V: Validate Request (Pydantic)
    V-->>A: Valid
    A->>R: routes_router.create_http_route()
    R->>S: resource_manager.create_custom_resource()
    S->>S: get_k8s_client()
    S->>K: Create HTTPRoute CRD
    K-->>S: Created
    S-->>R: Success
    R-->>A: ResourceResponse
    A-->>C: 201 Created
```

## 3. Policy Types

```mermaid
mindmap
  root((Policies))
    BackendTrafficPolicy
      Rate Limiting
      Circuit Breaker
      Retry
      Timeout
      Health Check
      Load Balancing
    SecurityPolicy
      JWT Auth
      OIDC Auth
      Basic Auth
      API Key Auth
      CORS
      External Auth
      IP Allowlist
      IP Blocklist
    ClientTrafficPolicy
      TLS Settings
      HTTP/2 Config
      Timeouts
      Headers
    EnvoyExtensionPolicy
      WASM
      External Processor
    EnvoyPatchPolicy
      Custom Patches
    EnvoyProxy Logging
      Access Logging
      JSON Logging
      OpenTelemetry OTLP
    HTTPRoute Headers
      Request Header Add
      Request Header Set
      Request Header Remove
      Response Header Add
      Response Header Set
      Response Header Remove
```

## 4. Route Types

```mermaid
graph LR
    subgraph Routes
        HTTP[HTTPRoute]
        GRPC[GRPCRoute]
        TLS[TLSRoute]
        TCP[TCPRoute]
        UDP[UDPRoute]
    end

    subgraph Config
        HTTP --> |path, backend| H1["/api/v1/*"]
        GRPC --> |service, method| G1["grpc.Service/Method"]
        TLS --> |hostnames| T1["*.example.com"]
        TCP --> |port| TC1["Port 5432"]
        UDP --> |port| U1["Port 53"]
    end
```

## 5. Complete API Endpoints

```mermaid
graph TD
    API["/api/v1"]
    
    API --> Routes["/routes"]
    API --> Backends["/backends"]
    API --> Policies["/policies"]
    API --> Secrets["/secrets"]
    API --> OpenAPI["/openapi"]
    API --> APIMgmt["/api, /apis"]
    
    Routes --> HTTP["/http"]
    Routes --> GRPC["/grpc"]
    Routes --> TLS["/tls"]
    Routes --> TCP["/tcp"]
    Routes --> UDP["/udp"]
    
    HTTP --> HTTP_CRUD["CRUD + /with-backend"]
    
    Backends --> Services["/services"]
    Backends --> Backend_CRUD["CRUD + /fqdn"]
    Services --> SVC_CRUD["CRUD + /external"]
    
    Policies --> BTP["/backend-traffic"]
    Policies --> SP["/security"]
    Policies --> CTP["/client-traffic"]
    Policies --> EPP["/envoy-patch"]
    Policies --> EEP["/envoy-extension"]
    
    BTP --> BTP_Simple["/rate-limit, /circuit-breaker, /retry"]
    SP --> SP_Simple["/jwt, /cors, /api-key, /basic-auth"]
    SP --> SP_IP["/ip-allowlist, /ip-blocklist"]
    SP --> SP_Ext["/external-auth"]
    CTP --> CTP_Simple["/tls, /timeout"]
    EEP --> EEP_Simple["/wasm, /ext-proc"]
    
    Policies --> LOG["/logging"]
    LOG --> LOG_Simple["/access-log, /otlp"]
    
    Secrets --> SEC_Types["/tls, /basic-auth, /oidc, /api-keys"]
    
    OpenAPI --> OA_Import["/import, /import/url, /import/file"]
    OpenAPI --> OA_Routes["/routes"]
    
    APIMgmt --> APIMgmt_CRUD["POST /api, GET /apis, GET /apis/{pathName}"]
    APIMgmt --> APIMgmt_Single["GET/PUT/DELETE /api/{name}"]
```

## 6. Data Flow Example

```mermaid
flowchart LR
    subgraph Step1["1. Create Backend"]
        B1[POST /backends/services/external]
        B2[ExternalName Service]
        B1 --> B2
    end
    
    subgraph Step2["2. Create Route"]
        R1[POST /routes/http]
        R2[HTTPRoute]
        R1 --> R2
    end
    
    subgraph Step3["3. Apply Rate Limit"]
        P1[POST /policies/backend-traffic/rate-limit]
        P2[BackendTrafficPolicy]
        P1 --> P2
    end
    
    subgraph Step4["4. Add JWT Auth"]
        J1[POST /policies/security/jwt]
        J2[SecurityPolicy]
        J1 --> J2
    end
    
    Step1 --> Step2 --> Step3 --> Step4
    
    subgraph Result["Traffic Flow"]
        C[Client] --> EG[Envoy Gateway]
        EG --> |"1. Match Route"| R2
        EG --> |"2. Validate JWT"| J2
        EG --> |"3. Check Rate Limit"| P2
        EG --> |"4. Forward"| B2
    end
    
    Step4 --> Result
```

## 7. Deployment View

```mermaid
C4Deployment
    title Deployment Diagram
    
    Deployment_Node(eks, "EKS Cluster", "AWS") {
        Deployment_Node(ns1, "envoy-agent-ns", "Namespace") {
            Container(api, "Envoy Agent API", "Python/FastAPI", "Manages Envoy Gateway resources")
        }
        
        Deployment_Node(ns2, "envoy-gateway-system", "Namespace") {
            Container(eg, "Envoy Gateway", "Controller", "Watches CRDs, configures proxies")
            Container(ep, "Envoy Proxies", "Envoy", "Handles traffic")
        }
    }
    
    Rel(api, eg, "Creates CRDs", "K8s API")
    Rel(eg, ep, "Configures", "xDS")
```

## 8. Class Diagram

```mermaid
classDiagram
    class FastAPI {
        +routes_router
        +backends_router
        +policies_router
        +secrets_router
        +openapi_router
    }
    
    class ResourceManager {
        +create_custom_resource()
        +get_custom_resource()
        +list_custom_resources()
        +update_custom_resource()
        +delete_custom_resource()
        +create_service()
        +create_secret()
    }
    
    class K8sClientManager {
        +get_custom_objects_api()
        +get_core_v1_api()
        +health_check()
        -_get_eks_token()
        -_ensure_client()
    }
    
    class HTTPRouteCreate {
        +name: str
        +path: str
        +gateway_name: str
        +backend_name: str
        +backend_port: int
    }
    
    class BackendTrafficPolicy {
        +rate_limit
        +circuit_breaker
        +retry
        +timeout
        +health_check
    }
    
    class SecurityPolicy {
        +jwt
        +oidc
        +basic_auth
        +api_key
        +cors
        +ext_auth
        +authorization
    }
    
    class EnvoyProxy {
        +telemetry
        +access_logging
    }
    
    class HTTPRouteFilters {
        +request_headers_to_add
        +request_headers_to_set
        +request_headers_to_remove
        +response_headers_to_add
        +response_headers_to_set
        +response_headers_to_remove
    }
    
    class OpenAPIParser {
        +spec: Dict
        +version: str
        +title: str
        +parse_routes()
        +generate_route_name()
        +get_info()
    }
    
    FastAPI --> ResourceManager
    FastAPI --> OpenAPIParser
    ResourceManager --> K8sClientManager
    ResourceManager ..> HTTPRouteCreate : creates
    ResourceManager ..> BackendTrafficPolicy : creates
    ResourceManager ..> SecurityPolicy : creates
    ResourceManager ..> EnvoyProxy : creates
    HTTPRouteCreate --> HTTPRouteFilters : uses
    OpenAPIParser ..> HTTPRouteCreate : generates
```
