"""
API Management V2 - Unified endpoint that accepts BOTH payload formats.

This router accepts:
1. API Management format (api-gateway wrapper)
2. Routes/HTTP format (flat payload with backendName/backendPort)

Endpoints:
  POST /api/v2/api — Create API (accepts both formats)

The payload format is auto-detected and routed to shared services.
"""

import logging
from typing import Any, Dict, List, Optional, Union
from urllib.parse import urlparse

from fastapi import APIRouter, Body, HTTPException, Query, Response
from pydantic import BaseModel, Field, validator, root_validator
from kubernetes.client.rest import ApiException

from ..models.routes import (
    URLRewrite,
    BackendTLSConfig,
    PathMatchType,
    HTTPMethodType,
)
from ..models.api_management import (
    ApiGatewayConfig,
    ApiCreatedResource,
)
from ..models.common import ErrorResponse
from ..services.resource_manager import ResourceManager
from ..services.backend_service import (
    create_backend,
    backend_exists,
    parse_upstream_url,
)
from ..config import get_gateway_config
from ..utils.helpers import build_target_ref

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v2", tags=["API Management V2"])

# Label keys
API_NAME_LABEL = "envoy-agent.io/api-name"
MANAGED_BY_LABEL = "envoy-agent.io/managed-by"
MANAGED_BY_VALUE = "api-management-v2"


def get_resource_manager(target_gateway: str) -> ResourceManager:
    """Get a resource manager for the specified target gateway."""
    return ResourceManager(target_gateway=target_gateway)


# ==================== Unified Payload Models ====================

class UnifiedUpstream(BaseModel):
    """Upstream configuration (for api-gateway format)."""
    url: str = Field(..., description="Backend URL")
    tls_certificate: Optional[str] = Field(None, alias="tls-certificate")

    class Config:
        populate_by_name = True


class UnifiedApiGatewayConfig(BaseModel):
    """API Gateway format payload."""
    name: str = Field(..., min_length=1, max_length=253)
    description: Optional[str] = Field(None)
    api_type: Optional[str] = Field("http", alias="api-type")
    policy_payload: Optional[List[Dict[str, Any]]] = Field(None, alias="policy-payload")
    tags: Optional[List[str]] = Field(None)
    upstream: UnifiedUpstream
    target_gateway: str = Field(..., alias="target-gateway")
    path: str
    hostnames: Optional[List[str]] = Field(None)
    url_rewrite: Optional[URLRewrite] = Field(None, alias="urlRewrite")
    timeout: Optional[str] = Field(None)

    class Config:
        populate_by_name = True


class UnifiedRouteConfig(BaseModel):
    """Routes/HTTP format payload (flat structure)."""
    name: str = Field(..., min_length=1, max_length=253)
    target_gateway: str = Field(..., alias="targetGateway")
    path: str
    backend_name: str = Field(..., alias="backendName")
    backend_port: int = Field(default=443, alias="backendPort")
    backend_tls: Optional[BackendTLSConfig] = Field(None, alias="backendTls")
    path_type: Optional[PathMatchType] = Field(PathMatchType.PATH_PREFIX, alias="pathType")
    hostnames: Optional[List[str]] = Field(None)
    methods: Optional[List[HTTPMethodType]] = Field(None)
    timeout: Optional[str] = Field(None)
    url_rewrite: Optional[URLRewrite] = Field(None, alias="urlRewrite")
    labels: Optional[Dict[str, str]] = Field(None)
    # Optional fields for backend creation
    backend_url: Optional[str] = Field(None, alias="backendUrl", description="If provided, creates the backend")

    class Config:
        populate_by_name = True


class UnifiedCreateRequest(BaseModel):
    """
    Unified request that accepts BOTH formats.
    
    Format 1 (API Management):
    ```json
    {
        "api-gateway": {
            "name": "my-api",
            "description": "...",
            "api-type": "http",
            "upstream": {"url": "http://backend:8080"},
            "target-gateway": "us-envoy-1",
            "path": "/my-api"
        }
    }
    ```
    
    Format 2 (Routes/HTTP - flat):
    ```json
    {
        "name": "my-route",
        "targetGateway": "us-envoy-1",
        "path": "/my-path",
        "backendName": "my-backend",
        "backendPort": 443,
        "hostnames": ["example.com"],
        "urlRewrite": {...}
    }
    ```
    """
    # API Gateway format fields
    api_gateway: Optional[UnifiedApiGatewayConfig] = Field(None, alias="api-gateway")
    swagger: Optional[Dict[str, Any]] = Field(None)
    
    # Routes/HTTP format fields (flat)
    name: Optional[str] = Field(None)
    target_gateway: Optional[str] = Field(None, alias="targetGateway")
    path: Optional[str] = Field(None)
    backend_name: Optional[str] = Field(None, alias="backendName")
    backend_port: Optional[int] = Field(None, alias="backendPort")
    backend_tls: Optional[BackendTLSConfig] = Field(None, alias="backendTls")
    path_type: Optional[PathMatchType] = Field(None, alias="pathType")
    hostnames: Optional[List[str]] = Field(None)
    methods: Optional[List[HTTPMethodType]] = Field(None)
    timeout: Optional[str] = Field(None)
    url_rewrite: Optional[URLRewrite] = Field(None, alias="urlRewrite")
    labels: Optional[Dict[str, str]] = Field(None)
    backend_url: Optional[str] = Field(None, alias="backendUrl")

    class Config:
        populate_by_name = True

    def is_api_gateway_format(self) -> bool:
        """Check if payload is in api-gateway format."""
        return self.api_gateway is not None

    def is_routes_format(self) -> bool:
        """Check if payload is in routes/http flat format."""
        return self.name is not None and self.backend_name is not None


class UnifiedApiResponse(BaseModel):
    """Response model for unified API creation."""
    status: str
    message: str
    api_name: str = Field(..., alias="apiName")
    namespace: str
    target_gateway: str = Field(..., alias="targetGateway")
    resources_created: List[ApiCreatedResource] = Field(default_factory=list, alias="resourcesCreated")
    errors: Optional[List[str]] = None
    details: Optional[Dict[str, Any]] = None
    payload_format: str = Field(..., alias="payloadFormat", description="Detected format: 'api-gateway' or 'routes-http'")

    class Config:
        populate_by_name = True


# ==================== Helper Functions ====================

def _build_labels(api_name: str, extra_labels: Optional[Dict[str, str]] = None) -> Dict[str, str]:
    """Build standard labels."""
    labels = {
        API_NAME_LABEL: api_name,
        MANAGED_BY_LABEL: MANAGED_BY_VALUE,
    }
    if extra_labels:
        labels.update(extra_labels)
    return labels


def _build_parent_ref(gateway_name: str) -> dict:
    """Build a parent reference for a route."""
    return {
        "group": "gateway.networking.k8s.io",
        "kind": "Gateway",
        "name": gateway_name,
    }


def _build_backend_ref(name: str, port: int) -> dict:
    """Build a backend reference for a route."""
    return {
        "group": "gateway.envoyproxy.io",
        "kind": "Backend",
        "name": name,
        "port": port,
    }


def _normalize_path(path: str) -> str:
    """Normalize path to start with /."""
    if not path.startswith("/"):
        path = f"/{path}"
    return path


# ==================== Unified Create Endpoint ====================

@router.post(
    "/api",
    response_model=UnifiedApiResponse,
    status_code=201,
    responses={409: {"model": ErrorResponse}, 422: {"model": ErrorResponse}},
    summary="Create API (Unified - accepts both formats)",
    description="""
Create an API using **either** payload format:

---

## Format 1: API Management (api-gateway wrapper)

```json
{
    "api-gateway": {
        "name": "my-api",
        "description": "My API description",
        "api-type": "http",
        "upstream": {
            "url": "http://my-backend.internal:8080",
            "tls-certificate": "optional-tls-secret"
        },
        "target-gateway": "us-envoy-1",
        "path": "/my-api",
        "hostnames": ["api.example.com"],
        "urlRewrite": {
            "hostname": {"type": "Static", "staticValue": "backend.internal"}
        },
        "policy-payload": [
            {"type": "JWT-validation", "name": "my-jwt"},
            {"type": "rate-limit", "requests": 100, "unit": "Minute"}
        ]
    }
}
```

---

## Format 2: Routes/HTTP (flat structure)

```json
{
    "name": "my-route",
    "targetGateway": "us-envoy-1",
    "path": "/my-path",
    "backendName": "my-backend",
    "backendPort": 443,
    "backendTls": {"enabled": true},
    "hostnames": ["api.example.com"],
    "urlRewrite": {
        "hostname": {"type": "Static", "staticValue": "backend.internal"}
    },
    "timeout": "30s"
}
```

---

The endpoint auto-detects the format and processes accordingly.
Both formats create Backend CRD + HTTPRoute using shared services.
""",
)
def create_unified_api(
    response: Response,
    payload: UnifiedCreateRequest = Body(...),
):
    """Create API accepting both api-gateway and routes/http formats."""
    
    # Detect payload format
    if payload.is_api_gateway_format():
        return _handle_api_gateway_format(response, payload)
    elif payload.is_routes_format():
        return _handle_routes_format(response, payload)
    else:
        raise HTTPException(
            status_code=422,
            detail={
                "error": "Invalid payload format",
                "message": "Payload must be either api-gateway format (with 'api-gateway' key) "
                          "or routes/http format (with 'name' and 'backendName' fields)",
                "examples": {
                    "api-gateway-format": {
                        "api-gateway": {
                            "name": "my-api",
                            "description": "...",
                            "api-type": "http",
                            "upstream": {"url": "http://backend:8080"},
                            "target-gateway": "us-envoy-1",
                            "path": "/my-api"
                        }
                    },
                    "routes-http-format": {
                        "name": "my-route",
                        "targetGateway": "us-envoy-1",
                        "path": "/my-path",
                        "backendName": "my-backend",
                        "backendPort": 443
                    }
                }
            }
        )


def _handle_api_gateway_format(response: Response, payload: UnifiedCreateRequest) -> UnifiedApiResponse:
    """Handle api-gateway format payload."""
    config = payload.api_gateway
    
    try:
        rm = get_resource_manager(config.target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    
    gateway_config = get_gateway_config(config.target_gateway)
    
    # Check if route already exists
    if rm.resource_exists("HTTPRoute", config.name):
        raise HTTPException(status_code=409, detail=f"API '{config.name}' already exists")
    
    created_resources = []
    errors = []
    path = _normalize_path(config.path)
    backend_name = f"{config.name}-backend"
    
    # Parse upstream
    hostname, backend_port, uses_tls = parse_upstream_url(config.upstream.url)
    
    labels = _build_labels(config.name)
    annotations = {
        "envoy-agent.io/api-description": config.description or "",
        "envoy-agent.io/api-type": config.api_type or "http",
    }
    
    # Step 1: Create Backend using shared service
    try:
        if not backend_exists(rm, backend_name):
            create_backend(
                rm=rm,
                name=backend_name,
                upstream_url=config.upstream.url,
                labels=labels.copy(),
                tls_certificate=config.upstream.tls_certificate,
            )
            created_resources.append(ApiCreatedResource(
                resource_type="Backend",
                resource_name=backend_name,
                status="created",
            ))
    except Exception as e:
        logger.exception("Failed to create Backend '%s'", backend_name)
        errors.append(f"Failed to create Backend: {str(e)}")
    
    # Step 2: Create HTTPRoute
    try:
        parent_ref = _build_parent_ref(gateway_config.gateway_name)
        backend_ref = _build_backend_ref(backend_name, backend_port)
        
        match_rule = {"path": {"type": "PathPrefix", "value": path}}
        rule: Dict[str, Any] = {
            "matches": [match_rule],
            "backendRefs": [backend_ref],
        }
        
        # Add timeout if specified
        if config.timeout:
            rule["timeouts"] = {"request": config.timeout}
        
        # Add URL rewrite filter if specified
        if config.url_rewrite:
            filter_spec = config.url_rewrite.to_filter_spec()
            if filter_spec:
                rule["filters"] = [filter_spec]
        
        spec: Dict[str, Any] = {
            "parentRefs": [parent_ref],
            "rules": [rule],
        }
        
        if config.hostnames:
            spec["hostnames"] = config.hostnames
        
        rm.create_custom_resource(
            kind="HTTPRoute",
            name=config.name,
            spec=spec,
            labels=labels,
            annotations=annotations,
        )
        created_resources.append(ApiCreatedResource(
            resource_type="HTTPRoute",
            resource_name=config.name,
            status="created",
        ))
    except ApiException as e:
        logger.exception("Failed to create HTTPRoute '%s'", config.name)
        errors.append(f"Failed to create HTTPRoute: {e.body}")
        raise HTTPException(status_code=422, detail=f"Failed to create route: {e.body}")
    
    if errors:
        response.status_code = 206
    
    return UnifiedApiResponse(
        status="created" if not errors else "partial",
        message=f"API '{config.name}' created successfully",
        api_name=config.name,
        namespace=rm.namespace,
        target_gateway=config.target_gateway,
        resources_created=created_resources,
        errors=errors if errors else None,
        payload_format="api-gateway",
        details={
            "path": path,
            "backendName": backend_name,
            "upstreamUrl": config.upstream.url,
            "hostnames": config.hostnames,
            "hasUrlRewrite": config.url_rewrite is not None,
        },
    )


def _handle_routes_format(response: Response, payload: UnifiedCreateRequest) -> UnifiedApiResponse:
    """Handle routes/http flat format payload."""
    
    try:
        rm = get_resource_manager(payload.target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    
    gateway_config = get_gateway_config(payload.target_gateway)
    
    # Check if route already exists
    if rm.resource_exists("HTTPRoute", payload.name):
        raise HTTPException(status_code=409, detail=f"Route '{payload.name}' already exists")
    
    created_resources = []
    errors = []
    path = _normalize_path(payload.path)
    backend_name = payload.backend_name
    backend_port = payload.backend_port or 443
    
    labels = _build_labels(payload.name, payload.labels)
    
    # Step 1: Create Backend if it doesn't exist
    try:
        if not backend_exists(rm, backend_name):
            # Build backend TLS config if specified
            backend_tls_spec = None
            if payload.backend_tls and payload.backend_tls.enabled:
                backend_tls_spec = {}
                if payload.backend_tls.ca_secret:
                    backend_tls_spec["caCertificateRefs"] = [
                        {"name": payload.backend_tls.ca_secret, "kind": "Secret"}
                    ]
                if payload.backend_tls.certificate_secret:
                    backend_tls_spec["clientCertificateRef"] = {
                        "name": payload.backend_tls.certificate_secret, "kind": "Secret"
                    }
            
            # Extract hostname from backendName or use provided backendUrl
            # For routes format, we need to create backend with the hostname
            # Try to extract from hostnames if urlRewrite has static hostname
            upstream_hostname = None
            if payload.url_rewrite and payload.url_rewrite.hostname:
                if payload.url_rewrite.hostname.static_value:
                    upstream_hostname = payload.url_rewrite.hostname.static_value
            
            if payload.backend_url:
                # If backendUrl provided, use it
                create_backend(
                    rm=rm,
                    name=backend_name,
                    upstream_url=payload.backend_url,
                    labels=labels.copy(),
                    backend_tls=backend_tls_spec,
                )
            elif upstream_hostname:
                # Use the rewrite hostname as backend target
                uses_tls = payload.backend_tls.enabled if payload.backend_tls else (backend_port == 443)
                scheme = "https" if uses_tls else "http"
                upstream_url = f"{scheme}://{upstream_hostname}:{backend_port}"
                create_backend(
                    rm=rm,
                    name=backend_name,
                    upstream_url=upstream_url,
                    labels=labels.copy(),
                    backend_tls=backend_tls_spec,
                )
            else:
                # Create backend with just hostname/port (no full URL)
                uses_tls = payload.backend_tls.enabled if payload.backend_tls else (backend_port == 443)
                create_backend(
                    rm=rm,
                    name=backend_name,
                    hostname=backend_name.replace("-backend", ""),  # Extract service name
                    port=backend_port,
                    labels=labels.copy(),
                    backend_tls=backend_tls_spec,
                    uses_tls=uses_tls,
                )
            
            created_resources.append(ApiCreatedResource(
                resource_type="Backend",
                resource_name=backend_name,
                status="created",
            ))
    except Exception as e:
        logger.exception("Failed to create Backend '%s'", backend_name)
        errors.append(f"Failed to create Backend: {str(e)}")
    
    # Step 2: Create HTTPRoute
    try:
        parent_ref = _build_parent_ref(gateway_config.gateway_name)
        backend_ref = _build_backend_ref(backend_name, backend_port)
        
        # Build match rule
        path_type = payload.path_type.value if payload.path_type else "PathPrefix"
        match_rule: Dict[str, Any] = {
            "path": {"type": path_type, "value": path}
        }
        
        # Add method if specified
        if payload.methods and len(payload.methods) > 0:
            match_rule["method"] = payload.methods[0].value
        
        rule: Dict[str, Any] = {
            "matches": [match_rule],
            "backendRefs": [backend_ref],
        }
        
        # Add timeout if specified
        if payload.timeout:
            rule["timeouts"] = {"request": payload.timeout}
        
        # Add URL rewrite filter if specified
        if payload.url_rewrite:
            filter_spec = payload.url_rewrite.to_filter_spec()
            if filter_spec:
                rule["filters"] = [filter_spec]
        
        spec: Dict[str, Any] = {
            "parentRefs": [parent_ref],
            "rules": [rule],
        }
        
        if payload.hostnames:
            spec["hostnames"] = payload.hostnames
        
        route_labels = labels.copy()
        route_labels["envoy-agent.io/backend"] = backend_name
        
        rm.create_custom_resource(
            kind="HTTPRoute",
            name=payload.name,
            spec=spec,
            labels=route_labels,
        )
        created_resources.append(ApiCreatedResource(
            resource_type="HTTPRoute",
            resource_name=payload.name,
            status="created",
        ))
    except ApiException as e:
        logger.exception("Failed to create HTTPRoute '%s'", payload.name)
        errors.append(f"Failed to create HTTPRoute: {e.body}")
        raise HTTPException(status_code=422, detail=f"Failed to create route: {e.body}")
    
    if errors:
        response.status_code = 206
    
    return UnifiedApiResponse(
        status="created" if not errors else "partial",
        message=f"Route '{payload.name}' created successfully",
        api_name=payload.name,
        namespace=rm.namespace,
        target_gateway=payload.target_gateway,
        resources_created=created_resources,
        errors=errors if errors else None,
        payload_format="routes-http",
        details={
            "path": path,
            "backendName": backend_name,
            "backendPort": backend_port,
            "hostnames": payload.hostnames,
            "hasUrlRewrite": payload.url_rewrite is not None,
            "hasTls": payload.backend_tls.enabled if payload.backend_tls else False,
            "timeout": payload.timeout,
        },
    )
