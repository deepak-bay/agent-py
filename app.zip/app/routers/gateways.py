"""
API routes for Gateway configuration and information.
"""

from fastapi import APIRouter, HTTPException, Query
from typing import Optional

from ..config import get_gateway_config, get_available_gateways

router = APIRouter(prefix="/gateways", tags=["Gateways"])


@router.get(
    "",
    summary="List available target gateways",
    description="Get a list of all configured target gateways and their cluster information.",
)
def list_available_gateways():
    """List all available target gateways."""
    gateways = get_available_gateways()
    result = []
    for name, config in gateways.items():
        result.append({
            "name": name,
            "region": config.aws_region,
            "cluster": config.eks_cluster_name,
            "namespace": config.k8s_namespace,
            "gatewayName": config.gateway_name,
        })
    return {"gateways": result, "total": len(result)}


@router.get(
    "/{gateway_id}",
    summary="Get target gateway details",
    description="Get detailed information about a specific target gateway.",
)
def get_gateway_details(gateway_id: str):
    """Get details of a specific target gateway."""
    try:
        config = get_gateway_config(gateway_id)
        return {
            "name": gateway_id,
            "region": config.aws_region,
            "cluster": config.eks_cluster_name,
            "namespace": config.k8s_namespace,
            "gatewayName": config.gateway_name,
            "gatewayClass": config.gateway_class,
        }
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
