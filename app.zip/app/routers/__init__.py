"""
API Routers for the Envoy Gateway Agent API.
"""

from .routes import router as routes_router
from .backends import router as backends_router
from .policies import router as policies_router
from .secrets import router as secrets_router
from .openapi_import import router as openapi_router
from .gateways import router as gateways_router
from .ai_gateway import router as ai_gateway_router
from .api_management import router as api_management_router
from .api_management_v2 import router as api_management_v2_router
from .configmaps import router as configmaps_router

__all__ = [
    "routes_router",
    "backends_router",
    "policies_router",
    "secrets_router",
    "openapi_router",
    "gateways_router",
    "ai_gateway_router",
    "api_management_router",
    "api_management_v2_router",
    "configmaps_router",
]
