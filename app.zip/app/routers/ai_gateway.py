"""
API routes for AI Gateway management.
Provides endpoints for managing AI/LLM service backends, routes, and policies
for providers like OpenAI, Azure OpenAI, AWS Bedrock, and custom AI services.
"""

from fastapi import APIRouter, HTTPException, Query
from typing import Optional
from kubernetes.client.rest import ApiException

from ..models.ai_gateway import (
    AIBackendCreate, AIBackendResponse,
    AIRouteCreate, AIRouteResponse,
    AITokenRateLimitCreate,
    AIModelRoutingCreate,
    AIAPIKeyAuthCreate,
    AIProvider,
)
from ..models.common import ResourceResponse, ResourceListResponse, ErrorResponse
from ..services.resource_manager import ResourceManager
from ..utils.helpers import build_target_ref
from ..config import get_gateway_config

router = APIRouter(prefix="/ai-gateway", tags=["AI Gateway"])


# Provider endpoint mappings
AI_PROVIDER_ENDPOINTS = {
    AIProvider.OPENAI: "api.openai.com",
    AIProvider.AZURE_OPENAI: None,  # Requires deployment-specific endpoint
    AIProvider.AWS_BEDROCK: None,   # Requires region-specific endpoint
    AIProvider.CUSTOM: None,        # Must be provided by user
}


def get_resource_manager(target_gateway: str) -> ResourceManager:
    """Get resource manager for the specified target gateway."""
    return ResourceManager(target_gateway=target_gateway)


def resolve_ai_endpoint(payload: AIBackendCreate) -> str:
    """Resolve the API endpoint hostname for an AI provider."""
    if payload.api_endpoint:
        # Strip protocol if present
        endpoint = payload.api_endpoint
        for prefix in ["https://", "http://"]:
            if endpoint.startswith(prefix):
                endpoint = endpoint[len(prefix):]
        return endpoint.rstrip("/")

    if payload.provider == AIProvider.OPENAI:
        return "api.openai.com"

    if payload.provider == AIProvider.AZURE_OPENAI:
        if not payload.azure_deployment_name:
            raise ValueError(
                "Azure OpenAI requires 'azureDeploymentName'. "
                "Provide 'apiEndpoint' or 'azureDeploymentName'."
            )
        return f"{payload.azure_deployment_name}.openai.azure.com"

    if payload.provider == AIProvider.AWS_BEDROCK:
        region = payload.aws_region or "us-east-1"
        return f"bedrock-runtime.{region}.amazonaws.com"

    raise ValueError(
        f"Provider '{payload.provider.value}' requires 'apiEndpoint' to be specified."
    )


# ==================== AI Service Backends ====================

@router.post(
    "/backends",
    response_model=AIBackendResponse,
    status_code=201,
    responses={409: {"model": ErrorResponse}, 422: {"model": ErrorResponse}},
    summary="Create an AI service backend",
    description="""
Create a Backend resource pointing to an AI/LLM provider's API endpoint.

**Supported Providers:**
- **openai**: Auto-resolves to `api.openai.com`
- **azure-openai**: Requires `azureDeploymentName` or `apiEndpoint`
- **aws-bedrock**: Auto-resolves using `awsRegion` (default: us-east-1)
- **custom**: Requires `apiEndpoint`

**Example:**
```json
{
    "name": "openai-backend",
    "targetGateway": "us-envoy-1",
    "provider": "openai"
}
```
""",
)
def create_ai_backend(payload: AIBackendCreate):
    """Create an AI service backend."""
    try:
        rm = get_resource_manager(payload.target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

    if rm.resource_exists("Backend", payload.name):
        raise HTTPException(
            status_code=409,
            detail=f"AI Backend '{payload.name}' already exists"
        )

    # Resolve endpoint
    try:
        hostname = resolve_ai_endpoint(payload)
    except ValueError as e:
        raise HTTPException(status_code=422, detail=str(e))

    # Build Backend spec with FQDN endpoint
    spec = {
        "endpoints": [{
            "fqdn": {
                "hostname": hostname,
                "port": payload.port,
            }
        }],
        "appProtocols": ["https" if payload.enable_tls else "http"],
    }

    # Labels
    labels = payload.labels or {}
    labels["envoy-agent.io/type"] = "ai-backend"
    labels["envoy-agent.io/ai-provider"] = payload.provider.value
    labels["envoy-agent.io/target-gateway"] = payload.target_gateway

    try:
        rm.create_custom_resource(
            kind="Backend",
            name=payload.name,
            spec=spec,
            labels=labels,
        )

        return AIBackendResponse(
            status="created",
            message=f"AI Backend '{payload.name}' created for {payload.provider.value}",
            backend_name=payload.name,
            namespace=rm.namespace,
            target_gateway=payload.target_gateway,
            provider=payload.provider.value,
            api_endpoint=hostname,
            details={
                "port": payload.port,
                "tls": payload.enable_tls,
            },
        )
    except ApiException as e:
        raise HTTPException(status_code=422, detail=f"Failed to create AI Backend: {e.body}")


@router.get(
    "/backends",
    response_model=ResourceListResponse,
    summary="List AI service backends",
    description="List all AI/LLM service Backend resources for a target gateway.",
)
def list_ai_backends(
    target_gateway: str = Query(..., alias="targetGateway", description="Target gateway identifier"),
):
    """List AI service backends."""
    try:
        rm = get_resource_manager(target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

    items = rm.list_custom_resources(
        "Backend",
        label_selector="envoy-agent.io/type=ai-backend",
    )

    return ResourceListResponse(
        items=items,
        total=len(items),
        namespace=rm.namespace,
    )


@router.get(
    "/backends/{name}",
    responses={404: {"model": ErrorResponse}},
    summary="Get an AI service backend",
    description="Get details of a specific AI service backend.",
)
def get_ai_backend(
    name: str,
    target_gateway: str = Query(..., alias="targetGateway", description="Target gateway identifier"),
):
    """Get an AI service backend by name."""
    try:
        rm = get_resource_manager(target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

    backend = rm.get_custom_resource("Backend", name)
    if not backend:
        raise HTTPException(status_code=404, detail=f"AI Backend '{name}' not found")

    return backend


@router.delete(
    "/backends/{name}",
    response_model=ResourceResponse,
    responses={404: {"model": ErrorResponse}},
    summary="Delete an AI service backend",
    description="Delete an AI service backend resource.",
)
def delete_ai_backend(
    name: str,
    target_gateway: str = Query(..., alias="targetGateway", description="Target gateway identifier"),
):
    """Delete an AI service backend."""
    try:
        rm = get_resource_manager(target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

    if not rm.delete_custom_resource("Backend", name):
        raise HTTPException(status_code=404, detail=f"AI Backend '{name}' not found")

    return ResourceResponse(
        status="deleted",
        message=f"AI Backend '{name}' deleted",
        resource_name=name,
        namespace=rm.namespace,
        resource_type="Backend",
    )


# ==================== AI Routes ====================

@router.post(
    "/routes",
    response_model=AIRouteResponse,
    status_code=201,
    responses={409: {"model": ErrorResponse}, 422: {"model": ErrorResponse}},
    summary="Create an AI route",
    description="""
Create an HTTPRoute configured for AI/LLM traffic.

Routes traffic from the gateway to an AI service backend. Supports
model-based header injection and configurable timeouts suitable for AI workloads.

**Example:**
```json
{
    "name": "openai-chat-route",
    "targetGateway": "us-envoy-1",
    "backendName": "openai-backend",
    "backendPort": 443,
    "path": "/v1/chat/completions",
    "model": "gpt-4o",
    "timeout": "120s"
}
```
""",
)
def create_ai_route(payload: AIRouteCreate):
    """Create an HTTPRoute for AI traffic."""
    try:
        rm = get_resource_manager(payload.target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

    gateway_config = get_gateway_config(payload.target_gateway)

    if rm.resource_exists("HTTPRoute", payload.name):
        raise HTTPException(
            status_code=409,
            detail=f"AI Route '{payload.name}' already exists"
        )

    try:
        # Build parent ref
        parent_ref = {
            "group": "gateway.networking.k8s.io",
            "kind": "Gateway",
            "name": gateway_config.gateway_name,
        }

        # Build backend ref
        backend_ref = {
            "name": payload.backend_name,
            "port": payload.backend_port,
        }

        # Build match rules for each path
        paths = [payload.path]
        if payload.additional_paths:
            paths.extend(payload.additional_paths)

        rules = []
        for path in paths:
            match_rule = {
                "path": {"type": "PathPrefix", "value": path}
            }

            rule = {
                "matches": [match_rule],
                "backendRefs": [backend_ref],
            }

            # Add timeout
            if payload.timeout:
                rule["timeouts"] = {"request": payload.timeout}

            # Add model header injection via request header filter
            filters = []
            if payload.model:
                filters.append({
                    "type": "RequestHeaderModifier",
                    "requestHeaderModifier": {
                        "set": [{"name": "x-ai-model", "value": payload.model}],
                    },
                })

            if filters:
                rule["filters"] = filters

            rules.append(rule)

        # Build spec
        spec = {
            "parentRefs": [parent_ref],
            "rules": rules,
        }

        if payload.hostnames:
            spec["hostnames"] = payload.hostnames

        # Labels
        labels = payload.labels or {}
        labels["envoy-agent.io/type"] = "ai-route"
        labels["envoy-agent.io/target-gateway"] = payload.target_gateway
        labels["envoy-agent.io/backend"] = payload.backend_name
        if payload.model:
            labels["envoy-agent.io/ai-model"] = payload.model

        rm.create_custom_resource(
            kind="HTTPRoute",
            name=payload.name,
            spec=spec,
            labels=labels,
        )

        return AIRouteResponse(
            status="created",
            message=f"AI Route '{payload.name}' created",
            route_name=payload.name,
            backend_name=payload.backend_name,
            namespace=rm.namespace,
            target_gateway=payload.target_gateway,
            path=payload.path,
            model=payload.model,
            details={
                "paths": paths,
                "timeout": payload.timeout,
            },
        )

    except ApiException as e:
        raise HTTPException(status_code=422, detail=f"Failed to create AI Route: {e.body}")


@router.get(
    "/routes",
    response_model=ResourceListResponse,
    summary="List AI routes",
    description="List all AI/LLM HTTPRoute resources for a target gateway.",
)
def list_ai_routes(
    target_gateway: str = Query(..., alias="targetGateway", description="Target gateway identifier"),
):
    """List AI routes."""
    try:
        rm = get_resource_manager(target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

    items = rm.list_custom_resources(
        "HTTPRoute",
        label_selector="envoy-agent.io/type=ai-route",
    )

    return ResourceListResponse(
        items=items,
        total=len(items),
        namespace=rm.namespace,
    )


@router.get(
    "/routes/{name}",
    responses={404: {"model": ErrorResponse}},
    summary="Get an AI route",
    description="Get details of a specific AI route.",
)
def get_ai_route(
    name: str,
    target_gateway: str = Query(..., alias="targetGateway", description="Target gateway identifier"),
):
    """Get an AI route by name."""
    try:
        rm = get_resource_manager(target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

    route = rm.get_custom_resource("HTTPRoute", name)
    if not route:
        raise HTTPException(status_code=404, detail=f"AI Route '{name}' not found")

    return route


@router.delete(
    "/routes/{name}",
    response_model=ResourceResponse,
    responses={404: {"model": ErrorResponse}},
    summary="Delete an AI route",
    description="Delete an AI route resource.",
)
def delete_ai_route(
    name: str,
    target_gateway: str = Query(..., alias="targetGateway", description="Target gateway identifier"),
):
    """Delete an AI route."""
    try:
        rm = get_resource_manager(target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

    if not rm.delete_custom_resource("HTTPRoute", name):
        raise HTTPException(status_code=404, detail=f"AI Route '{name}' not found")

    return ResourceResponse(
        status="deleted",
        message=f"AI Route '{name}' deleted",
        resource_name=name,
        namespace=rm.namespace,
        resource_type="HTTPRoute",
    )


# ==================== AI Policies ====================

@router.post(
    "/policies/token-rate-limit",
    response_model=ResourceResponse,
    status_code=201,
    responses={409: {"model": ErrorResponse}, 422: {"model": ErrorResponse}},
    summary="Create AI token rate limiting",
    description="""
Create a BackendTrafficPolicy with token-based rate limiting for AI routes.

Limits AI API usage based on token counts per minute and/or request counts.
This is essential for controlling costs with AI/LLM providers.

**Example:**
```json
{
    "name": "openai-token-limit",
    "targetGateway": "us-envoy-1",
    "targetRoute": "openai-chat-route",
    "totalTokensPerMinute": 100000,
    "requestsPerMinute": 60
}
```
""",
)
def create_ai_token_rate_limit(payload: AITokenRateLimitCreate):
    """Create token-based rate limiting for AI routes."""
    try:
        rm = get_resource_manager(payload.target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

    if rm.resource_exists("BackendTrafficPolicy", payload.name):
        raise HTTPException(
            status_code=409,
            detail=f"AI rate limit policy '{payload.name}' already exists"
        )

    # Build rate limit rules
    rules = []

    if payload.requests_per_minute:
        rules.append({
            "limit": {
                "requests": payload.requests_per_minute,
                "unit": "Minute",
            }
        })

    # Token-based limits are configured as metadata annotations
    # since Envoy uses ext_proc or WASM for token counting
    annotations = {}
    if payload.input_tokens_per_minute:
        annotations["ai.envoy-agent.io/input-tokens-per-minute"] = str(payload.input_tokens_per_minute)
    if payload.output_tokens_per_minute:
        annotations["ai.envoy-agent.io/output-tokens-per-minute"] = str(payload.output_tokens_per_minute)
    if payload.total_tokens_per_minute:
        annotations["ai.envoy-agent.io/total-tokens-per-minute"] = str(payload.total_tokens_per_minute)

    # Build spec with request-based rate limit as the enforced limit
    spec = {
        "targetRef": build_target_ref("HTTPRoute", payload.target_route),
    }

    if rules:
        spec["rateLimit"] = {
            "type": "Global",
            "global": {"rules": rules},
        }

    # Labels
    labels = payload.labels or {}
    labels["envoy-agent.io/type"] = "ai-policy"
    labels["envoy-agent.io/ai-policy-type"] = "token-rate-limit"
    labels["envoy-agent.io/target-gateway"] = payload.target_gateway

    try:
        rm.create_custom_resource(
            kind="BackendTrafficPolicy",
            name=payload.name,
            spec=spec,
            labels=labels,
            annotations=annotations if annotations else None,
        )

        details = {"targetGateway": payload.target_gateway}
        if payload.requests_per_minute:
            details["requestsPerMinute"] = payload.requests_per_minute
        if payload.total_tokens_per_minute:
            details["totalTokensPerMinute"] = payload.total_tokens_per_minute
        if payload.input_tokens_per_minute:
            details["inputTokensPerMinute"] = payload.input_tokens_per_minute
        if payload.output_tokens_per_minute:
            details["outputTokensPerMinute"] = payload.output_tokens_per_minute

        return ResourceResponse(
            status="created",
            message=f"AI token rate limit '{payload.name}' created",
            resource_name=payload.name,
            namespace=rm.namespace,
            resource_type="BackendTrafficPolicy",
            details=details,
        )
    except ApiException as e:
        raise HTTPException(status_code=422, detail=f"Failed to create AI rate limit: {e.body}")


@router.post(
    "/policies/api-key-auth",
    response_model=ResourceResponse,
    status_code=201,
    responses={409: {"model": ErrorResponse}, 422: {"model": ErrorResponse}},
    summary="Create AI API key authentication",
    description="""
Create a SecurityPolicy requiring API key authentication for AI routes.

Prevents unauthorized access to AI endpoints which can be expensive.

**Example:**
```json
{
    "name": "ai-api-key-auth",
    "targetGateway": "us-envoy-1",
    "targetRoute": "openai-chat-route",
    "apiKeysSecret": "ai-api-keys",
    "headerName": "x-api-key"
}
```
""",
)
def create_ai_api_key_auth(payload: AIAPIKeyAuthCreate):
    """Create API key authentication for AI routes."""
    try:
        rm = get_resource_manager(payload.target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

    if rm.resource_exists("SecurityPolicy", payload.name):
        raise HTTPException(
            status_code=409,
            detail=f"AI auth policy '{payload.name}' already exists"
        )

    spec = {
        "targetRef": build_target_ref("HTTPRoute", payload.target_route),
        "apiKey": {
            "extractFrom": {"headers": [payload.header_name]},
            "credentials": [{"kind": "Secret", "name": payload.api_keys_secret}],
        },
    }

    labels = payload.labels or {}
    labels["envoy-agent.io/type"] = "ai-policy"
    labels["envoy-agent.io/ai-policy-type"] = "api-key-auth"
    labels["envoy-agent.io/target-gateway"] = payload.target_gateway

    try:
        rm.create_custom_resource(
            kind="SecurityPolicy",
            name=payload.name,
            spec=spec,
            labels=labels,
        )

        return ResourceResponse(
            status="created",
            message=f"AI API key auth '{payload.name}' created",
            resource_name=payload.name,
            namespace=rm.namespace,
            resource_type="SecurityPolicy",
            details={
                "headerName": payload.header_name,
                "targetGateway": payload.target_gateway,
            },
        )
    except ApiException as e:
        raise HTTPException(status_code=422, detail=f"Failed to create AI auth policy: {e.body}")


@router.post(
    "/routes/model-routing",
    response_model=ResourceResponse,
    status_code=201,
    responses={409: {"model": ErrorResponse}, 422: {"model": ErrorResponse}},
    summary="Create AI model-based routing",
    description="""
Create an HTTPRoute that routes requests to different AI backends
based on the model specified in the request header (`x-ai-model`).

**Example:**
```json
{
    "name": "ai-model-router",
    "targetGateway": "us-envoy-1",
    "path": "/v1/chat/completions",
    "rules": [
        {"model": "gpt-4o", "backendName": "openai-backend", "backendPort": 443},
        {"model": "claude-3.5-sonnet", "backendName": "anthropic-backend", "backendPort": 443}
    ],
    "defaultBackendName": "openai-backend",
    "defaultBackendPort": 443
}
```
""",
)
def create_ai_model_routing(payload: AIModelRoutingCreate):
    """Create model-based routing for AI requests."""
    try:
        rm = get_resource_manager(payload.target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

    gateway_config = get_gateway_config(payload.target_gateway)

    if rm.resource_exists("HTTPRoute", payload.name):
        raise HTTPException(
            status_code=409,
            detail=f"AI model route '{payload.name}' already exists"
        )

    try:
        parent_ref = {
            "group": "gateway.networking.k8s.io",
            "kind": "Gateway",
            "name": gateway_config.gateway_name,
        }

        # Build rules: one per model + default
        rules = []

        for model_rule in payload.rules:
            rule = {
                "matches": [{
                    "path": {"type": "PathPrefix", "value": payload.path},
                    "headers": [{
                        "type": "Exact",
                        "name": "x-ai-model",
                        "value": model_rule.model,
                    }],
                }],
                "backendRefs": [{
                    "name": model_rule.backend_name,
                    "port": model_rule.backend_port,
                    "weight": model_rule.weight,
                }],
            }
            if payload.timeout:
                rule["timeouts"] = {"request": payload.timeout}
            rules.append(rule)

        # Default rule (no header match)
        default_rule = {
            "matches": [{
                "path": {"type": "PathPrefix", "value": payload.path},
            }],
            "backendRefs": [{
                "name": payload.default_backend_name,
                "port": payload.default_backend_port,
            }],
        }
        if payload.timeout:
            default_rule["timeouts"] = {"request": payload.timeout}
        rules.append(default_rule)

        spec = {
            "parentRefs": [parent_ref],
            "rules": rules,
        }

        if payload.hostnames:
            spec["hostnames"] = payload.hostnames

        labels = payload.labels or {}
        labels["envoy-agent.io/type"] = "ai-model-route"
        labels["envoy-agent.io/target-gateway"] = payload.target_gateway

        rm.create_custom_resource(
            kind="HTTPRoute",
            name=payload.name,
            spec=spec,
            labels=labels,
        )

        return ResourceResponse(
            status="created",
            message=f"AI model routing '{payload.name}' created with {len(payload.rules)} model rules",
            resource_name=payload.name,
            namespace=rm.namespace,
            resource_type="HTTPRoute",
            details={
                "models": [r.model for r in payload.rules],
                "defaultBackend": payload.default_backend_name,
                "targetGateway": payload.target_gateway,
            },
        )
    except ApiException as e:
        raise HTTPException(status_code=422, detail=f"Failed to create model routing: {e.body}")


@router.get(
    "/policies",
    response_model=ResourceListResponse,
    summary="List AI policies",
    description="List all AI-specific policies (rate limits, auth) for a target gateway.",
)
def list_ai_policies(
    target_gateway: str = Query(..., alias="targetGateway", description="Target gateway identifier"),
):
    """List AI policies."""
    try:
        rm = get_resource_manager(target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

    # Collect both BackendTrafficPolicies and SecurityPolicies with AI labels
    btp_items = rm.list_custom_resources(
        "BackendTrafficPolicy",
        label_selector="envoy-agent.io/type=ai-policy",
    )
    sp_items = rm.list_custom_resources(
        "SecurityPolicy",
        label_selector="envoy-agent.io/type=ai-policy",
    )

    items = btp_items + sp_items

    return ResourceListResponse(
        items=items,
        total=len(items),
        namespace=rm.namespace,
    )


@router.delete(
    "/policies/{name}",
    response_model=ResourceResponse,
    responses={404: {"model": ErrorResponse}},
    summary="Delete an AI policy",
    description="Delete an AI policy (tries BackendTrafficPolicy first, then SecurityPolicy).",
)
def delete_ai_policy(
    name: str,
    target_gateway: str = Query(..., alias="targetGateway", description="Target gateway identifier"),
):
    """Delete an AI policy."""
    try:
        rm = get_resource_manager(target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

    # Try BackendTrafficPolicy first
    if rm.delete_custom_resource("BackendTrafficPolicy", name):
        return ResourceResponse(
            status="deleted",
            message=f"AI policy '{name}' deleted",
            resource_name=name,
            namespace=rm.namespace,
            resource_type="BackendTrafficPolicy",
        )

    # Try SecurityPolicy
    if rm.delete_custom_resource("SecurityPolicy", name):
        return ResourceResponse(
            status="deleted",
            message=f"AI policy '{name}' deleted",
            resource_name=name,
            namespace=rm.namespace,
            resource_type="SecurityPolicy",
        )

    raise HTTPException(status_code=404, detail=f"AI policy '{name}' not found")
