"""
API routes for importing OpenAPI specifications.
Creates HTTPRoutes from OpenAPI/Swagger specs.
"""

import logging
import httpx
from typing import Optional
from fastapi import APIRouter, HTTPException, UploadFile, File, Form, Query, Response
from kubernetes.client.rest import ApiException

from ..models.openapi_import import (
    OpenAPIImportRequest,
    OpenAPIImportFromURLRequest,
    OpenAPIImportResponse,
    RouteFromSpec,
)
from ..services.openapi_parser import OpenAPIParser
from ..services.resource_manager import ResourceManager
from ..config import get_gateway_config
from ..utils.helpers import build_parent_ref, build_backend_ref

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/openapi", tags=["OpenAPI Import"])


def get_resource_manager(target_gateway: str) -> ResourceManager:
    """Get resource manager for the specified target gateway."""
    return ResourceManager(target_gateway=target_gateway)


@router.post(
    "/import",
    response_model=OpenAPIImportResponse,
    status_code=201,
    summary="Import routes from OpenAPI spec",
    description="Parse an OpenAPI specification and create HTTPRoutes for each endpoint.",
)
def import_from_spec(response: Response, payload: OpenAPIImportRequest):
    """
    Import routes from an OpenAPI specification (JSON body).
    
    This endpoint:
    1. Parses the OpenAPI spec to extract all paths and methods
    2. Creates a backend service for the API
    3. Creates an HTTPRoute for each unique path
    """
    try:
        rm = get_resource_manager(payload.target_gateway)
        gateway_config = get_gateway_config(payload.target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    
    # Parse OpenAPI spec
    try:
        parser = OpenAPIParser(payload.spec)
        routes = parser.parse_routes(payload.base_path)
    except Exception as e:
        raise HTTPException(status_code=422, detail=f"Failed to parse OpenAPI spec: {str(e)}")
    
    if not routes:
        raise HTTPException(status_code=422, detail="No routes found in OpenAPI spec")
    
    # Prepare response
    created_routes = []
    skipped_routes = []
    errors = []
    
    # Create backend service (one for the entire API)
    backend_name = f"{payload.route_prefix or 'api'}-backend"
    
    if not payload.dry_run:
        try:
            if not rm.service_exists(backend_name):
                app_protocol = "https" if payload.backend_tls_enabled else "http"
                rm.create_external_name_service(
                    name=backend_name,
                    external_name=payload.backend_url,
                    port=payload.backend_port,
                    app_protocol=app_protocol,
                )
                logger.info(f"Created backend service: {backend_name}")
        except ApiException as e:
            errors.append(f"Failed to create backend service: {e.body}")
    
    # Create HTTPRoutes for each path
    for route_info in routes:
        route_name = parser.generate_route_name(
            route_info["path"], 
            route_info["methods"],
            payload.route_prefix
        )
        
        route_spec = RouteFromSpec(
            name=route_name,
            path=route_info["path"],
            methods=route_info["methods"],
            summary=route_info.get("summary"),
            operation_id=route_info.get("operation_id"),
            tags=route_info.get("tags"),
        )
        
        if payload.dry_run:
            created_routes.append(route_spec)
            continue
        
        # Check if route already exists
        if rm.resource_exists("HTTPRoute", route_name):
            skipped_routes.append(route_spec)
            continue
        
        # Build HTTPRoute spec
        try:
            parent_ref = build_parent_ref(gateway_config.gateway_name)
            backend_ref = build_backend_ref(backend_name, payload.backend_port)
            
            # Build match rule
            match_rule = {"path": {"type": "PathPrefix", "value": route_info["path"]}}
            
            # Add method matching if not all methods
            if route_info["methods"] and set(route_info["methods"]) != {"GET", "POST", "PUT", "PATCH", "DELETE", "HEAD", "OPTIONS"}:
                match_rule["method"] = route_info["methods"][0] if len(route_info["methods"]) == 1 else None
            
            rule = {
                "matches": [match_rule],
                "backendRefs": [backend_ref],
            }
            
            spec = {
                "parentRefs": [parent_ref],
                "rules": [rule],
            }
            
            # Add hostnames if provided
            if payload.hostnames:
                spec["hostnames"] = payload.hostnames
            
            # Build labels
            labels = payload.labels or {}
            labels["envoy-agent.io/target-gateway"] = payload.target_gateway
            labels["envoy-agent.io/backend"] = backend_name
            labels["envoy-agent.io/openapi-import"] = "true"
            if parser.title:
                # Sanitize title for label
                safe_title = parser.title[:63].replace(" ", "-").lower()
                labels["envoy-agent.io/api-title"] = safe_title
            
            rm.create_custom_resource(
                kind="HTTPRoute",
                name=route_name,
                spec=spec,
                labels=labels,
            )
            
            created_routes.append(route_spec)
            logger.info(f"Created HTTPRoute: {route_name}")
            
        except ApiException as e:
            errors.append(f"Failed to create route '{route_name}': {e.body}")
        except Exception as e:
            errors.append(f"Failed to create route '{route_name}': {str(e)}")
    
    # Set HTTP status code to 206 for partial success
    if errors:
        response.status_code = 206
    
    return OpenAPIImportResponse(
        status="success" if not errors else "partial",
        message=f"Imported {len(created_routes)} routes from OpenAPI spec",
        spec_title=parser.title,
        spec_version=parser.spec_version,
        routes_created=len(created_routes),
        routes_skipped=len(skipped_routes),
        routes=created_routes,
        errors=errors,
        target_gateway=payload.target_gateway,
        namespace=rm.namespace,
        dry_run=payload.dry_run,
    )


@router.post(
    "/import/url",
    response_model=OpenAPIImportResponse,
    status_code=201,
    summary="Import routes from OpenAPI spec URL",
    description="Fetch an OpenAPI specification from a URL and create HTTPRoutes.",
)
async def import_from_url(response: Response, payload: OpenAPIImportFromURLRequest):
    """
    Import routes from an OpenAPI specification URL.
    
    Fetches the spec from the provided URL and creates routes.
    """
    # Fetch spec from URL
    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.get(payload.spec_url)
            response.raise_for_status()
            
            # Try to parse as JSON
            try:
                spec = response.json()
            except Exception:
                raise HTTPException(
                    status_code=422, 
                    detail="Failed to parse response as JSON. Ensure URL returns valid JSON OpenAPI spec."
                )
    except httpx.HTTPError as e:
        raise HTTPException(status_code=422, detail=f"Failed to fetch OpenAPI spec: {str(e)}")
    
    # Create import request and delegate to main import function
    import_request = OpenAPIImportRequest(
        target_gateway=payload.target_gateway,
        spec=spec,
        backend_url=payload.backend_url,
        backend_port=payload.backend_port,
        backend_tls_enabled=payload.backend_tls_enabled,
        route_prefix=payload.route_prefix,
        hostnames=payload.hostnames,
        labels=payload.labels,
        dry_run=payload.dry_run,
    )
    
    return import_from_spec(response, import_request)


@router.post(
    "/import/file",
    response_model=OpenAPIImportResponse,
    status_code=201,
    summary="Import routes from OpenAPI spec file",
    description="Upload an OpenAPI specification file and create HTTPRoutes.",
)
async def import_from_file(
    response: Response,
    file: UploadFile = File(..., description="OpenAPI spec file (JSON or YAML)"),
    target_gateway: str = Form(..., alias="targetGateway", description="Target gateway identifier"),
    backend_url: str = Form(..., alias="backendUrl", description="Backend URL"),
    backend_port: int = Form(default=443, alias="backendPort", description="Backend port"),
    backend_tls_enabled: bool = Form(default=True, alias="backendTlsEnabled", description="Enable TLS"),
    route_prefix: Optional[str] = Form(default=None, alias="routePrefix", description="Route name prefix"),
    hostnames: Optional[str] = Form(default=None, description="Comma-separated hostnames"),
    dry_run: bool = Form(default=False, alias="dryRun", description="Dry run mode"),
):
    """
    Import routes from an uploaded OpenAPI specification file.
    
    Supports JSON and YAML formats.
    """
    import json
    import yaml
    
    # Read file content
    content = await file.read()
    
    # Try to parse as JSON first, then YAML
    try:
        spec = json.loads(content)
    except json.JSONDecodeError:
        try:
            spec = yaml.safe_load(content)
        except yaml.YAMLError as e:
            raise HTTPException(
                status_code=422, 
                detail=f"Failed to parse file as JSON or YAML: {str(e)}"
            )
    
    if not isinstance(spec, dict):
        raise HTTPException(status_code=422, detail="Invalid OpenAPI spec format")
    
    # Parse hostnames
    hostname_list = None
    if hostnames:
        hostname_list = [h.strip() for h in hostnames.split(",") if h.strip()]
    
    # Create import request
    import_request = OpenAPIImportRequest(
        target_gateway=target_gateway,
        spec=spec,
        backend_url=backend_url,
        backend_port=backend_port,
        backend_tls_enabled=backend_tls_enabled,
        route_prefix=route_prefix,
        hostnames=hostname_list,
        dry_run=dry_run,
    )
    return import_from_spec(response, import_request)
    return import_from_spec(import_request)


@router.get(
    "/routes",
    summary="List OpenAPI-imported routes",
    description="List all routes that were created from OpenAPI imports.",
)
def list_imported_routes(
    target_gateway: str = Query(..., alias="targetGateway", description="Target gateway identifier"),
):
    """List all routes created from OpenAPI imports."""
    try:
        rm = get_resource_manager(target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    
    # Find routes with openapi-import label
    routes = rm.list_custom_resources(
        "HTTPRoute", 
        label_selector="envoy-agent.io/openapi-import=true"
    )
    
    return {
        "routes": [
            {
                "name": r["metadata"]["name"],
                "namespace": r["metadata"]["namespace"],
                "path": r["spec"]["rules"][0]["matches"][0]["path"]["value"] if r.get("spec", {}).get("rules") else None,
                "apiTitle": r["metadata"].get("labels", {}).get("envoy-agent.io/api-title"),
                "backend": r["metadata"].get("labels", {}).get("envoy-agent.io/backend"),
            }
            for r in routes
        ],
        "total": len(routes),
        "targetGateway": target_gateway,
        "namespace": rm.namespace,
    }


@router.delete(
    "/routes/{api_title}",
    summary="Delete all routes for an API",
    description="Delete all routes that were imported from a specific API.",
)
def delete_imported_routes(
    api_title: str,
    target_gateway: str = Query(..., alias="targetGateway", description="Target gateway identifier"),
    delete_backend: bool = Query(default=True, alias="deleteBackend", description="Also delete the backend service"),
):
    """Delete all routes imported from a specific API."""
    try:
        rm = get_resource_manager(target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    
    # Sanitize API title for label matching
    safe_title = api_title[:63].replace(" ", "-").lower()
    
    # Find routes with this API title
    routes = rm.list_custom_resources(
        "HTTPRoute",
        label_selector=f"envoy-agent.io/api-title={safe_title}"
    )
    
    if not routes:
        raise HTTPException(status_code=404, detail=f"No routes found for API '{api_title}'")
    
    deleted_routes = []
    backend_name = None
    errors = []
    
    for route in routes:
        route_name = route["metadata"]["name"]
        if not backend_name:
            backend_name = route["metadata"].get("labels", {}).get("envoy-agent.io/backend")
        
        try:
            rm.delete_custom_resource("HTTPRoute", route_name)
            deleted_routes.append(route_name)
        except Exception as e:
            errors.append(f"Failed to delete route '{route_name}': {str(e)}")
    
    # Delete backend if requested
    backend_deleted = False
    if delete_backend and backend_name:
        try:
            if rm.service_exists(backend_name):
                rm.delete_service(backend_name)
                backend_deleted = True
        except Exception as e:
            errors.append(f"Failed to delete backend '{backend_name}': {str(e)}")
    
    return {
        "status": "success" if not errors else "partial",
        "message": f"Deleted {len(deleted_routes)} routes",
        "deletedRoutes": deleted_routes,
        "backendDeleted": backend_deleted,
        "errors": errors,
        "targetGateway": target_gateway,
    }
