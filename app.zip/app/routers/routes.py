"""
Unified API routes for HTTPRoute, GRPCRoute, TLSRoute, TCPRoute, UDPRoute.
"""

from fastapi import APIRouter, HTTPException, Query
from typing import Optional, List
from kubernetes.client.rest import ApiException

from ..models.routes import (
    SimpleHTTPRouteCreate, HTTPRouteUpdate, HTTPRouteResponse, RouteListResponse,
    GRPCRouteCreate, TLSRouteCreate, TCPRouteCreate, UDPRouteCreate,
)
from ..models.common import ResourceResponse, ErrorResponse
from ..services.resource_manager import ResourceManager
from ..config import get_settings, get_gateway_config

router = APIRouter(prefix="/routes", tags=["Routes"])


def get_resource_manager(target_gateway: str) -> ResourceManager:
    """Get a resource manager for the specified target gateway."""
    return ResourceManager(target_gateway=target_gateway)


def build_parent_ref(gateway_name: str, namespace: Optional[str] = None) -> dict:
    """Build a parent reference for a route."""
    ref = {
        "group": "gateway.networking.k8s.io",
        "kind": "Gateway",
        "name": gateway_name,
    }
    if namespace:
        ref["namespace"] = namespace
    return ref


def build_backend_ref(name: str, port: int, namespace: Optional[str] = None, use_backend_crd: bool = True) -> dict:
    """Build a backend reference for a route.
    
    Args:
        name: Backend name
        port: Backend port
        namespace: Optional namespace
        use_backend_crd: If True, reference Envoy Gateway Backend CRD.
                        If False, reference a Kubernetes Service.
    """
    ref = {
        "name": name,
        "port": port,
    }
    if use_backend_crd:
        ref["group"] = "gateway.envoyproxy.io"
        ref["kind"] = "Backend"
    if namespace:
        ref["namespace"] = namespace
    return ref


# ==================== HTTPRoute ====================

@router.post(
    "/http",
    response_model=ResourceResponse,
    status_code=201,
    responses={409: {"model": ErrorResponse}, 422: {"model": ErrorResponse}},
    summary="Create an HTTPRoute",
    description="""
Create an HTTPRoute using an existing backend service.

The route will be created in the cluster/namespace determined by the target_gateway.

**Example:**
```json
{
    "name": "users-route",
    "targetGateway": "us-envoy-1",
    "path": "/api/v1/users",
    "backendName": "users-service",
    "backendPort": 9080
}
```
""",
)
def create_http_route(payload: SimpleHTTPRouteCreate):
    """Create a simple HTTPRoute with an existing backend."""
    
    try:
        rm = get_resource_manager(payload.target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    
    gateway_config = get_gateway_config(payload.target_gateway)
    
    # Check if route already exists
    if rm.resource_exists("HTTPRoute", payload.name):
        raise HTTPException(
            status_code=409,
            detail=f"HTTPRoute '{payload.name}' already exists"
        )
    
    try:
        # Build HTTPRoute spec
        parent_ref = build_parent_ref(gateway_config.gateway_name)
        backend_ref = build_backend_ref(payload.backend_name, payload.backend_port)
        
        # Build match rule
        match_rule = {
            "path": {
                "type": payload.path_type.value,
                "value": payload.path,
            }
        }
        
        # Add methods if specified
        if payload.methods and len(payload.methods) > 0:
            match_rule["method"] = payload.methods[0].value
        
        # Build rule
        rule = {
            "matches": [match_rule],
            "backendRefs": [backend_ref],
        }
        
        # Add timeout if specified
        if payload.timeout:
            rule["timeouts"] = {"request": payload.timeout}
        
        # Handle URL rewrite filter (optional)
        # Supports all scenarios from: https://gateway.envoyproxy.io/docs/tasks/traffic/http-urlrewrite/
        http_route_filter_name = None
        if payload.url_rewrite:
            if payload.url_rewrite.requires_http_route_filter():
                # Extended features (regex, header-based hostname) require HTTPRouteFilter CRD
                http_route_filter_name = f"{payload.name}-url-rewrite"
                http_route_filter_spec = payload.url_rewrite.to_http_route_filter_spec()
                
                if http_route_filter_spec:
                    # Create HTTPRouteFilter CRD first
                    rm.create_custom_resource(
                        kind="HTTPRouteFilter",
                        name=http_route_filter_name,
                        spec=http_route_filter_spec,
                        labels={"envoy-agent.io/route": payload.name},
                    )
                    # Add ExtensionRef filter to rule
                    rule["filters"] = [payload.url_rewrite.get_extension_ref_filter(http_route_filter_name)]
            else:
                # Core Gateway API URL rewrite (simple hostname, prefix/fullpath rewrite)
                filter_spec = payload.url_rewrite.to_filter_spec()
                if filter_spec:
                    rule["filters"] = [filter_spec]
        
        # Build spec
        spec = {
            "parentRefs": [parent_ref],
            "rules": [rule],
        }
        
        if payload.hostnames:
            spec["hostnames"] = payload.hostnames
        
        # Create HTTPRoute
        labels = payload.labels or {}
        labels["envoy-agent.io/target-gateway"] = payload.target_gateway
        labels["envoy-agent.io/backend"] = payload.backend_name
        if http_route_filter_name:
            labels["envoy-agent.io/url-rewrite-filter"] = http_route_filter_name
        
        rm.create_custom_resource(
            kind="HTTPRoute",
            name=payload.name,
            spec=spec,
            labels=labels,
        )
        
        return ResourceResponse(
            status="created",
            message=f"HTTPRoute '{payload.name}' created successfully",
            resource_name=payload.name,
            namespace=rm.namespace,
            resource_type="HTTPRoute",
            details={
                "backend": payload.backend_name,
                "targetGateway": payload.target_gateway,
            },
        )
        
    except ApiException as e:
        raise HTTPException(status_code=422, detail=f"Failed to create HTTPRoute: {e.body}")




@router.get(
    "/http",
    response_model=RouteListResponse,
    summary="List HTTPRoutes",
    description="List all HTTPRoute resources for a target gateway.",
)
def list_http_routes(
    target_gateway: str = Query(..., alias="targetGateway", description="Target gateway identifier"),
):
    """List HTTPRoutes for a target gateway."""
    try:
        rm = get_resource_manager(target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    
    items = rm.list_custom_resources("HTTPRoute")
    
    return RouteListResponse(
        items=items,
        total=len(items),
        target_gateway=target_gateway,
        namespace=rm.namespace,
    )


@router.get(
    "/http/{name}",
    responses={404: {"model": ErrorResponse}},
    summary="Get an HTTPRoute",
    description="Get an HTTPRoute resource by name.",
)
def get_http_route(
    name: str,
    target_gateway: str = Query(..., alias="targetGateway", description="Target gateway identifier"),
):
    """Get an HTTPRoute by name."""
    try:
        rm = get_resource_manager(target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    
    route = rm.get_custom_resource("HTTPRoute", name)
    
    if not route:
        raise HTTPException(status_code=404, detail=f"HTTPRoute '{name}' not found")
    
    return route


@router.put(
    "/http/{name}",
    response_model=ResourceResponse,
    responses={404: {"model": ErrorResponse}, 422: {"model": ErrorResponse}},
    summary="Update an HTTPRoute",
    description="Update an existing HTTPRoute resource.",
)
def update_http_route(
    name: str,
    payload: HTTPRouteUpdate,
    target_gateway: str = Query(..., alias="targetGateway", description="Target gateway identifier"),
):
    """Update an existing HTTPRoute."""
    try:
        rm = get_resource_manager(target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    
    existing = rm.get_custom_resource("HTTPRoute", name)
    if not existing:
        raise HTTPException(status_code=404, detail=f"HTTPRoute '{name}' not found")
    
    # Get existing backend name from labels
    labels = existing.get("metadata", {}).get("labels", {})
    backend_name = labels.get("envoy-agent.io/backend", f"{name}-backend")
    
    # Update backend if backend_url changed
    if payload.backend_url:
        use_tls = False
        if payload.backend_tls and payload.backend_tls.enabled:
            use_tls = True
        elif payload.backend_port and payload.backend_port == 443:
            use_tls = True
        
        # Delete old backend and create new
        rm.delete_service(backend_name)
        rm.create_backend_for_route(
            name=backend_name,
            backend_url=payload.backend_url,
            port=payload.backend_port or 443,
            use_tls=use_tls,
        )
    
    # Build updated spec from existing
    spec = existing.get("spec", {})
    
    # Update path if provided
    if payload.path:
        if "rules" not in spec:
            spec["rules"] = [{"matches": [{}], "backendRefs": []}]
        spec["rules"][0]["matches"][0]["path"] = {
            "type": (payload.path_type.value if payload.path_type else "PathPrefix"),
            "value": payload.path,
        }
    
    # Update hostnames if provided
    if payload.hostnames is not None:
        spec["hostnames"] = payload.hostnames
    
    # Update timeout if provided
    if payload.timeout:
        spec["rules"][0]["timeouts"] = {"request": payload.timeout}
    
    try:
        rm.update_custom_resource("HTTPRoute", name, spec)
        
        return ResourceResponse(
            status="updated",
            message=f"HTTPRoute '{name}' updated successfully",
            resource_name=name,
            namespace=rm.namespace,
            resource_type="HTTPRoute",
        )
    except ApiException as e:
        raise HTTPException(status_code=422, detail=f"Failed to update HTTPRoute: {e.body}")


@router.delete(
    "/http/{name}",
    response_model=ResourceResponse,
    responses={404: {"model": ErrorResponse}},
    summary="Delete an HTTPRoute",
    description="Delete an HTTPRoute resource and its associated backend.",
)
def delete_http_route(
    name: str,
    target_gateway: str = Query(..., alias="targetGateway", description="Target gateway identifier"),
    delete_backend: bool = Query(True, alias="deleteBackend", description="Also delete the backend service"),
):
    """Delete an HTTPRoute and optionally its backend."""
    try:
        rm = get_resource_manager(target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    
    # Get route to find backend name
    route = rm.get_custom_resource("HTTPRoute", name)
    if not route:
        raise HTTPException(status_code=404, detail=f"HTTPRoute '{name}' not found")
    
    backend_name = route.get("metadata", {}).get("labels", {}).get("envoy-agent.io/backend")
    
    # Delete route
    deleted = rm.delete_custom_resource("HTTPRoute", name)
    if not deleted:
        raise HTTPException(status_code=404, detail=f"HTTPRoute '{name}' not found")
    
    # Delete backend if requested
    if delete_backend and backend_name:
        rm.delete_service(backend_name)
    
    return ResourceResponse(
        status="deleted",
        message=f"HTTPRoute '{name}' deleted successfully",
        resource_name=name,
        namespace=rm.namespace,
        resource_type="HTTPRoute",
        details={"backend_deleted": delete_backend and backend_name is not None},
    )


# ==================== GRPCRoute ====================

@router.post(
    "/grpc",
    response_model=HTTPRouteResponse,
    status_code=201,
    summary="Create a GRPCRoute with backend",
    description="Create a new GRPCRoute with automatic backend creation.",
)
def create_grpc_route(payload: GRPCRouteCreate):
    """Create a GRPCRoute with automatic backend creation."""
    try:
        rm = get_resource_manager(payload.target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    
    gateway_config = get_gateway_config(payload.target_gateway)
    backend_name = f"{payload.name}-backend"
    
    if rm.resource_exists("GRPCRoute", payload.name):
        raise HTTPException(status_code=409, detail=f"GRPCRoute '{payload.name}' already exists")
    
    use_tls = payload.backend_tls and payload.backend_tls.enabled
    
    try:
        # Create backend
        if not rm.service_exists(backend_name):
            rm.create_backend_for_route(
                name=backend_name,
                backend_url=payload.backend_url,
                port=payload.backend_port,
                use_tls=use_tls,
            )
        
        # Build spec
        parent_ref = build_parent_ref(gateway_config.gateway_name)
        backend_ref = build_backend_ref(backend_name, payload.backend_port)
        
        match_rule = {}
        if payload.service or payload.method:
            match_rule["method"] = {}
            if payload.service:
                match_rule["method"]["service"] = payload.service
            if payload.method:
                match_rule["method"]["method"] = payload.method
        
        spec = {
            "parentRefs": [parent_ref],
            "rules": [{
                "backendRefs": [backend_ref],
            }],
        }
        
        if match_rule:
            spec["rules"][0]["matches"] = [match_rule]
        
        if payload.hostnames:
            spec["hostnames"] = payload.hostnames
        
        labels = payload.labels or {}
        labels["envoy-agent.io/target-gateway"] = payload.target_gateway
        labels["envoy-agent.io/backend"] = backend_name
        
        rm.create_custom_resource("GRPCRoute", payload.name, spec, labels=labels)
        
        cluster_info = rm.get_cluster_info()
        
        return HTTPRouteResponse(
            status="created",
            message=f"GRPCRoute '{payload.name}' and backend created",
            route_name=payload.name,
            backend_name=backend_name,
            namespace=rm.namespace,
            target_gateway=payload.target_gateway,
            cluster=cluster_info.get("cluster_name", gateway_config.eks_cluster_name),
            region=cluster_info.get("region", gateway_config.aws_region),
        )
    except ApiException as e:
        rm.delete_service(backend_name)
        raise HTTPException(status_code=422, detail=f"Failed to create GRPCRoute: {e.body}")


@router.get("/grpc", summary="List GRPCRoutes")
def list_grpc_routes(
    target_gateway: str = Query(..., alias="targetGateway"),
):
    try:
        rm = get_resource_manager(target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    
    items = rm.list_custom_resources("GRPCRoute")
    return {"items": items, "total": len(items), "targetGateway": target_gateway, "namespace": rm.namespace}


@router.delete("/grpc/{name}", response_model=ResourceResponse, summary="Delete a GRPCRoute")
def delete_grpc_route(
    name: str,
    target_gateway: str = Query(..., alias="targetGateway"),
    delete_backend: bool = Query(True, alias="deleteBackend"),
):
    try:
        rm = get_resource_manager(target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    
    route = rm.get_custom_resource("GRPCRoute", name)
    if not route:
        raise HTTPException(status_code=404, detail=f"GRPCRoute '{name}' not found")
    
    backend_name = route.get("metadata", {}).get("labels", {}).get("envoy-agent.io/backend")
    
    rm.delete_custom_resource("GRPCRoute", name)
    if delete_backend and backend_name:
        rm.delete_service(backend_name)
    
    return ResourceResponse(status="deleted", message=f"GRPCRoute '{name}' deleted", resource_name=name, namespace=rm.namespace, resource_type="GRPCRoute")


# ==================== TLSRoute ====================

@router.post(
    "/tls",
    response_model=HTTPRouteResponse,
    status_code=201,
    summary="Create a TLSRoute with backend",
)
def create_tls_route(payload: TLSRouteCreate):
    try:
        rm = get_resource_manager(payload.target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    
    gateway_config = get_gateway_config(payload.target_gateway)
    backend_name = f"{payload.name}-backend"
    
    if rm.resource_exists("TLSRoute", payload.name):
        raise HTTPException(status_code=409, detail=f"TLSRoute '{payload.name}' already exists")
    
    use_tls = payload.backend_tls and payload.backend_tls.enabled
    
    try:
        if not rm.service_exists(backend_name):
            rm.create_backend_for_route(backend_name, payload.backend_url, payload.backend_port, use_tls)
        
        parent_ref = build_parent_ref(gateway_config.gateway_name)
        
        spec = {
            "parentRefs": [parent_ref],
            "hostnames": payload.hostnames,
            "rules": [{"backendRefs": [build_backend_ref(backend_name, payload.backend_port)]}],
        }
        
        labels = payload.labels or {}
        labels["envoy-agent.io/target-gateway"] = payload.target_gateway
        labels["envoy-agent.io/backend"] = backend_name
        
        rm.create_custom_resource("TLSRoute", payload.name, spec, labels=labels)
        
        cluster_info = rm.get_cluster_info()
        
        return HTTPRouteResponse(
            status="created", message=f"TLSRoute '{payload.name}' and backend created",
            route_name=payload.name, backend_name=backend_name, namespace=rm.namespace,
            target_gateway=payload.target_gateway, cluster=cluster_info.get("cluster_name"), region=cluster_info.get("region"),
        )
    except ApiException as e:
        rm.delete_service(backend_name)
        raise HTTPException(status_code=422, detail=f"Failed to create TLSRoute: {e.body}")


@router.get("/tls", summary="List TLSRoutes")
def list_tls_routes(target_gateway: str = Query(..., alias="targetGateway")):
    try:
        rm = get_resource_manager(target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    items = rm.list_custom_resources("TLSRoute")
    return {"items": items, "total": len(items), "targetGateway": target_gateway, "namespace": rm.namespace}


@router.delete("/tls/{name}", response_model=ResourceResponse, summary="Delete a TLSRoute")
def delete_tls_route(name: str, target_gateway: str = Query(..., alias="targetGateway"), delete_backend: bool = Query(True, alias="deleteBackend")):
    try:
        rm = get_resource_manager(target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    route = rm.get_custom_resource("TLSRoute", name)
    if not route:
        raise HTTPException(status_code=404, detail=f"TLSRoute '{name}' not found")
    backend_name = route.get("metadata", {}).get("labels", {}).get("envoy-agent.io/backend")
    rm.delete_custom_resource("TLSRoute", name)
    if delete_backend and backend_name:
        rm.delete_service(backend_name)
    return ResourceResponse(status="deleted", message=f"TLSRoute '{name}' deleted", resource_name=name, namespace=rm.namespace, resource_type="TLSRoute")


# ==================== TCPRoute ====================

@router.post("/tcp", response_model=HTTPRouteResponse, status_code=201, summary="Create a TCPRoute with backend")
def create_tcp_route(payload: TCPRouteCreate):
    try:
        rm = get_resource_manager(payload.target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    
    gateway_config = get_gateway_config(payload.target_gateway)
    backend_name = f"{payload.name}-backend"
    
    if rm.resource_exists("TCPRoute", payload.name):
        raise HTTPException(status_code=409, detail=f"TCPRoute '{payload.name}' already exists")
    
    use_tls = payload.backend_tls and payload.backend_tls.enabled if payload.backend_tls else False
    
    try:
        if not rm.service_exists(backend_name):
            rm.create_backend_for_route(backend_name, payload.backend_url, payload.backend_port, use_tls)
        
        spec = {
            "parentRefs": [build_parent_ref(gateway_config.gateway_name)],
            "rules": [{"backendRefs": [build_backend_ref(backend_name, payload.backend_port)]}],
        }
        
        labels = payload.labels or {}
        labels["envoy-agent.io/target-gateway"] = payload.target_gateway
        labels["envoy-agent.io/backend"] = backend_name
        
        rm.create_custom_resource("TCPRoute", payload.name, spec, labels=labels)
        cluster_info = rm.get_cluster_info()
        
        return HTTPRouteResponse(
            status="created", message=f"TCPRoute '{payload.name}' and backend created",
            route_name=payload.name, backend_name=backend_name, namespace=rm.namespace,
            target_gateway=payload.target_gateway, cluster=cluster_info.get("cluster_name"), region=cluster_info.get("region"),
        )
    except ApiException as e:
        rm.delete_service(backend_name)
        raise HTTPException(status_code=422, detail=f"Failed to create TCPRoute: {e.body}")


@router.get("/tcp", summary="List TCPRoutes")
def list_tcp_routes(target_gateway: str = Query(..., alias="targetGateway")):
    try:
        rm = get_resource_manager(target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    items = rm.list_custom_resources("TCPRoute")
    return {"items": items, "total": len(items), "targetGateway": target_gateway, "namespace": rm.namespace}


@router.delete("/tcp/{name}", response_model=ResourceResponse, summary="Delete a TCPRoute")
def delete_tcp_route(name: str, target_gateway: str = Query(..., alias="targetGateway"), delete_backend: bool = Query(True, alias="deleteBackend")):
    try:
        rm = get_resource_manager(target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    route = rm.get_custom_resource("TCPRoute", name)
    if not route:
        raise HTTPException(status_code=404, detail=f"TCPRoute '{name}' not found")
    backend_name = route.get("metadata", {}).get("labels", {}).get("envoy-agent.io/backend")
    rm.delete_custom_resource("TCPRoute", name)
    if delete_backend and backend_name:
        rm.delete_service(backend_name)
    return ResourceResponse(status="deleted", message=f"TCPRoute '{name}' deleted", resource_name=name, namespace=rm.namespace, resource_type="TCPRoute")


# ==================== UDPRoute ====================

@router.post("/udp", response_model=HTTPRouteResponse, status_code=201, summary="Create a UDPRoute with backend")
def create_udp_route(payload: UDPRouteCreate):
    try:
        rm = get_resource_manager(payload.target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    
    gateway_config = get_gateway_config(payload.target_gateway)
    backend_name = f"{payload.name}-backend"
    
    if rm.resource_exists("UDPRoute", payload.name):
        raise HTTPException(status_code=409, detail=f"UDPRoute '{payload.name}' already exists")
    
    try:
        if not rm.service_exists(backend_name):
            rm.create_backend_for_route(backend_name, payload.backend_url, payload.backend_port, use_tls=False)
        
        spec = {
            "parentRefs": [build_parent_ref(gateway_config.gateway_name)],
            "rules": [{"backendRefs": [build_backend_ref(backend_name, payload.backend_port)]}],
        }
        
        labels = payload.labels or {}
        labels["envoy-agent.io/target-gateway"] = payload.target_gateway
        labels["envoy-agent.io/backend"] = backend_name
        
        rm.create_custom_resource("UDPRoute", payload.name, spec, labels=labels)
        cluster_info = rm.get_cluster_info()
        
        return HTTPRouteResponse(
            status="created", message=f"UDPRoute '{payload.name}' and backend created",
            route_name=payload.name, backend_name=backend_name, namespace=rm.namespace,
            target_gateway=payload.target_gateway, cluster=cluster_info.get("cluster_name"), region=cluster_info.get("region"),
        )
    except ApiException as e:
        rm.delete_service(backend_name)
        raise HTTPException(status_code=422, detail=f"Failed to create UDPRoute: {e.body}")


@router.get("/udp", summary="List UDPRoutes")
def list_udp_routes(target_gateway: str = Query(..., alias="targetGateway")):
    try:
        rm = get_resource_manager(target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    items = rm.list_custom_resources("UDPRoute")
    return {"items": items, "total": len(items), "targetGateway": target_gateway, "namespace": rm.namespace}


@router.delete("/udp/{name}", response_model=ResourceResponse, summary="Delete a UDPRoute")
def delete_udp_route(name: str, target_gateway: str = Query(..., alias="targetGateway"), delete_backend: bool = Query(True, alias="deleteBackend")):
    try:
        rm = get_resource_manager(target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    route = rm.get_custom_resource("UDPRoute", name)
    if not route:
        raise HTTPException(status_code=404, detail=f"UDPRoute '{name}' not found")
    backend_name = route.get("metadata", {}).get("labels", {}).get("envoy-agent.io/backend")
    rm.delete_custom_resource("UDPRoute", name)
    if delete_backend and backend_name:
        rm.delete_service(backend_name)
    return ResourceResponse(status="deleted", message=f"UDPRoute '{name}' deleted", resource_name=name, namespace=rm.namespace, resource_type="UDPRoute")
