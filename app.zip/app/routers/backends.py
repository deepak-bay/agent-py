"""
API routes for Backend and Service resources.
Uses targetGateway to determine cluster/namespace.
"""

from fastapi import APIRouter, HTTPException, Query
from typing import Optional
from kubernetes.client.rest import ApiException

from ..models.backends import (
    ServiceCreate, ServiceUpdate, ServiceResponse,
    BackendCreate, BackendUpdate, BackendResponse,
    SimpleExternalBackend, SimpleFQDNBackend,
    SimpleBackendCreate, SimpleFQDNBackendWithTLS,
)
from ..models.common import ResourceResponse, ResourceListResponse, ErrorResponse
from ..services.resource_manager import ResourceManager
from ..utils.helpers import extract_hostname, extract_port
from ..config import get_gateway_config

router = APIRouter(prefix="/backends", tags=["Backends"])


def get_resource_manager(target_gateway: str) -> ResourceManager:
    """Get resource manager for the specified target gateway."""
    return ResourceManager(target_gateway=target_gateway)


# ==================== Services ====================

@router.post(
    "/services",
    response_model=ResourceResponse,
    status_code=201,
    responses={409: {"model": ErrorResponse}, 422: {"model": ErrorResponse}},
    summary="Create a Service",
    description="Create a Kubernetes Service resource.",
)
def create_service(
    payload: ServiceCreate,
    target_gateway: str = Query(..., alias="targetGateway", description="Target gateway identifier"),
):
    try:
        rm = get_resource_manager(target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    
    if rm.get_service(payload.metadata.name):
        raise HTTPException(
            status_code=409,
            detail=f"Service '{payload.metadata.name}' already exists"
        )
    
    try:
        spec = payload.spec.model_dump(by_alias=True, exclude_none=True)
        rm.create_service(
            name=payload.metadata.name,
            spec=spec,
            labels=payload.metadata.labels,
        )
        
        return ResourceResponse(
            status="created",
            message=f"Service '{payload.metadata.name}' created successfully",
            resource_name=payload.metadata.name,
            namespace=rm.namespace,
            resource_type="Service",
            details={"targetGateway": target_gateway},
        )
    except ApiException as e:
        raise HTTPException(status_code=422, detail=f"Failed to create Service: {e.body}")


@router.get(
    "/services",
    response_model=ResourceListResponse,
    summary="List Services",
    description="List all Service resources for the target gateway.",
)
def list_services(
    target_gateway: str = Query(..., alias="targetGateway", description="Target gateway identifier"),
    label_selector: Optional[str] = Query(None, description="Label selector"),
):
    try:
        rm = get_resource_manager(target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    
    items = rm.list_services(label_selector=label_selector)
    
    return ResourceListResponse(
        items=items,
        total=len(items),
        namespace=rm.namespace,
    )


@router.get(
    "/services/{name}",
    response_model=ServiceResponse,
    responses={404: {"model": ErrorResponse}},
    summary="Get a Service",
    description="Get a Service resource by name.",
)
def get_service(
    name: str,
    target_gateway: str = Query(..., alias="targetGateway", description="Target gateway identifier"),
):
    try:
        rm = get_resource_manager(target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    
    service = rm.get_service(name)
    
    if not service:
        raise HTTPException(status_code=404, detail=f"Service '{name}' not found")
    
    return ServiceResponse(**service)


@router.put(
    "/services/{name}",
    response_model=ResourceResponse,
    responses={404: {"model": ErrorResponse}, 422: {"model": ErrorResponse}},
    summary="Update a Service",
    description="Update an existing Service resource.",
)
def update_service(
    name: str,
    payload: ServiceUpdate,
    target_gateway: str = Query(..., alias="targetGateway", description="Target gateway identifier"),
):
    try:
        rm = get_resource_manager(target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    
    if not rm.get_service(name):
        raise HTTPException(status_code=404, detail=f"Service '{name}' not found")
    
    try:
        spec = payload.spec.model_dump(by_alias=True, exclude_none=True)
        rm.update_service(name, spec)
        
        return ResourceResponse(
            status="updated",
            message=f"Service '{name}' updated successfully",
            resource_name=name,
            namespace=rm.namespace,
            resource_type="Service",
        )
    except ApiException as e:
        raise HTTPException(status_code=422, detail=f"Failed to update Service: {e.body}")


@router.delete(
    "/services/{name}",
    response_model=ResourceResponse,
    responses={404: {"model": ErrorResponse}},
    summary="Delete a Service",
    description="Delete a Service resource.",
)
def delete_service(
    name: str,
    target_gateway: str = Query(..., alias="targetGateway", description="Target gateway identifier"),
):
    try:
        rm = get_resource_manager(target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    
    deleted = rm.delete_service(name)
    if not deleted:
        raise HTTPException(status_code=404, detail=f"Service '{name}' not found")
    
    return ResourceResponse(
        status="deleted",
        message=f"Service '{name}' deleted successfully",
        resource_name=name,
        namespace=rm.namespace,
        resource_type="Service",
    )


# ==================== Simple Service Creation ====================

@router.post(
    "/services/external",
    response_model=ResourceResponse,
    status_code=201,
    summary="Create an ExternalName Service",
    description="Create an ExternalName service pointing to an external URL.",
)
def create_external_service(
    payload: SimpleExternalBackend,
    target_gateway: str = Query(..., alias="targetGateway", description="Target gateway identifier"),
):
    try:
        rm = get_resource_manager(target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    
    if rm.get_service(payload.name):
        raise HTTPException(status_code=409, detail=f"Service '{payload.name}' already exists")
    
    hostname = extract_hostname(str(payload.url))
    port = payload.port or extract_port(str(payload.url))
    
    try:
        rm.create_external_name_service(payload.name, hostname, port)
        
        return ResourceResponse(
            status="created",
            message=f"ExternalName Service '{payload.name}' created",
            resource_name=payload.name,
            namespace=rm.namespace,
            resource_type="Service",
            details={"external_name": hostname, "port": port, "targetGateway": target_gateway},
        )
    except ApiException as e:
        raise HTTPException(status_code=422, detail=f"Failed to create Service: {e.body}")


# ==================== Backend (Envoy Gateway) ====================

@router.post(
    "/full",
    response_model=ResourceResponse,
    status_code=201,
    responses={409: {"model": ErrorResponse}, 422: {"model": ErrorResponse}},
    summary="Create a Backend (Full Spec)",
    description="Create an Envoy Gateway Backend resource with full Kubernetes-style spec.",
)
def create_backend(
    payload: BackendCreate,
    target_gateway: str = Query(..., alias="targetGateway", description="Target gateway identifier"),
):
    try:
        rm = get_resource_manager(target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    
    if rm.resource_exists("Backend", payload.metadata.name):
        raise HTTPException(
            status_code=409,
            detail=f"Backend '{payload.metadata.name}' already exists"
        )
    
    try:
        spec = payload.spec.model_dump(by_alias=True, exclude_none=True)
        rm.create_custom_resource(
            kind="Backend",
            name=payload.metadata.name,
            spec=spec,
            labels=payload.metadata.labels,
            annotations=payload.metadata.annotations,
        )
        
        return ResourceResponse(
            status="created",
            message=f"Backend '{payload.metadata.name}' created successfully",
            resource_name=payload.metadata.name,
            namespace=rm.namespace,
            resource_type="Backend",
            details={"targetGateway": target_gateway},
        )
    except ApiException as e:
        raise HTTPException(status_code=422, detail=f"Failed to create Backend: {e.body}")


@router.get(
    "",
    response_model=ResourceListResponse,
    summary="List Backends",
    description="List all Backend resources for the target gateway.",
)
def list_backends(
    target_gateway: str = Query(..., alias="targetGateway", description="Target gateway identifier"),
    label_selector: Optional[str] = Query(None, description="Label selector"),
):
    try:
        rm = get_resource_manager(target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    
    items = rm.list_custom_resources("Backend", label_selector=label_selector)
    
    return ResourceListResponse(
        items=items,
        total=len(items),
        namespace=rm.namespace,
    )


@router.get(
    "/{name}",
    response_model=BackendResponse,
    responses={404: {"model": ErrorResponse}},
    summary="Get a Backend",
    description="Get a Backend resource by name.",
)
def get_backend(
    name: str,
    target_gateway: str = Query(..., alias="targetGateway", description="Target gateway identifier"),
):
    try:
        rm = get_resource_manager(target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    
    backend = rm.get_custom_resource("Backend", name)
    
    if not backend:
        raise HTTPException(status_code=404, detail=f"Backend '{name}' not found")
    
    return BackendResponse(**backend)


@router.put(
    "/{name}",
    response_model=ResourceResponse,
    responses={404: {"model": ErrorResponse}, 422: {"model": ErrorResponse}},
    summary="Update a Backend",
    description="Update an existing Backend resource.",
)
def update_backend(
    name: str,
    payload: BackendUpdate,
    target_gateway: str = Query(..., alias="targetGateway", description="Target gateway identifier"),
):
    try:
        rm = get_resource_manager(target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    
    if not rm.resource_exists("Backend", name):
        raise HTTPException(status_code=404, detail=f"Backend '{name}' not found")
    
    try:
        spec = payload.spec.model_dump(by_alias=True, exclude_none=True)
        rm.update_custom_resource("Backend", name, spec)
        
        return ResourceResponse(
            status="updated",
            message=f"Backend '{name}' updated successfully",
            resource_name=name,
            namespace=rm.namespace,
            resource_type="Backend",
        )
    except ApiException as e:
        raise HTTPException(status_code=422, detail=f"Failed to update Backend: {e.body}")


@router.delete(
    "/{name}",
    response_model=ResourceResponse,
    responses={404: {"model": ErrorResponse}},
    summary="Delete a Backend",
    description="Delete a Backend resource.",
)
def delete_backend(
    name: str,
    target_gateway: str = Query(..., alias="targetGateway", description="Target gateway identifier"),
):
    try:
        rm = get_resource_manager(target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    
    deleted = rm.delete_custom_resource("Backend", name)
    if not deleted:
        raise HTTPException(status_code=404, detail=f"Backend '{name}' not found")
    
    return ResourceResponse(
        status="deleted",
        message=f"Backend '{name}' deleted successfully",
        resource_name=name,
        namespace=rm.namespace,
        resource_type="Backend",
    )


# ==================== Simple Backend Creation ====================

@router.post(
    "/fqdn",
    response_model=ResourceResponse,
    status_code=201,
    summary="Create a FQDN Backend",
    description="Create a Backend with FQDN endpoint (for external services).",
)
def create_fqdn_backend(
    payload: SimpleFQDNBackend,
    target_gateway: str = Query(..., alias="targetGateway", description="Target gateway identifier"),
):
    try:
        rm = get_resource_manager(target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    
    if rm.resource_exists("Backend", payload.name):
        raise HTTPException(status_code=409, detail=f"Backend '{payload.name}' already exists")
    
    # Build spec
    spec = {
        "endpoints": [{
            "fqdn": {
                "hostname": payload.hostname,
                "port": payload.port,
            }
        }],
    }
    
    # Only include appProtocols if explicitly provided (h2c, ws, wss)
    if payload.app_protocol:
        spec["appProtocols"] = [payload.app_protocol.value]
    
    if payload.enable_tls and payload.ca_secret_name:
        spec["tls"] = {
            "caCertificateRefs": [{
                "kind": "Secret",
                "name": payload.ca_secret_name,
            }]
        }
    
    try:
        rm.create_custom_resource(
            kind="Backend",
            name=payload.name,
            spec=spec,
        )
        
        details = {
            "hostname": payload.hostname,
            "port": payload.port,
            "targetGateway": target_gateway,
        }
        if payload.app_protocol:
            details["appProtocol"] = payload.app_protocol.value
        
        return ResourceResponse(
            status="created",
            message=f"Backend '{payload.name}' created",
            resource_name=payload.name,
            namespace=rm.namespace,
            resource_type="Backend",
            details=details,
        )
    except ApiException as e:
        raise HTTPException(status_code=422, detail=f"Failed to create Backend: {e.body}")


# ==================== Simple Backend with TLS ====================

@router.post(
    "",
    response_model=ResourceResponse,
    status_code=201,
    summary="Create a Backend with TLS support",
    description="""
Create a Backend with simplified TLS configuration.

Supports both no-mTLS (server verification only) and mTLS (mutual TLS).

**No mTLS Example (CA from ConfigMap):**
```json
{
    "name": "mule-backend",
    "backendUrl": "np.api.us01e.bayer.com",
    "backendPort": 443,
    "backendTls": {
        "enabled": true,
        "caSecret": "mule-ca-cert",
        "caKind": "ConfigMap"
    }
}
```

**mTLS Example (CA + Client Cert):**
```json
{
    "name": "mule-backend",
    "backendUrl": "np.api.us01e.bayer.com",
    "backendPort": 443,
    "backendTls": {
        "enabled": true,
        "caSecret": "mule-ca-cert",
        "caKind": "ConfigMap",
        "clientCertSecret": "mule-client-cert"
    }
}
```
""",
)
def create_simple_backend(
    payload: SimpleBackendCreate,
    target_gateway: str = Query(..., alias="targetGateway", description="Target gateway identifier"),
):
    """Create a Backend with TLS support."""
    try:
        rm = get_resource_manager(target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    
    if rm.resource_exists("Backend", payload.name):
        raise HTTPException(status_code=409, detail=f"Backend '{payload.name}' already exists")
    
    # Build spec using the model method
    spec = payload.to_backend_spec()
    
    try:
        rm.create_custom_resource(
            kind="Backend",
            name=payload.name,
            spec=spec,
        )
        
        details = {
            "hostname": payload.backend_url,
            "port": payload.backend_port,
            "targetGateway": target_gateway,
        }
        
        if payload.app_protocol:
            details["appProtocol"] = payload.app_protocol.value
        
        if payload.backend_tls and payload.backend_tls.enabled:
            details["tls"] = {
                "enabled": True,
                "caKind": payload.backend_tls.ca_kind.value,
                "caSecret": payload.backend_tls.ca_secret,
                "mTLS": payload.backend_tls.client_cert_secret is not None,
            }
        
        return ResourceResponse(
            status="created",
            message=f"Backend '{payload.name}' created with TLS",
            resource_name=payload.name,
            namespace=rm.namespace,
            resource_type="Backend",
            details=details,
        )
    except ApiException as e:
        raise HTTPException(status_code=422, detail=f"Failed to create Backend: {e.body}")


@router.post(
    "/fqdn/tls",
    response_model=ResourceResponse,
    status_code=201,
    summary="Create a FQDN Backend with TLS",
    description="""
Create a Backend with FQDN endpoint and TLS configuration.

**No mTLS Example:**
```json
{
    "name": "mule-backend",
    "hostname": "np.api.us01e.bayer.com",
    "port": 443,
    "caConfigMapName": "mule-ca-cert"
}
```

**mTLS Example:**
```json
{
    "name": "mule-backend",
    "hostname": "np.api.us01e.bayer.com",
    "port": 443,
    "caConfigMapName": "mule-ca-cert",
    "clientCertSecretName": "mule-client-cert"
}
```
""",
)
def create_fqdn_backend_with_tls(
    payload: SimpleFQDNBackendWithTLS,
    target_gateway: str = Query(..., alias="targetGateway", description="Target gateway identifier"),
):
    """Create a Backend with FQDN endpoint and TLS."""
    try:
        rm = get_resource_manager(target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    
    if rm.resource_exists("Backend", payload.name):
        raise HTTPException(status_code=409, detail=f"Backend '{payload.name}' already exists")
    
    # Build spec using the model method
    spec = payload.to_backend_spec()
    
    try:
        rm.create_custom_resource(
            kind="Backend",
            name=payload.name,
            spec=spec,
        )
        
        details = {
            "hostname": payload.hostname,
            "port": payload.port,
            "targetGateway": target_gateway,
        }
        
        if payload.app_protocol:
            details["appProtocol"] = payload.app_protocol.value
        
        if payload.ca_configmap_name or payload.ca_secret_name:
            details["tls"] = {
                "enabled": True,
                "caKind": "ConfigMap" if payload.ca_configmap_name else "Secret",
                "caName": payload.ca_configmap_name or payload.ca_secret_name,
                "mTLS": payload.client_cert_secret_name is not None,
            }
        
        return ResourceResponse(
            status="created",
            message=f"Backend '{payload.name}' created with TLS",
            resource_name=payload.name,
            namespace=rm.namespace,
            resource_type="Backend",
            details=details,
        )
    except ApiException as e:
        raise HTTPException(status_code=422, detail=f"Failed to create Backend: {e.body}")
