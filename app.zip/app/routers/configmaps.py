"""
API routes for ConfigMap and TLS Secret resources.
Supports CA certificates for Backend TLS (no-mTLS and mTLS scenarios).

Endpoints:
  POST   /configmaps                    — Create ConfigMap from file paths
  POST   /configmaps/content            — Create ConfigMap from content
  POST   /configmaps/batch              — Batch create ConfigMaps (for 2000+ APIs)
  GET    /configmaps                    — List ConfigMaps
  GET    /configmaps/{name}             — Get ConfigMap
  PUT    /configmaps/{name}             — Update ConfigMap
  DELETE /configmaps/{name}             — Delete ConfigMap
  POST   /configmaps/tls-secret         — Create TLS Secret from file paths
  POST   /configmaps/tls-secret/content — Create TLS Secret from content
"""

import logging
from fastapi import APIRouter, HTTPException, Query
from typing import Optional, List
from kubernetes.client.rest import ApiException

from ..models.configmaps import (
    ConfigMapCreate,
    ConfigMapCreateFromContent,
    ConfigMapResponse,
    TLSSecretCreate,
    TLSSecretCreateFromContent,
    BatchConfigMapCreate,
    BatchConfigMapResponse,
    BatchConfigMapResult,
)
from ..models.common import ResourceResponse, ResourceListResponse, ErrorResponse
from ..services.resource_manager import ResourceManager
from ..config import get_gateway_config

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/configmaps", tags=["ConfigMaps"])


def get_resource_manager(target_gateway: str) -> ResourceManager:
    """Get a resource manager for the specified target gateway."""
    return ResourceManager(target_gateway=target_gateway)


# ==================== ConfigMap Operations ====================

@router.post(
    "",
    response_model=ResourceResponse,
    status_code=201,
    responses={409: {"model": ErrorResponse}, 422: {"model": ErrorResponse}},
    summary="Create a ConfigMap from file paths",
    description="""
Create a ConfigMap by reading content from local file paths.

This is typically used for creating CA certificate ConfigMaps for Backend TLS.

**Example:**
```json
{
    "metadata": {
        "name": "mule-ca-cert"
    },
    "filePaths": {
        "ca.crt": "/path/to/ca-chain.crt"
    }
}
```

The ConfigMap can then be referenced in a Backend TLS configuration:
```yaml
tls:
  caCertificateRefs:
  - group: ""
    kind: ConfigMap
    name: mule-ca-cert
```
""",
)
def create_configmap_from_files(
    payload: ConfigMapCreate,
    target_gateway: str = Query(..., alias="targetGateway", description="Target gateway identifier"),
):
    """Create a ConfigMap from file paths."""
    try:
        rm = get_resource_manager(target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    
    if rm.configmap_exists(payload.metadata.name):
        raise HTTPException(
            status_code=409,
            detail=f"ConfigMap '{payload.metadata.name}' already exists"
        )
    
    try:
        rm.create_configmap_from_files(
            name=payload.metadata.name,
            file_paths=payload.file_paths,
            labels=payload.metadata.labels,
            annotations=payload.metadata.annotations,
        )
        
        return ResourceResponse(
            status="created",
            message=f"ConfigMap '{payload.metadata.name}' created successfully",
            resource_name=payload.metadata.name,
            namespace=rm.namespace,
            resource_type="ConfigMap",
            details={
                "targetGateway": target_gateway,
                "keys": list(payload.file_paths.keys()),
            },
        )
    except FileNotFoundError as e:
        raise HTTPException(status_code=422, detail=f"File not found: {str(e)}")
    except ApiException as e:
        raise HTTPException(status_code=422, detail=f"Failed to create ConfigMap: {e.body}")


@router.post(
    "/content",
    response_model=ResourceResponse,
    status_code=201,
    responses={409: {"model": ErrorResponse}, 422: {"model": ErrorResponse}},
    summary="Create a ConfigMap from content",
    description="""
Create a ConfigMap with direct content (e.g., base64 encoded or raw PEM).

**Example:**
```json
{
    "metadata": {
        "name": "mule-ca-cert"
    },
    "data": {
        "ca.crt": "-----BEGIN CERTIFICATE-----\\n..."
    }
}
```
""",
)
def create_configmap_from_content(
    payload: ConfigMapCreateFromContent,
    target_gateway: str = Query(..., alias="targetGateway", description="Target gateway identifier"),
):
    """Create a ConfigMap from content."""
    try:
        rm = get_resource_manager(target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    
    if rm.configmap_exists(payload.metadata.name):
        raise HTTPException(
            status_code=409,
            detail=f"ConfigMap '{payload.metadata.name}' already exists"
        )
    
    try:
        rm.create_configmap(
            name=payload.metadata.name,
            data=payload.data,
            labels=payload.metadata.labels,
            annotations=payload.metadata.annotations,
        )
        
        return ResourceResponse(
            status="created",
            message=f"ConfigMap '{payload.metadata.name}' created successfully",
            resource_name=payload.metadata.name,
            namespace=rm.namespace,
            resource_type="ConfigMap",
            details={
                "targetGateway": target_gateway,
                "keys": list(payload.data.keys()),
            },
        )
    except ApiException as e:
        raise HTTPException(status_code=422, detail=f"Failed to create ConfigMap: {e.body}")


@router.post(
    "/batch",
    response_model=BatchConfigMapResponse,
    status_code=201,
    summary="Batch create ConfigMaps",
    description="""
Create multiple ConfigMaps in a single request.

Optimized for creating 2000+ APIs where each may need its own CA certificate ConfigMap.

**Example:**
```json
{
    "items": [
        {
            "name": "api-1-ca-cert",
            "filePaths": {"ca.crt": "/path/to/api-1-ca.crt"}
        },
        {
            "name": "api-2-ca-cert",
            "data": {"ca.crt": "-----BEGIN CERTIFICATE-----..."}
        }
    ],
    "failFast": false
}
```

With `failFast: false`, all items are processed and errors are reported per-item.
With `failFast: true`, processing stops on the first error.
""",
)
def batch_create_configmaps(
    payload: BatchConfigMapCreate,
    target_gateway: str = Query(..., alias="targetGateway", description="Target gateway identifier"),
):
    """Batch create ConfigMaps."""
    try:
        rm = get_resource_manager(target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    
    results: List[BatchConfigMapResult] = []
    created_count = 0
    exists_count = 0
    failed_count = 0
    
    for item in payload.items:
        try:
            # Check if exists
            if rm.configmap_exists(item.name):
                results.append(BatchConfigMapResult(
                    name=item.name,
                    status="exists",
                    error=None,
                ))
                exists_count += 1
                continue
            
            # Create from file paths or data
            if item.file_paths:
                rm.create_configmap_from_files(
                    name=item.name,
                    file_paths=item.file_paths,
                    labels=item.labels,
                    annotations=item.annotations,
                )
            elif item.data:
                rm.create_configmap(
                    name=item.name,
                    data=item.data,
                    labels=item.labels,
                    annotations=item.annotations,
                )
            else:
                raise ValueError("Either filePaths or data must be provided")
            
            results.append(BatchConfigMapResult(
                name=item.name,
                status="created",
                error=None,
            ))
            created_count += 1
            
        except Exception as e:
            error_msg = str(e)
            results.append(BatchConfigMapResult(
                name=item.name,
                status="failed",
                error=error_msg,
            ))
            failed_count += 1
            
            if payload.fail_fast:
                # Fill remaining as not processed
                remaining = payload.items[len(results):]
                for remaining_item in remaining:
                    results.append(BatchConfigMapResult(
                        name=remaining_item.name,
                        status="failed",
                        error="Skipped due to failFast",
                    ))
                    failed_count += 1
                break
    
    return BatchConfigMapResponse(
        total=len(payload.items),
        created=created_count,
        exists=exists_count,
        failed=failed_count,
        results=results,
    )


@router.get(
    "",
    response_model=ResourceListResponse,
    summary="List ConfigMaps",
    description="List all ConfigMaps in the target gateway namespace.",
)
def list_configmaps(
    target_gateway: str = Query(..., alias="targetGateway", description="Target gateway identifier"),
    label_selector: Optional[str] = Query(None, description="Label selector"),
):
    """List ConfigMaps."""
    try:
        rm = get_resource_manager(target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    
    items = rm.list_configmaps(label_selector=label_selector)
    
    return ResourceListResponse(
        items=items,
        total=len(items),
        namespace=rm.namespace,
    )


@router.get(
    "/{name}",
    response_model=ConfigMapResponse,
    responses={404: {"model": ErrorResponse}},
    summary="Get a ConfigMap",
    description="Get a ConfigMap by name.",
)
def get_configmap(
    name: str,
    target_gateway: str = Query(..., alias="targetGateway", description="Target gateway identifier"),
):
    """Get a ConfigMap by name."""
    try:
        rm = get_resource_manager(target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    
    configmap = rm.get_configmap(name)
    
    if not configmap:
        raise HTTPException(status_code=404, detail=f"ConfigMap '{name}' not found")
    
    return ConfigMapResponse(**configmap)


@router.put(
    "/{name}",
    response_model=ResourceResponse,
    responses={404: {"model": ErrorResponse}, 422: {"model": ErrorResponse}},
    summary="Update a ConfigMap",
    description="Update an existing ConfigMap.",
)
def update_configmap(
    name: str,
    payload: ConfigMapCreateFromContent,
    target_gateway: str = Query(..., alias="targetGateway", description="Target gateway identifier"),
):
    """Update a ConfigMap."""
    try:
        rm = get_resource_manager(target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    
    if not rm.configmap_exists(name):
        raise HTTPException(status_code=404, detail=f"ConfigMap '{name}' not found")
    
    try:
        rm.update_configmap(
            name=name,
            data=payload.data,
            labels=payload.metadata.labels,
            annotations=payload.metadata.annotations,
        )
        
        return ResourceResponse(
            status="updated",
            message=f"ConfigMap '{name}' updated successfully",
            resource_name=name,
            namespace=rm.namespace,
            resource_type="ConfigMap",
            details={"targetGateway": target_gateway},
        )
    except ApiException as e:
        raise HTTPException(status_code=422, detail=f"Failed to update ConfigMap: {e.body}")


@router.delete(
    "/{name}",
    response_model=ResourceResponse,
    responses={404: {"model": ErrorResponse}},
    summary="Delete a ConfigMap",
    description="Delete a ConfigMap.",
)
def delete_configmap(
    name: str,
    target_gateway: str = Query(..., alias="targetGateway", description="Target gateway identifier"),
):
    """Delete a ConfigMap."""
    try:
        rm = get_resource_manager(target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    
    deleted = rm.delete_configmap(name)
    if not deleted:
        raise HTTPException(status_code=404, detail=f"ConfigMap '{name}' not found")
    
    return ResourceResponse(
        status="deleted",
        message=f"ConfigMap '{name}' deleted successfully",
        resource_name=name,
        namespace=rm.namespace,
        resource_type="ConfigMap",
    )


# ==================== TLS Secret Operations ====================

@router.post(
    "/tls-secret",
    response_model=ResourceResponse,
    status_code=201,
    responses={409: {"model": ErrorResponse}, 422: {"model": ErrorResponse}},
    summary="Create a TLS Secret from file paths",
    description="""
Create a TLS Secret for mTLS client certificates by reading from file paths.

**Example:**
```json
{
    "metadata": {
        "name": "mule-client-cert"
    },
    "tlsCrtPath": "/path/to/tls.crt",
    "tlsKeyPath": "/path/to/tls.key",
    "caCrtPath": "/path/to/ca.crt"
}
```

The Secret can then be referenced in a Backend TLS configuration for mTLS:
```yaml
tls:
  caCertificateRefs:
  - group: ""
    kind: ConfigMap
    name: mule-ca-cert
  clientCertificateRef:
    kind: Secret
    name: mule-client-cert
```
""",
)
def create_tls_secret_from_files(
    payload: TLSSecretCreate,
    target_gateway: str = Query(..., alias="targetGateway", description="Target gateway identifier"),
):
    """Create a TLS Secret from file paths."""
    try:
        rm = get_resource_manager(target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    
    if rm.get_secret(payload.metadata.name):
        raise HTTPException(
            status_code=409,
            detail=f"Secret '{payload.metadata.name}' already exists"
        )
    
    try:
        rm.create_tls_secret_from_files(
            name=payload.metadata.name,
            tls_crt_path=payload.tls_crt_path,
            tls_key_path=payload.tls_key_path,
            ca_crt_path=payload.ca_crt_path,
            labels=payload.metadata.labels,
        )
        
        return ResourceResponse(
            status="created",
            message=f"TLS Secret '{payload.metadata.name}' created successfully",
            resource_name=payload.metadata.name,
            namespace=rm.namespace,
            resource_type="Secret",
            details={
                "targetGateway": target_gateway,
                "type": "kubernetes.io/tls",
                "hasCaCrt": payload.ca_crt_path is not None,
            },
        )
    except FileNotFoundError as e:
        raise HTTPException(status_code=422, detail=f"File not found: {str(e)}")
    except ApiException as e:
        raise HTTPException(status_code=422, detail=f"Failed to create TLS Secret: {e.body}")


@router.post(
    "/tls-secret/content",
    response_model=ResourceResponse,
    status_code=201,
    responses={409: {"model": ErrorResponse}, 422: {"model": ErrorResponse}},
    summary="Create a TLS Secret from content",
    description="""
Create a TLS Secret for mTLS client certificates with direct content.

**Example:**
```json
{
    "metadata": {
        "name": "mule-client-cert"
    },
    "tlsCrt": "-----BEGIN CERTIFICATE-----\\n...",
    "tlsKey": "-----BEGIN PRIVATE KEY-----\\n...",
    "caCrt": "-----BEGIN CERTIFICATE-----\\n..."
}
```
""",
)
def create_tls_secret_from_content(
    payload: TLSSecretCreateFromContent,
    target_gateway: str = Query(..., alias="targetGateway", description="Target gateway identifier"),
):
    """Create a TLS Secret from content."""
    try:
        rm = get_resource_manager(target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    
    if rm.get_secret(payload.metadata.name):
        raise HTTPException(
            status_code=409,
            detail=f"Secret '{payload.metadata.name}' already exists"
        )
    
    try:
        rm.create_tls_secret(
            name=payload.metadata.name,
            tls_crt=payload.tls_crt,
            tls_key=payload.tls_key,
            ca_crt=payload.ca_crt,
            labels=payload.metadata.labels,
        )
        
        return ResourceResponse(
            status="created",
            message=f"TLS Secret '{payload.metadata.name}' created successfully",
            resource_name=payload.metadata.name,
            namespace=rm.namespace,
            resource_type="Secret",
            details={
                "targetGateway": target_gateway,
                "type": "kubernetes.io/tls",
                "hasCaCrt": payload.ca_crt is not None,
            },
        )
    except ApiException as e:
        raise HTTPException(status_code=422, detail=f"Failed to create TLS Secret: {e.body}")
