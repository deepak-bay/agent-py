"""
API routes for Kubernetes Secrets.
Uses targetGateway to determine cluster/namespace.
"""

from fastapi import APIRouter, HTTPException, Query
from typing import Optional
from kubernetes.client.rest import ApiException
import base64

from ..models.secrets import (
    TLSSecretCreate, TLSSecretUpdate,
    BasicAuthSecretCreate, BasicAuthSecretUpdate,
    GenericSecretCreate, GenericSecretUpdate,
    OIDCSecretCreate, APIKeySecretCreate,
    SecretResponse, SecretListResponse,
)
from ..models.common import ResourceResponse, ErrorResponse
from ..services.resource_manager import ResourceManager

router = APIRouter(prefix="/secrets", tags=["Secrets"])


def get_resource_manager(target_gateway: str) -> ResourceManager:
    """Get resource manager for the specified target gateway."""
    return ResourceManager(target_gateway=target_gateway)


# ==================== Generic Secret Operations ====================

@router.post(
    "",
    response_model=ResourceResponse,
    status_code=201,
    responses={409: {"model": ErrorResponse}, 422: {"model": ErrorResponse}},
    summary="Create a Secret",
    description="Create a generic Kubernetes Secret.",
)
def create_secret(
    payload: GenericSecretCreate,
    target_gateway: str = Query(..., alias="targetGateway", description="Target gateway identifier"),
):
    try:
        rm = get_resource_manager(target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    
    if rm.get_secret(payload.metadata.name):
        raise HTTPException(
            status_code=409,
            detail=f"Secret '{payload.metadata.name}' already exists"
        )
    
    try:
        # Combine data and stringData
        data = payload.data or {}
        if payload.string_data:
            for k, v in payload.string_data.items():
                data[k] = base64.b64encode(v.encode()).decode()
        
        # Decode base64 data for the create_secret method (it will re-encode)
        decoded_data = {}
        for k, v in data.items():
            try:
                decoded_data[k] = base64.b64decode(v).decode()
            except Exception:
                decoded_data[k] = v
        
        rm.create_secret(
            name=payload.metadata.name,
            data=decoded_data,
            secret_type=payload.type.value,
            labels=payload.metadata.labels,
        )
        
        return ResourceResponse(
            status="created",
            message=f"Secret '{payload.metadata.name}' created successfully",
            resource_name=payload.metadata.name,
            namespace=rm.namespace,
            resource_type="Secret",
            details={"targetGateway": target_gateway},
        )
    except ApiException as e:
        raise HTTPException(status_code=422, detail=f"Failed to create Secret: {e.body}")


@router.get(
    "",
    response_model=SecretListResponse,
    summary="List Secrets",
    description="List all Secrets for the target gateway (data is not included).",
)
def list_secrets(
    target_gateway: str = Query(..., alias="targetGateway", description="Target gateway identifier"),
    label_selector: Optional[str] = Query(None, description="Label selector"),
):
    try:
        rm = get_resource_manager(target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    
    items = rm.list_secrets(label_selector=label_selector)
    
    return SecretListResponse(
        items=items,
        total=len(items),
        namespace=rm.namespace,
    )


@router.get(
    "/{name}",
    response_model=SecretResponse,
    responses={404: {"model": ErrorResponse}},
    summary="Get a Secret",
    description="Get a Secret by name (data is not included for security).",
)
def get_secret(
    name: str,
    target_gateway: str = Query(..., alias="targetGateway", description="Target gateway identifier"),
):
    try:
        rm = get_resource_manager(target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    
    secret = rm.get_secret(name, include_data=False)
    
    if not secret:
        raise HTTPException(status_code=404, detail=f"Secret '{name}' not found")
    
    return SecretResponse(**secret)


@router.delete(
    "/{name}",
    response_model=ResourceResponse,
    responses={404: {"model": ErrorResponse}},
    summary="Delete a Secret",
    description="Delete a Secret resource.",
)
def delete_secret(
    name: str,
    target_gateway: str = Query(..., alias="targetGateway", description="Target gateway identifier"),
):
    try:
        rm = get_resource_manager(target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    
    deleted = rm.delete_secret(name)
    if not deleted:
        raise HTTPException(status_code=404, detail=f"Secret '{name}' not found")
    
    return ResourceResponse(
        status="deleted",
        message=f"Secret '{name}' deleted successfully",
        resource_name=name,
        namespace=rm.namespace,
        resource_type="Secret",
    )


# ==================== TLS Secrets ====================

@router.post(
    "/tls",
    response_model=ResourceResponse,
    status_code=201,
    summary="Create a TLS Secret",
    description="Create a TLS secret for HTTPS listeners.",
)
def create_tls_secret(
    payload: TLSSecretCreate,
    target_gateway: str = Query(..., alias="targetGateway", description="Target gateway identifier"),
):
    try:
        rm = get_resource_manager(target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    
    if rm.get_secret(payload.name):
        raise HTTPException(status_code=409, detail=f"Secret '{payload.name}' already exists")
    
    try:
        data = {
            "tls.crt": payload.tls_crt,
            "tls.key": payload.tls_key,
        }
        if payload.ca_crt:
            data["ca.crt"] = payload.ca_crt
        
        rm.create_secret(
            name=payload.name,
            data=data,
            secret_type="kubernetes.io/tls",
            labels=payload.labels,
        )
        
        return ResourceResponse(
            status="created",
            message=f"TLS Secret '{payload.name}' created",
            resource_name=payload.name,
            namespace=rm.namespace,
            resource_type="Secret",
            details={"type": "kubernetes.io/tls", "targetGateway": target_gateway},
        )
    except ApiException as e:
        raise HTTPException(status_code=422, detail=f"Failed to create TLS Secret: {e.body}")


# ==================== Basic Auth Secrets ====================

@router.post(
    "/basic-auth",
    response_model=ResourceResponse,
    status_code=201,
    summary="Create a Basic Auth Secret",
    description="Create a secret for basic authentication (htpasswd format).",
)
def create_basic_auth_secret(
    payload: BasicAuthSecretCreate,
    target_gateway: str = Query(..., alias="targetGateway", description="Target gateway identifier"),
):
    try:
        rm = get_resource_manager(target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    
    if rm.get_secret(payload.name):
        raise HTTPException(status_code=409, detail=f"Secret '{payload.name}' already exists")
    
    try:
        data = {
            "username": payload.username,
            "password": payload.password.get_secret_value(),
        }
        
        rm.create_secret(
            name=payload.name,
            data=data,
            secret_type="kubernetes.io/basic-auth",
            labels=payload.labels,
        )
        
        return ResourceResponse(
            status="created",
            message=f"Basic Auth Secret '{payload.name}' created",
            resource_name=payload.name,
            namespace=rm.namespace,
            resource_type="Secret",
            details={"type": "kubernetes.io/basic-auth", "targetGateway": target_gateway},
        )
    except ApiException as e:
        raise HTTPException(status_code=422, detail=f"Failed to create Basic Auth Secret: {e.body}")


# ==================== OIDC Secrets ====================

@router.post(
    "/oidc",
    response_model=ResourceResponse,
    status_code=201,
    summary="Create an OIDC Client Secret",
    description="Create a secret for OIDC client credentials.",
)
def create_oidc_secret(
    payload: OIDCSecretCreate,
    target_gateway: str = Query(..., alias="targetGateway", description="Target gateway identifier"),
):
    try:
        rm = get_resource_manager(target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    
    if rm.get_secret(payload.name):
        raise HTTPException(status_code=409, detail=f"Secret '{payload.name}' already exists")
    
    try:
        data = {
            "client-id": payload.client_id,
            "client-secret": payload.client_secret.get_secret_value(),
        }
        
        rm.create_secret(
            name=payload.name,
            data=data,
            secret_type="Opaque",
            labels=payload.labels,
        )
        
        return ResourceResponse(
            status="created",
            message=f"OIDC Secret '{payload.name}' created",
            resource_name=payload.name,
            namespace=rm.namespace,
            resource_type="Secret",
            details={"type": "Opaque", "purpose": "oidc-client", "targetGateway": target_gateway},
        )
    except ApiException as e:
        raise HTTPException(status_code=422, detail=f"Failed to create OIDC Secret: {e.body}")


# ==================== API Key Secrets ====================

@router.post(
    "/api-keys",
    response_model=ResourceResponse,
    status_code=201,
    summary="Create an API Key Secret",
    description="Create a secret containing API keys for authentication.",
)
def create_api_key_secret(
    payload: APIKeySecretCreate,
    target_gateway: str = Query(..., alias="targetGateway", description="Target gateway identifier"),
):
    try:
        rm = get_resource_manager(target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    
    if rm.get_secret(payload.name):
        raise HTTPException(status_code=409, detail=f"Secret '{payload.name}' already exists")
    
    try:
        rm.create_secret(
            name=payload.name,
            data=payload.api_keys,
            secret_type="Opaque",
            labels=payload.labels,
        )
        
        return ResourceResponse(
            status="created",
            message=f"API Key Secret '{payload.name}' created",
            resource_name=payload.name,
            namespace=rm.namespace,
            resource_type="Secret",
            details={"type": "Opaque", "purpose": "api-keys", "key_count": len(payload.api_keys), "targetGateway": target_gateway},
        )
    except ApiException as e:
        raise HTTPException(status_code=422, detail=f"Failed to create API Key Secret: {e.body}")
