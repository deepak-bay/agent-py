"""
API Management routes for creating, updating, deleting, and retrieving APIs.
An API is a higher-level abstraction that orchestrates routes, backends, and policies.

Endpoints:
  POST   /api                — Create an API
  GET    /apis               — List APIs (full payload)
  GET    /apis/summary       — List API names and paths (lightweight table)
  GET    /apis/{pathName}    — List APIs by path (pathName without leading /)
  GET    /api/{name}         — Get API details
  PUT    /api/{name}         — Update API (diff-based)
  DELETE /api/{name}         — Delete API
"""

import logging
from urllib.parse import urlparse
from fastapi import APIRouter, Body, HTTPException, Query, Response
from typing import Any, Dict, List, Optional, Tuple
from kubernetes.client.rest import ApiException

from ..models.api_management import (
    ApiGatewayCreateRequest,
    ApiGatewayUpdateRequest,
    ApiGatewayResponse,
    ApiGatewayDetailResponse,
    ApiGatewayListResponse,
    ApiSummaryItem,
    ApiSummaryListResponse,
    ApiCreatedResource,
    ALL_POLICIES_PAYLOAD,
    SAMPLE_SWAGGER_SPEC,
)
from ..models.common import ResourceResponse, ErrorResponse
from ..services.resource_manager import ResourceManager
from ..services.openapi_parser import OpenAPIParser
from ..config import get_gateway_config
from ..utils.helpers import build_target_ref

logger = logging.getLogger(__name__)

# Use empty prefix — paths are explicit (/api, /apis)
router = APIRouter(tags=["API Management"])

# Label keys used for tracking API resources
API_NAME_LABEL = "envoy-agent.io/api-name"
MANAGED_BY_LABEL = "envoy-agent.io/managed-by"
MANAGED_BY_VALUE = "api-management"
API_DESCRIPTION_ANNOTATION = "envoy-agent.io/api-description"
API_TYPE_ANNOTATION = "envoy-agent.io/api-type"
API_TAGS_ANNOTATION = "envoy-agent.io/api-tags"

# Maximum rules per HTTPRoute (Kubernetes Gateway API limit)
MAX_RULES_PER_HTTPROUTE = 16


def get_resource_manager(target_gateway: str) -> ResourceManager:
    """Get a resource manager for the specified target gateway."""
    return ResourceManager(target_gateway=target_gateway)


def _build_api_labels(api_name: str, tags: Optional[list] = None) -> dict:
    """Build standard labels for API-managed resources."""
    labels = {
        API_NAME_LABEL: api_name,
        MANAGED_BY_LABEL: MANAGED_BY_VALUE,
    }
    if tags:
        for i, tag in enumerate(tags[:5]):
            safe_tag = tag[:63].replace(" ", "-").lower()
            labels[f"envoy-agent.io/tag-{i}"] = safe_tag
    return labels


def _build_api_annotations(description: str, api_type: str, tags: Optional[list] = None) -> dict:
    """Build annotations for API-managed resources."""
    annotations = {
        API_DESCRIPTION_ANNOTATION: description,
        API_TYPE_ANNOTATION: api_type,
    }
    if tags:
        annotations[API_TAGS_ANNOTATION] = ",".join(tags)
    return annotations


def _build_parent_ref(gateway_name: str) -> dict:
    """Build a parent reference for a route."""
    return {
        "group": "gateway.networking.k8s.io",
        "kind": "Gateway",
        "name": gateway_name,
    }


def _build_backend_ref(name: str, port: int, use_backend_crd: bool = True) -> dict:
    """Build a backend reference for a route.
    
    Args:
        name: Backend name
        port: Backend port
        use_backend_crd: If True, reference Envoy Gateway Backend CRD.
                        If False, reference a Kubernetes Service.
    """
    ref = {"name": name, "port": port}
    if use_backend_crd:
        ref["group"] = "gateway.envoyproxy.io"
        ref["kind"] = "Backend"
    return ref


def _normalize_path(path: str) -> str:
    """Normalize a path to start with /."""
    if not path.startswith("/"):
        path = f"/{path}"
    return path


def _build_swagger_rules(
    spec_routes: List[Dict[str, Any]],
    base_path: str,
    backend_name: str,
    backend_port: int,
) -> List[Dict[str, Any]]:
    """Build deduplicated, method-aware HTTPRoute rules from parsed OpenAPI routes.

    Multiple OpenAPI paths can normalise to the same Gateway path once path
    parameters are stripped (e.g. ``/hosts``, ``/hosts/{id}``,
    ``/hosts/{id}/cfg`` all become ``/hosts``).  This helper:

    1. Groups routes by their normalised full path.
    2. Merges the HTTP methods from every route that shares a path.
    3. Produces one rule per unique path with one ``match`` entry per method,
       so that only spec-defined methods are allowed through the gateway.
    """
    # Collect unique methods per normalised path (preserving insertion order)
    path_methods: Dict[str, set] = {}
    for route_info in spec_routes:
        swagger_path = route_info["path"]
        if not swagger_path.startswith("/"):
            swagger_path = f"/{swagger_path}"

        full_path = (
            f"{base_path.rstrip('/')}{swagger_path}" if base_path != "/" else swagger_path
        )
        while "//" in full_path:
            full_path = full_path.replace("//", "/")

        if full_path not in path_methods:
            path_methods[full_path] = set()
        path_methods[full_path].update(route_info.get("methods", []))

    # Build one rule per unique path
    backend_ref = _build_backend_ref(backend_name, backend_port)
    rules: List[Dict[str, Any]] = []
    for full_path, methods in path_methods.items():
        matches = []
        for method in sorted(methods):  # sorted for deterministic output
            matches.append({
                "path": {"type": "PathPrefix", "value": full_path},
                "method": method,
            })
        rules.append({"matches": matches, "backendRefs": [backend_ref]})

    return rules


def _create_or_update_http_routes_with_sharding(
    rm: ResourceManager,
    api_name: str,
    all_rules: List[Dict[str, Any]],
    parent_ref: dict,
    labels: dict,
    annotations: dict,
    is_update: bool = False,
) -> List[ApiCreatedResource]:
    """
    Create or update HTTPRoute(s) with automatic sharding if rules exceed the limit.
    
    Returns a list of created/updated resources.
    Handles cleanup of old shards during updates.
    """
    created_resources = []
    total_rules = len(all_rules)
    
    if total_rules <= MAX_RULES_PER_HTTPROUTE:
        # Single HTTPRoute (no sharding needed)
        spec = {
            "parentRefs": [parent_ref],
            "rules": all_rules,
        }
        
        if is_update:
            # Delete any old shards that may exist
            _cleanup_old_shards(rm, api_name, 0)
            rm.update_custom_resource("HTTPRoute", api_name, spec, annotations=annotations)
            created_resources.append(ApiCreatedResource(
                resource_type="HTTPRoute",
                resource_name=api_name,
                status="updated",
            ))
        else:
            rm.create_custom_resource(
                kind="HTTPRoute",
                name=api_name,
                spec=spec,
                labels=labels,
                annotations=annotations,
            )
            created_resources.append(ApiCreatedResource(
                resource_type="HTTPRoute",
                resource_name=api_name,
                status="created",
            ))
        logger.info(f"{'Updated' if is_update else 'Created'} HTTPRoute: {api_name} with {total_rules} rules")
    else:
        # Multiple HTTPRoutes required (sharding)
        num_shards = (total_rules + MAX_RULES_PER_HTTPROUTE - 1) // MAX_RULES_PER_HTTPROUTE
        shard_annotations = annotations.copy()
        shard_annotations["envoy-agent.io/route-sharded"] = "true"
        shard_annotations["envoy-agent.io/route-shard-count"] = str(num_shards)
        
        logger.info(f"{'Updating' if is_update else 'Creating'} {total_rules} rules across {num_shards} HTTPRoute resources")
        
        for shard_idx in range(num_shards):
            start_idx = shard_idx * MAX_RULES_PER_HTTPROUTE
            end_idx = min(start_idx + MAX_RULES_PER_HTTPROUTE, total_rules)
            shard_rules = all_rules[start_idx:end_idx]
            
            # First shard uses the main name, others get -shard-N suffix
            if shard_idx == 0:
                route_name = api_name
            else:
                route_name = f"{api_name}-shard-{shard_idx}"
            
            shard_labels = labels.copy()
            shard_labels["envoy-agent.io/route-shard-index"] = str(shard_idx)
            
            shard_specific_annotations = shard_annotations.copy()
            shard_specific_annotations["envoy-agent.io/route-shard-index"] = str(shard_idx)
            
            spec = {
                "parentRefs": [parent_ref],
                "rules": shard_rules,
            }
            
            if is_update:
                # Check if this shard already exists
                if rm.resource_exists("HTTPRoute", route_name):
                    rm.update_custom_resource("HTTPRoute", route_name, spec, annotations=shard_specific_annotations)
                    created_resources.append(ApiCreatedResource(
                        resource_type="HTTPRoute",
                        resource_name=route_name,
                        status="updated",
                    ))
                else:
                    rm.create_custom_resource(
                        kind="HTTPRoute",
                        name=route_name,
                        spec=spec,
                        labels=shard_labels,
                        annotations=shard_specific_annotations,
                    )
                    created_resources.append(ApiCreatedResource(
                        resource_type="HTTPRoute",
                        resource_name=route_name,
                        status="created",
                    ))
            else:
                rm.create_custom_resource(
                    kind="HTTPRoute",
                    name=route_name,
                    spec=spec,
                    labels=shard_labels,
                    annotations=shard_specific_annotations,
                )
                created_resources.append(ApiCreatedResource(
                    resource_type="HTTPRoute",
                    resource_name=route_name,
                    status="created",
                ))
            logger.info(f"{'Updated' if is_update else 'Created'} HTTPRoute shard {shard_idx+1}/{num_shards}: {route_name} with {len(shard_rules)} rules")
        
        # Cleanup old shards if updating and shard count decreased
        if is_update:
            _cleanup_old_shards(rm, api_name, num_shards)
    
    return created_resources


def _cleanup_old_shards(rm: ResourceManager, api_name: str, current_shard_count: int):
    """
    Delete old shard HTTPRoutes that are no longer needed.
    Starting from current_shard_count, delete any routes with -shard-N suffix.
    """
    shard_idx = current_shard_count
    while True:
        route_name = f"{api_name}-shard-{shard_idx}"
        if rm.resource_exists("HTTPRoute", route_name):
            try:
                rm.delete_custom_resource("HTTPRoute", route_name)
                logger.info(f"Deleted old shard: {route_name}")
            except Exception as e:
                logger.warning(f"Failed to delete old shard {route_name}: {e}")
                break
        else:
            break
        shard_idx += 1


def _parse_upstream_url(url: str) -> Tuple[str, int, bool]:
    """Parse an upstream URL to extract hostname, port, and TLS flag."""
    parsed = urlparse(url)
    scheme = parsed.scheme.lower() if parsed.scheme else "http"
    uses_tls = scheme == "https"
    hostname = parsed.hostname or url
    port = parsed.port or (443 if uses_tls else 80)
    return hostname, port, uses_tls


# ==================== Policy Creation Helpers ====================

# Map of supported policy-payload types to their handler info
SUPPORTED_POLICY_TYPES = {
    # SecurityPolicy types
    "jwt-validation": {"kind": "SecurityPolicy", "default_suffix": "jwt"},
    "jwt": {"kind": "SecurityPolicy", "default_suffix": "jwt"},
    "cors": {"kind": "SecurityPolicy", "default_suffix": "cors"},
    "api-key": {"kind": "SecurityPolicy", "default_suffix": "api-key"},
    "basic-auth": {"kind": "SecurityPolicy", "default_suffix": "basic-auth"},
    "ip-allow": {"kind": "SecurityPolicy", "default_suffix": "ip-allowlist"},
    "ip-allowlist": {"kind": "SecurityPolicy", "default_suffix": "ip-allowlist"},
    "ip-block": {"kind": "SecurityPolicy", "default_suffix": "ip-blocklist"},
    "ip-blocklist": {"kind": "SecurityPolicy", "default_suffix": "ip-blocklist"},
    "external-auth": {"kind": "SecurityPolicy", "default_suffix": "ext-auth"},
    # BackendTrafficPolicy types
    "rate-limit": {"kind": "BackendTrafficPolicy", "default_suffix": "rate-limit"},
    "circuit-breaker": {"kind": "BackendTrafficPolicy", "default_suffix": "circuit-breaker"},
    "retry": {"kind": "BackendTrafficPolicy", "default_suffix": "retry"},
}


def _parse_policy_payload(policy_payload: List[Dict[str, Any]]) -> List[Tuple[str, str, Dict[str, Any]]]:
    """
    Parse the policy-payload list of objects.

    Each object must have a 'type' field.
    Optional 'name' field — auto-generated if absent.
    Returns a list of (policy_type, policy_name, config) tuples.
    """
    policies = []
    for item in policy_payload:
        if not isinstance(item, dict):
            raise ValueError(
                f"Each policy-payload item must be an object with a 'type' field, got: {type(item).__name__}"
            )
        ptype = item.get("type")
        if not ptype:
            raise ValueError(
                f"Policy object missing required 'type' field: {item}"
            )
        pname = item.get("name", "")
        # Everything except 'type' and 'name' is config
        config = {k: v for k, v in item.items() if k not in ("type", "name")}
        policies.append((ptype, pname, config))
    return policies


def _resolve_policy_name(policy_name: str, api_name: str, default_suffix: str) -> str:
    """
    Resolve the final policy resource name.

    Always prefixed with '{api_name}-' so policies are namespaced per API.
    - If policy_name is provided: '{api_name}-{policy_name}'
      (unless it already starts with '{api_name}-')
    - If policy_name is empty: '{api_name}-{default_suffix}'
    """
    if policy_name:
        if policy_name.startswith(f"{api_name}-"):
            return policy_name
        return f"{api_name}-{policy_name}"
    return f"{api_name}-{default_suffix}"


def _create_policy_resource(
    rm: ResourceManager,
    policy_type: str,
    policy_name: str,
    route_name: str,
    api_name: str,
    labels: dict,
    config: Optional[Dict[str, Any]] = None,
) -> ApiCreatedResource:
    """
    Create a policy resource based on the policy type and optional config.

    If config is provided, uses the config fields to build the spec.
    Otherwise, creates a skeleton policy with sensible defaults.
    targetRoute is always derived from route_name (the API name).
    """
    config = config or {}
    ptype = policy_type.lower().replace("_", "-")
    type_info = SUPPORTED_POLICY_TYPES.get(ptype)
    if not type_info:
        raise ValueError(
            f"Unknown policy type: '{policy_type}'. "
            f"Supported: {', '.join(sorted(set(SUPPORTED_POLICY_TYPES.keys())))}"
        )

    kind = type_info["kind"]
    resolved_name = _resolve_policy_name(policy_name, api_name, type_info["default_suffix"])
    target_ref = build_target_ref("HTTPRoute", route_name)

    # Build spec based on policy type, using config if available
    if ptype in ("jwt-validation", "jwt"):
        provider = {"name": resolved_name}
        if config.get("issuer"):
            provider["issuer"] = config["issuer"]
        if config.get("jwksUri"):
            provider["remoteJWKS"] = {"uri": config["jwksUri"]}
        if config.get("audiences"):
            provider["audiences"] = config["audiences"]
        if config.get("claimToHeaders"):
            provider["claimToHeaders"] = [
                {"claim": k, "header": v}
                for k, v in config["claimToHeaders"].items()
            ]
        spec = {"targetRef": target_ref, "jwt": {"providers": [provider]}}

    elif ptype == "cors":
        raw_origins = config.get("allowedOrigins", ["*"])
        # Envoy Gateway CRD requires origins to be '*' or full URLs (http:// or https://)
        origins = []
        for o in raw_origins:
            if o == "*" or o.startswith("http://") or o.startswith("https://"):
                origins.append(o)
            else:
                origins.append(f"https://{o}")
        cors_config = {
            "allowOrigins": origins,
            "allowMethods": config.get("allowedMethods", ["GET", "POST", "PUT", "DELETE", "OPTIONS"]),
            "allowHeaders": config.get("allowedHeaders", ["Content-Type", "Authorization"]),
            "allowCredentials": config.get("allowCredentials", False),
            "maxAge": config.get("maxAge", "24h"),
        }
        if config.get("exposeHeaders"):
            cors_config["exposeHeaders"] = config["exposeHeaders"]
        spec = {"targetRef": target_ref, "cors": cors_config}

    elif ptype == "api-key":
        header_name = config.get("headerName", "x-api-key")
        credentials = []
        if config.get("apiKeysSecret"):
            credentials = [{"kind": "Secret", "name": config["apiKeysSecret"]}]
        spec = {
            "targetRef": target_ref,
            "apiKey": {
                "extractFrom": {"headers": [header_name]},
                "credentials": credentials,
            },
        }

    elif ptype == "basic-auth":
        users_secret = config.get("usersSecret", f"{api_name}-users")
        spec = {
            "targetRef": target_ref,
            "basicAuth": {"users": {"kind": "Secret", "name": users_secret}},
        }

    elif ptype in ("ip-allow", "ip-allowlist"):
        cidrs = config.get("allowedCidrs", [])
        spec = {
            "targetRef": target_ref,
            "authorization": {
                "defaultAction": "Deny",
                "rules": [{
                    "name": "allow-cidrs",
                    "action": "Allow",
                    "principal": {"clientCIDRs": cidrs},
                }],
            },
        }

    elif ptype in ("ip-block", "ip-blocklist"):
        cidrs = config.get("blockedCidrs", [])
        spec = {
            "targetRef": target_ref,
            "authorization": {
                "defaultAction": "Allow",
                "rules": [{
                    "name": "block-cidrs",
                    "action": "Deny",
                    "principal": {"clientCIDRs": cidrs},
                }],
            },
        }

    elif ptype == "external-auth":
        auth_svc = config.get("authServiceName", f"{api_name}-auth-service")
        auth_port = config.get("authServicePort", 9001)
        auth_path = config.get("authPath", "/auth/verify")
        headers_to_auth = config.get("headersToAuth", ["Authorization"])
        failure_mode = config.get("failureMode", "FailClosed")
        spec = {
            "targetRef": target_ref,
            "extAuth": {
                "http": {
                    "backendRef": {"name": auth_svc, "port": auth_port},
                    "path": auth_path,
                    "headersToBackend": headers_to_auth,
                },
                "failureMode": failure_mode,
            },
        }

    elif ptype == "rate-limit":
        requests = config.get("requests", 100)
        unit = config.get("unit", "Minute")
        spec = {
            "targetRef": target_ref,
            "rateLimit": {
                "type": "Global",
                "global": {
                    "rules": [{"limit": {"requests": requests, "unit": unit}}],
                },
            },
        }

    elif ptype == "circuit-breaker":
        spec = {
            "targetRef": target_ref,
            "circuitBreaker": {
                "maxConnections": config.get("maxConnections", 1024),
                "maxPendingRequests": config.get("maxPendingRequests", 128),
                "maxParallelRequests": config.get("maxParallelRequests", 128),
            },
        }

    elif ptype == "retry":
        triggers = []
        if config.get("retryOn5xx", True):
            triggers.append("5xx")
        if config.get("retryOnConnectFailure", True):
            triggers.append("connect-failure")
        spec = {
            "targetRef": target_ref,
            "retry": {
                "numRetries": config.get("numRetries", 3),
                "retryOn": {"triggers": triggers} if triggers else None,
                "perRetry": {"timeout": config.get("perRetryTimeout", "5s")},
            },
        }
    else:
        raise ValueError(f"Unknown policy type: '{policy_type}'")

    rm.create_custom_resource(
        kind=kind,
        name=resolved_name,
        spec=spec,
        labels=labels,
    )

    return ApiCreatedResource(
        resource_type=kind,
        resource_name=resolved_name,
        status="created",
    )


# ==================== Reverse-engineer policy specs to user-facing format ====================

def _reconstruct_policy_payload(policy: Dict[str, Any], api_name: str) -> Optional[Dict[str, Any]]:
    """
    Convert a K8s SecurityPolicy or BackendTrafficPolicy resource back into
    the user-facing policy-payload object format.

    Returns a dict like {"type": "cors", "name": "my-cors", ...} or None if
    the policy kind/spec is unrecognised.
    """
    spec = policy.get("spec", {})
    p_name = policy.get("metadata", {}).get("name", "")
    kind = policy.get("kind", "")

    # Strip the api-name prefix from the policy name for the user-facing payload
    user_name = p_name
    prefix = f"{api_name}-"
    if user_name.startswith(prefix):
        user_name = user_name[len(prefix):]

    # --- SecurityPolicy ---
    if kind == "SecurityPolicy" or spec.get("jwt") or spec.get("cors") or spec.get("apiKey") or spec.get("basicAuth") or spec.get("authorization") or spec.get("extAuth"):
        # JWT
        if spec.get("jwt"):
            providers = spec["jwt"].get("providers", [])
            obj: Dict[str, Any] = {"type": "JWT-validation", "name": user_name}
            if providers:
                prov = providers[0]
                if prov.get("issuer"):
                    obj["issuer"] = prov["issuer"]
                jwks = prov.get("remoteJWKS", {})
                if jwks.get("uri"):
                    obj["jwksUri"] = jwks["uri"]
                if prov.get("audiences"):
                    obj["audiences"] = prov["audiences"]
                if prov.get("claimToHeaders"):
                    obj["claimToHeaders"] = {
                        c["claim"]: c["header"] for c in prov["claimToHeaders"]
                    }
            return obj

        # CORS
        if spec.get("cors"):
            cors = spec["cors"]
            obj = {"type": "cors", "name": user_name}
            if cors.get("allowOrigins"):
                obj["allowedOrigins"] = cors["allowOrigins"]
            if cors.get("allowMethods"):
                obj["allowedMethods"] = cors["allowMethods"]
            if cors.get("allowHeaders"):
                obj["allowedHeaders"] = cors["allowHeaders"]
            if cors.get("exposeHeaders"):
                obj["exposeHeaders"] = cors["exposeHeaders"]
            if "allowCredentials" in cors:
                obj["allowCredentials"] = cors["allowCredentials"]
            if cors.get("maxAge"):
                obj["maxAge"] = cors["maxAge"]
            return obj

        # API Key
        if spec.get("apiKey"):
            ak = spec["apiKey"]
            obj = {"type": "api-key", "name": user_name}
            headers = ak.get("extractFrom", {}).get("headers", [])
            if headers:
                obj["headerName"] = headers[0]
            creds = ak.get("credentials", [])
            if creds:
                obj["apiKeysSecret"] = creds[0].get("name", "")
            return obj

        # Basic Auth
        if spec.get("basicAuth"):
            ba = spec["basicAuth"]
            obj = {"type": "basic-auth", "name": user_name}
            users = ba.get("users", {})
            if users.get("name"):
                obj["usersSecret"] = users["name"]
            return obj

        # Authorization (ip-allow / ip-block)
        if spec.get("authorization"):
            auth = spec["authorization"]
            default_action = auth.get("defaultAction", "")
            rules = auth.get("rules", [])
            cidrs = []
            if rules:
                cidrs = rules[0].get("principal", {}).get("clientCIDRs", [])
            if default_action == "Deny":
                return {"type": "ip-allow", "name": user_name, "allowedCidrs": cidrs}
            else:
                return {"type": "ip-block", "name": user_name, "blockedCidrs": cidrs}

        # External Auth
        if spec.get("extAuth"):
            ea = spec["extAuth"]
            http = ea.get("http", {})
            backend_ref = http.get("backendRef", {})
            obj: Dict[str, Any] = {"type": "external-auth", "name": user_name}
            if backend_ref.get("name"):
                obj["authServiceName"] = backend_ref["name"]
            if backend_ref.get("port"):
                obj["authServicePort"] = backend_ref["port"]
            if http.get("path"):
                obj["authPath"] = http["path"]
            if http.get("headersToBackend"):
                obj["headersToAuth"] = http["headersToBackend"]
            if ea.get("failureMode"):
                obj["failureMode"] = ea["failureMode"]
            return obj

    # --- BackendTrafficPolicy ---
    if kind == "BackendTrafficPolicy" or spec.get("rateLimit") or spec.get("circuitBreaker") or spec.get("retry"):
        # Rate Limit
        if spec.get("rateLimit"):
            rl = spec["rateLimit"]
            obj = {"type": "rate-limit", "name": user_name}
            gl = rl.get("global", {})
            rules = gl.get("rules", [])
            if rules:
                limit = rules[0].get("limit", {})
                obj["requests"] = limit.get("requests", 100)
                obj["unit"] = limit.get("unit", "Minute")
            return obj

        # Circuit Breaker
        if spec.get("circuitBreaker"):
            cb = spec["circuitBreaker"]
            return {
                "type": "circuit-breaker",
                "name": user_name,
                "maxConnections": cb.get("maxConnections", 1024),
                "maxPendingRequests": cb.get("maxPendingRequests", 128),
                "maxParallelRequests": cb.get("maxParallelRequests", 128),
            }

        # Retry
        if spec.get("retry"):
            rt = spec["retry"]
            obj: Dict[str, Any] = {"type": "retry", "name": user_name}
            obj["numRetries"] = rt.get("numRetries", 3)
            per_retry = rt.get("perRetry", {})
            if per_retry.get("timeout"):
                obj["perRetryTimeout"] = per_retry["timeout"]
            triggers = rt.get("retryOn", {}).get("triggers", [])
            obj["retryOn5xx"] = "5xx" in triggers
            obj["retryOnConnectFailure"] = "connect-failure" in triggers
            return obj

    return None


def _reconstruct_api_gateway_payload(
    rm: ResourceManager,
    api_name: str,
    existing: Dict[str, Any],
    target_gateway: str,
) -> Dict[str, Any]:
    """
    Reconstruct the full api-gateway payload from K8s resources.

    Returns a dict in the same format accepted by create/update endpoints,
    so the user can copy-paste it directly into a PUT request.
    """
    # Basic fields from annotations/labels
    api_gateway: Dict[str, Any] = {
        "name": api_name,
        "description": existing.get("description", ""),
        "api-type": existing.get("api_type", "http"),
        "target-gateway": target_gateway,
        "path": existing.get("path", "/"),
    }

    # Tags
    tags = existing.get("tags", [])
    if tags:
        api_gateway["tags"] = tags

    # Upstream from backend service annotations
    upstream: Dict[str, Any] = {"url": ""}
    if existing.get("backend"):
        backend_meta = existing["backend"].get("metadata") or {}
        backend_annots = backend_meta.get("annotations") or {}
        upstream_url = backend_annots.get("envoy-agent.io/upstream-url", "")
        tls_cert = backend_annots.get("envoy-agent.io/tls-certificate")
        upstream["url"] = upstream_url
        if tls_cert:
            upstream["tls-certificate"] = tls_cert
    api_gateway["upstream"] = upstream

    # Policies
    policies = existing.get("policies", [])
    if policies:
        policy_payload = []
        for p in policies:
            reconstructed = _reconstruct_policy_payload(p, api_name)
            if reconstructed:
                policy_payload.append(reconstructed)
        if policy_payload:
            api_gateway["policy-payload"] = policy_payload

    result: Dict[str, Any] = {"api-gateway": api_gateway}
    return result


# ==================== Path Uniqueness Check ====================

def _check_path_uniqueness(
    rm: ResourceManager,
    path: str,
    exclude_api_name: Optional[str] = None,
) -> Optional[str]:
    """
    Check if a path is already used by another managed API on the same target gateway.

    Returns the name of the conflicting API if the path is taken, or None if available.
    Optionally excludes a specific API name (used during updates so the API's own
    path doesn't conflict with itself).
    """
    managed_routes = rm.list_custom_resources(
        "HTTPRoute",
        label_selector=f"{MANAGED_BY_LABEL}={MANAGED_BY_VALUE}",
    )

    normalized = _normalize_path(path)

    for route in managed_routes:
        route_meta = route.get("metadata", {})
        route_name = route_meta.get("name", "")
        route_labels = route_meta.get("labels", {})

        # Skip the API being updated
        api_name = route_labels.get(API_NAME_LABEL, route_name)
        if exclude_api_name and api_name == exclude_api_name:
            continue

        # Extract path from route spec
        rules = route.get("spec", {}).get("rules", [])
        if rules:
            matches = rules[0].get("matches", [])
            if matches:
                existing_path = matches[0].get("path", {}).get("value")
                if existing_path and _normalize_path(existing_path) == normalized:
                    return api_name

    return None


# ==================== Fetch Existing API Helper ====================

def _fetch_existing_api(rm: ResourceManager, name: str) -> dict:
    """
    Fetch the full existing state of an API by name.

    Returns a dict with:
      route, route_kind, backend, swagger_routes, policies, annotations, labels
    or None if the API does not exist.
    """
    route = rm.get_custom_resource("HTTPRoute", name)
    route_kind = "HTTPRoute"
    if not route:
        try:
            route = rm.get_custom_resource("TLSRoute", name)
            route_kind = "TLSRoute"
        except ApiException as e:
            if e.status == 404:
                # TLSRoute CRD not installed — treat as not found
                route = None
            else:
                raise

    if not route:
        return None

    route_labels = route.get("metadata", {}).get("labels", {})
    route_annotations = route.get("metadata", {}).get("annotations", {})

    # Extract swagger rules from the main route (consolidated into rules[1:])
    # When a swagger spec is imported, paths are stored as additional rules
    # in the main route rather than as separate HTTPRoute resources.
    swagger_rules = []
    if route_kind == "HTTPRoute" and route_annotations.get("envoy-agent.io/swagger-imported") == "true":
        all_rules = route.get("spec", {}).get("rules", [])
        if len(all_rules) > 1:
            swagger_rules = all_rules[1:]

    # Fetch all attached policies
    all_policies = []
    for policy_kind in ("SecurityPolicy", "BackendTrafficPolicy"):
        policies = rm.list_custom_resources(
            policy_kind,
            label_selector=f"{API_NAME_LABEL}={name}",
        )
        all_policies.extend(policies)

    # Fetch Backend CRD
    backend_name = f"{name}-backend"
    backend = rm.get_custom_resource(kind="Backend", name=backend_name)

    # Extract existing path from route spec
    existing_path = None
    if route_kind == "HTTPRoute":
        rules = route.get("spec", {}).get("rules", [])
        if rules:
            matches = rules[0].get("matches", [])
            if matches:
                existing_path = matches[0].get("path", {}).get("value")

    # Extract existing policy names from resources
    existing_policy_names = []
    for p in all_policies:
        p_meta = p.get("metadata", {})
        existing_policy_names.append({
            "name": p_meta.get("name"),
            "kind": p.get("kind", p_meta.get("labels", {}).get("kind", "SecurityPolicy")),
        })

    return {
        "route": route,
        "route_kind": route_kind,
        "labels": route_labels,
        "annotations": route_annotations,
        "backend": backend,
        "backend_name": backend_name,
        "swagger_routes": swagger_rules,
        "policies": all_policies,
        "policy_names": existing_policy_names,
        "description": route_annotations.get(API_DESCRIPTION_ANNOTATION, ""),
        "api_type": route_annotations.get(API_TYPE_ANNOTATION, "http"),
        "tags": route_annotations.get(API_TAGS_ANNOTATION, "").split(",")
                if route_annotations.get(API_TAGS_ANNOTATION) else [],
        "path": existing_path,
        "managed": route_labels.get(MANAGED_BY_LABEL) == MANAGED_BY_VALUE,
    }


# ==================== OpenAPI example payloads ====================

_UPDATE_POLICIES = [
    {**p, "name": f"updated-{p['name']}"} for p in ALL_POLICIES_PAYLOAD
]

_CREATE_EXAMPLES = {
    "basic_no_policies": {
        "summary": "Basic API — no policies, no swagger (policy-payload is optional)",
        "value": {
            "api-gateway": {
                "name": "my-api",
                "description": "A simple API without any policies",
                "api-type": "http",
                "upstream": {"url": "http://my-backend.internal:8080"},
                "target-gateway": "us-envoy-1",
                "path": "/my-api",
            }
        },
    },
    "all_10_policies": {
        "summary": "API with ALL 10 supported policies (all optional — include only what you need)",
        "value": {
            "api-gateway": {
                "name": "full-policy-api",
                "description": "API with all 10 supported policy types — all optional, pick only what you need",
                "api-type": "http",
                "policy-payload": ALL_POLICIES_PAYLOAD,
                "tags": ["production", "full-policies"],
                "upstream": {
                    "url": "https://secure-backend.example.com",
                    "tls-certificate": "backend-tls-cert",
                },
                "target-gateway": "us-envoy-1",
                "path": "/full-policy",
            }
        },
    },
    "all_policies_with_openapi_spec": {
        "summary": "API with all policies + full OpenAPI 3.0 swagger spec",
        "value": {
            "api-gateway": {
                "name": "petstore-api",
                "description": "Pet Store API with all policies and OpenAPI spec",
                "api-type": "http",
                "policy-payload": ALL_POLICIES_PAYLOAD,
                "tags": ["petstore", "sample"],
                "upstream": {
                    "url": "https://petstore.example.com",
                    "tls-certificate": "petstore-tls-cert",
                },
                "target-gateway": "us-envoy-1",
                "path": "/petstore",
            },
            "swagger": SAMPLE_SWAGGER_SPEC,
        },
    },
    "tls_api": {
        "summary": "TLS API (creates TLSRoute) — no policies",
        "value": {
            "api-gateway": {
                "name": "tls-api",
                "description": "TLS passthrough API",
                "api-type": "tls",
                "upstream": {
                    "url": "https://tls-backend.example.com",
                    "tls-certificate": "tls-cert-ref",
                },
                "target-gateway": "us-envoy-1",
                "path": "/tls",
            }
        },
    },
}

_UPDATE_EXAMPLES = {
    "all_10_policies": {
        "summary": "Update API with ALL 10 supported policies (all optional)",
        "value": {
            "api-gateway": {
                "name": "my-api",
                "description": "Updated with all 10 policy types — all optional",
                "api-type": "http",
                "policy-payload": _UPDATE_POLICIES,
                "tags": ["updated", "full-policies"],
                "upstream": {"url": "http://new-backend.com", "tls-certificate": "new-tls-cert"},
                "target-gateway": "us-envoy-1",
                "path": "/updated-path",
            }
        },
    },
    "few_policies": {
        "summary": "Update API with a few policies",
        "value": {
            "api-gateway": {
                "name": "my-api",
                "description": "Updated with selected policies",
                "api-type": "http",
                "policy-payload": [
                    {"type": "JWT-validation", "name": "updated-jwt", "issuer": "https://auth.example.com", "jwksUri": "https://auth.example.com/.well-known/jwks.json"},
                    {"type": "rate-limit", "name": "updated-rl", "requests": 200, "unit": "Minute"},
                ],
                "upstream": {"url": "http://new-backend.com"},
                "target-gateway": "us-envoy-1",
                "path": "/updated-path",
            }
        },
    },
    "remove_all_policies": {
        "summary": "Update API — remove all policies",
        "value": {
            "api-gateway": {
                "name": "my-api",
                "description": "Updated — all policies removed",
                "api-type": "http",
                "policy-payload": [],
                "upstream": {"url": "http://backend.com"},
                "target-gateway": "us-envoy-1",
                "path": "/my-api",
            }
        },
    },
    "all_policies_with_openapi_spec": {
        "summary": "Update API with all policies + full OpenAPI 3.0 swagger spec",
        "value": {
            "api-gateway": {
                "name": "my-api",
                "description": "Updated with all policies and new swagger spec",
                "api-type": "http",
                "policy-payload": _UPDATE_POLICIES,
                "tags": ["updated"],
                "upstream": {"url": "https://api.example.com", "tls-certificate": "api-tls-cert"},
                "target-gateway": "us-envoy-1",
                "path": "/my-api",
            },
            "swagger": SAMPLE_SWAGGER_SPEC,
        },
    },
}


# ==================== Create API ====================

@router.post(
    "/api",
    response_model=ApiGatewayResponse,
    status_code=201,
    responses={409: {"model": ErrorResponse}, 422: {"model": ErrorResponse}},
    summary="Create an API",
    description="""
Create a new API that orchestrates route, backend, and policy creation.

This endpoint:
1. Creates a backend service from the `upstream` URL
2. Creates a single route (HTTPRoute for `http`, TLSRoute for `tls`)
   — if a `swagger` spec is provided, all spec paths are consolidated as
   additional rules within the same route (1 K8s resource, not N)
3. Attaches policies from the optional `policy-payload` (list of policy objects)

---

**Required fields:** `name`, `description`, `api-type`, `upstream`, `target-gateway`, `path`

**Optional fields:** `policy-payload`, `tags`, `swagger`, `upstream.tls-certificate`

---

### Path uniqueness

Each API path must be **unique** within a target gateway. If the path is already used by
another API, a `409 Conflict` is returned with the conflicting API name.

### policy-payload (optional)

List of policy objects. Each must have a `type` field. `name` is optional (auto-generated).
No `targetRoute` needed — derived from the API name.

**Policy naming:** All policy resource names are automatically prefixed with the API name.
For example, if the API is `petstore-api` and a policy name is `my-jwt`, the created
resource will be named `petstore-api-my-jwt`. If no name is given, it defaults to
`{api-name}-{policy-type-suffix}` (e.g., `petstore-api-jwt`).

**SecurityPolicy types:**

| type | Config Fields | Default Behavior |
|---|---|---|
| `JWT-validation` | issuer, jwksUri, audiences, claimToHeaders | Empty JWT provider |
| `cors` | allowedOrigins, allowedMethods, allowedHeaders, exposeHeaders, allowCredentials, maxAge | Allow *; origins must be full URLs (https://...) or bare domains are auto-prefixed with https:// |
| `api-key` | headerName, apiKeysSecret | Reads x-api-key header |
| `basic-auth` | usersSecret | References {api-name}-users secret |
| `ip-allow` | allowedCidrs | Deny all, empty CIDR list |
| `ip-block` | blockedCidrs | Allow all, empty CIDR list |
| `external-auth` | authServiceName, authServicePort, authPath, headersToAuth, failureMode | Points to {api-name}-auth-service:9001 |

**BackendTrafficPolicy types:**

| type | Config Fields | Default Behavior |
|---|---|---|
| `rate-limit` | requests, unit | 100 req/min |
| `circuit-breaker` | maxConnections, maxPendingRequests, maxParallelRequests | 1024/128/128 |
| `retry` | numRetries, perRetryTimeout, retryOn5xx, retryOnConnectFailure | 3 retries, 5s timeout |

All policies are **optional**. Omit or pass `[]` for no policies.
""",
)
def create_api(
    response: Response,
    payload: ApiGatewayCreateRequest = Body(
        ...,
        openapi_examples=_CREATE_EXAMPLES,
    ),
):
    """Create a new API with route, backend, and policies."""
    api_config = payload.api_gateway
    target_gateway = api_config.target_gateway

    try:
        rm = get_resource_manager(target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

    gateway_config = get_gateway_config(target_gateway)

    # Thorough existence check: look for both HTTPRoute and TLSRoute with this name
    existing = _fetch_existing_api(rm, api_config.name)
    if existing:
        detail = {
            "error": f"API '{api_config.name}' already exists",
            "existingApi": {
                "name": api_config.name,
                "routeType": existing["route_kind"],
                "apiType": existing["api_type"],
                "description": existing["description"],
                "path": existing["path"],
                "managed": existing["managed"],
                "policiesCount": len(existing["policies"]),
                "swaggerRoutesCount": len(existing["swagger_routes"]),
                "hasBackend": existing["backend"] is not None,
            },
        }
        raise HTTPException(status_code=409, detail=detail)

    # Path uniqueness check: ensure no other managed API uses the same path
    path = _normalize_path(api_config.path)
    conflicting_api = _check_path_uniqueness(rm, path)
    if conflicting_api:
        raise HTTPException(
            status_code=409,
            detail={
                "error": f"Path '{path}' is already in use",
                "conflictingApi": conflicting_api,
                "requestedPath": path,
                "message": f"Path '{path}' is already used by API '{conflicting_api}' on this gateway. Each API must have a unique path.",
            },
        )

    route_kind = "TLSRoute" if api_config.api_type.value == "tls" else "HTTPRoute"

    labels = _build_api_labels(api_config.name, api_config.tags)
    annotations = _build_api_annotations(
        api_config.description, api_config.api_type.value, api_config.tags
    )

    created_resources = []
    errors = []
    backend_name = f"{api_config.name}-backend"

    # Parse upstream
    hostname, backend_port, uses_tls = _parse_upstream_url(api_config.upstream.url)

    # Step 1: Create Backend CRD (Envoy Gateway Backend resource)
    try:
        if not rm.resource_exists("Backend", backend_name):
            app_protocol = "https" if uses_tls else "http"
            
            # Build Backend CRD spec with FQDN endpoint
            backend_spec = {
                "endpoints": [
                    {
                        "fqdn": {
                            "hostname": hostname,
                            "port": backend_port,
                        }
                    }
                ],
                "appProtocols": [app_protocol],
            }

            backend_labels = labels.copy()
            backend_annotations = {}
            if api_config.upstream.tls_certificate:
                backend_annotations["envoy-agent.io/tls-certificate"] = api_config.upstream.tls_certificate
            backend_annotations["envoy-agent.io/upstream-url"] = api_config.upstream.url

            rm.create_custom_resource(
                kind="Backend",
                name=backend_name,
                spec=backend_spec,
                labels=backend_labels,
                annotations=backend_annotations,
            )
            created_resources.append(ApiCreatedResource(
                resource_type="Backend",
                resource_name=backend_name,
                status="created",
            ))
            logger.info(f"Created Backend CRD: {backend_name}")
    except ApiException as e:
        logger.exception("Failed to create Backend CRD '%s'", backend_name)
        errors.append(f"Failed to create Backend CRD: {e.body}")
    except Exception as e:
        logger.exception("Failed to create Backend CRD '%s'", backend_name)
        errors.append(f"Failed to create Backend CRD: {str(e)}")

    # Step 2a: Pre-parse swagger spec (paths will be consolidated into the main route)
    # Paths are deduplicated and method-aware so that only spec-defined HTTP
    # methods are allowed through the gateway for each path.
    swagger_rules = []
    if payload.swagger:
        try:
            parser = OpenAPIParser(payload.swagger)
            spec_routes = parser.parse_routes()

            swagger_rules = _build_swagger_rules(spec_routes, path, backend_name, backend_port)

            annotations["envoy-agent.io/swagger-imported"] = "true"
            annotations["envoy-agent.io/swagger-paths-count"] = str(len(swagger_rules))
            logger.info(f"Parsed {len(swagger_rules)} unique swagger path rules for consolidation into main route")

        except Exception as e:
            logger.exception("Failed to parse swagger spec for API '%s'", api_config.name)
            errors.append(f"Failed to parse swagger spec: {str(e)}")

    # Step 2b: Create main route (with swagger paths as additional rules if provided)
    try:
        parent_ref = _build_parent_ref(gateway_config.gateway_name)
        backend_ref = _build_backend_ref(backend_name, backend_port)

        if api_config.api_type.value == "tls":
            spec = {
                "parentRefs": [parent_ref],
                "hostnames": [api_config.name],
                "rules": [{"backendRefs": [backend_ref]}],
            }
            rm.create_custom_resource(
                kind="TLSRoute",
                name=api_config.name,
                spec=spec,
                labels=labels,
                annotations=annotations,
            )
            created_resources.append(ApiCreatedResource(
                resource_type="TLSRoute",
                resource_name=api_config.name,
                status="created",
            ))
        else:
            match_rule = {"path": {"type": "PathPrefix", "value": path}}
            main_rule = {"matches": [match_rule], "backendRefs": [backend_ref]}
            all_rules = [main_rule] + swagger_rules
            
            # Create HTTPRoute(s) with automatic sharding if needed
            route_resources = _create_or_update_http_routes_with_sharding(
                rm=rm,
                api_name=api_config.name,
                all_rules=all_rules,
                parent_ref=parent_ref,
                labels=labels,
                annotations=annotations,
                is_update=False,
            )
            created_resources.extend(route_resources)

        logger.info(f"Created {route_kind}: {api_config.name}")

    except ApiException as e:
        logger.exception("Failed to create %s route '%s'", route_kind, api_config.name)
        errors.append(f"Failed to create route: {e.body}")
        try:
            rm.delete_custom_resource(kind="Backend", name=backend_name)
        except Exception:
            pass
        raise HTTPException(status_code=422, detail=f"Failed to create API route: {e.body}")
    except Exception as e:
        logger.exception("Failed to create %s route '%s'", route_kind, api_config.name)
        errors.append(f"Failed to create route: {str(e)}")
        try:
            rm.delete_custom_resource(kind="Backend", name=backend_name)
        except Exception:
            pass
        raise HTTPException(status_code=422, detail=f"Failed to create API route: {str(e)}")

    # Step 4: Attach policies from policy-payload
    policies_attached = 0
    policy_payload = api_config.policy_payload or []
    if policy_payload:
        try:
            parsed_policies = _parse_policy_payload(policy_payload)
        except ValueError as e:
            errors.append(str(e))
            parsed_policies = []

        for policy_type, policy_name, config in parsed_policies:
            try:
                resource = _create_policy_resource(
                    rm, policy_type, policy_name,
                    api_config.name, api_config.name, labels, config
                )
                created_resources.append(resource)
                policies_attached += 1
            except ValueError as e:
                logger.exception("Invalid policy config for '%s' on API '%s'", policy_name or policy_type, api_config.name)
                errors.append(str(e))
            except ApiException as e:
                logger.exception("Failed to create policy '%s' on API '%s'", policy_name or policy_type, api_config.name)
                errors.append(f"Failed to create policy '{policy_name or policy_type}': {e.body}")
            except Exception as e:
                logger.exception("Failed to create policy '%s' on API '%s'", policy_name or policy_type, api_config.name)
                errors.append(f"Failed to create policy '{policy_name or policy_type}': {str(e)}")

    # Set HTTP status code to 206 for partial success
    if errors:
        response.status_code = 206

    return ApiGatewayResponse(
        status="created" if not errors else "partial",
        message=f"API '{api_config.name}' created successfully"
                + (f" with {len(errors)} error(s)" if errors else ""),
        api_name=api_config.name,
        namespace=rm.namespace,
        target_gateway=target_gateway,
        resources_created=created_resources,
        errors=errors if errors else None,
        details={
            "apiType": api_config.api_type.value,
            "path": path,
            "backendName": backend_name,
            "upstreamUrl": api_config.upstream.url,
            "tlsCertificate": api_config.upstream.tls_certificate,
            "routeType": route_kind,
            "swaggerImported": payload.swagger is not None,
            "policiesAttached": policies_attached,
        },
    )


# ==================== List APIs ====================

@router.get(
    "/apis",
    response_model=ApiGatewayListResponse,
    summary="List APIs",
    description="""List all APIs managed by the API management system for a target gateway.

Each API is returned in the **same payload format** accepted by the Create / Update
endpoints, so you can copy any item from the response and paste it directly into a
`PUT /api/{name}` request body to update it.
""",
)
def list_apis(
    target_gateway: str = Query(
        ..., alias="targetGateway", description="Target gateway identifier"
    ),
):
    """List all managed APIs in the create/update payload format."""
    try:
        rm = get_resource_manager(target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

    # List HTTPRoutes (should always exist)
    try:
        http_routes = rm.list_custom_resources(
            "HTTPRoute",
            label_selector=f"{MANAGED_BY_LABEL}={MANAGED_BY_VALUE}",
        )
    except ApiException as e:
        if e.status == 404:
            http_routes = []
        else:
            raise

    # List TLSRoutes — CRD may not be installed, handle gracefully
    try:
        tls_routes = rm.list_custom_resources(
            "TLSRoute",
            label_selector=f"{MANAGED_BY_LABEL}={MANAGED_BY_VALUE}",
        )
    except ApiException as e:
        if e.status == 404:
            logger.warning("TLSRoute CRD not found on cluster — skipping TLS routes")
            tls_routes = []
        else:
            raise

    apis = []
    seen_api_names = set()

    for route in http_routes + tls_routes:
        route_labels = route.get("metadata", {}).get("labels", {})

        api_name = route_labels.get(API_NAME_LABEL, route["metadata"]["name"])
        if api_name in seen_api_names:
            continue
        seen_api_names.add(api_name)

        # Fetch full API state and reconstruct the user-facing payload
        existing = _fetch_existing_api(rm, api_name)
        if not existing:
            continue

        payload = _reconstruct_api_gateway_payload(rm, api_name, existing, target_gateway)

        # Add metadata fields that are useful but not part of the create payload
        payload["_metadata"] = {
            "routeType": existing["route_kind"],
            "namespace": route.get("metadata", {}).get("namespace", rm.namespace),
            "createdAt": route.get("metadata", {}).get("creationTimestamp"),
            "policiesCount": len(existing.get("policies", [])),
            "swaggerRoutesCount": len(existing.get("swagger_routes", [])),
        }

        apis.append(payload)

    return ApiGatewayListResponse(
        items=apis,
        total=len(apis),
        target_gateway=target_gateway,
        namespace=rm.namespace,
    )


# ==================== List API Summary (Name + Path table) ====================

@router.get(
    "/apis/summary",
    response_model=ApiSummaryListResponse,
    summary="List API names and paths",
    description="""Return a lightweight tabular list of all managed APIs showing just name, path,
type, and description for a target gateway.

This is faster than `GET /apis` because it does **not** fetch full API state
(policies, backend, swagger rules) — it reads only route metadata.
""",
)
def list_api_summary(
    target_gateway: str = Query(
        ..., alias="targetGateway", description="Target gateway identifier"
    ),
):
    """Return a compact name + path table of all managed APIs."""
    try:
        rm = get_resource_manager(target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

    # List HTTPRoutes
    try:
        http_routes = rm.list_custom_resources(
            "HTTPRoute",
            label_selector=f"{MANAGED_BY_LABEL}={MANAGED_BY_VALUE}",
        )
    except ApiException as e:
        if e.status == 404:
            http_routes = []
        else:
            raise

    # List TLSRoutes
    try:
        tls_routes = rm.list_custom_resources(
            "TLSRoute",
            label_selector=f"{MANAGED_BY_LABEL}={MANAGED_BY_VALUE}",
        )
    except ApiException as e:
        if e.status == 404:
            tls_routes = []
        else:
            raise

    items = []
    seen = set()

    for route in http_routes + tls_routes:
        meta = route.get("metadata", {})
        labels = meta.get("labels", {})
        annotations = meta.get("annotations", {})

        api_name = labels.get(API_NAME_LABEL, meta.get("name", ""))
        if api_name in seen:
            continue
        seen.add(api_name)

        # Extract path from first rule
        route_path = ""
        rules = route.get("spec", {}).get("rules", [])
        if rules:
            matches = rules[0].get("matches", [])
            if matches:
                route_path = matches[0].get("path", {}).get("value", "")

        items.append(ApiSummaryItem(
            name=api_name,
            path=route_path,
            api_type=annotations.get(API_TYPE_ANNOTATION, "http"),
            description=annotations.get(API_DESCRIPTION_ANNOTATION, ""),
        ))

    return ApiSummaryListResponse(
        items=items,
        total=len(items),
        target_gateway=target_gateway,
        namespace=rm.namespace,
    )


# ==================== List APIs by Path ====================

@router.get(
    "/apis/{path_name}",
    response_model=ApiGatewayListResponse,
    summary="List APIs by path",
    description="""List APIs whose path matches the given `pathName`.

The `pathName` should be provided **without** the leading `/`.
For example, to find APIs with path `/petstore`, use `GET /apis/petstore`.

Supports nested paths using URL encoding or multiple path segments:
- `/apis/api%2Fv1%2Fusers` for path `/api/v1/users`
""",
)
def list_apis_by_path(
    path_name: str,
    target_gateway: str = Query(
        ..., alias="targetGateway", description="Target gateway identifier"
    ),
):
    """List APIs matching a specific path."""
    try:
        rm = get_resource_manager(target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

    search_path = _normalize_path(path_name)

    # List HTTPRoutes
    try:
        http_routes = rm.list_custom_resources(
            "HTTPRoute",
            label_selector=f"{MANAGED_BY_LABEL}={MANAGED_BY_VALUE}",
        )
    except ApiException as e:
        if e.status == 404:
            http_routes = []
        else:
            raise

    # List TLSRoutes
    try:
        tls_routes = rm.list_custom_resources(
            "TLSRoute",
            label_selector=f"{MANAGED_BY_LABEL}={MANAGED_BY_VALUE}",
        )
    except ApiException as e:
        if e.status == 404:
            tls_routes = []
        else:
            raise

    apis = []
    seen_api_names = set()

    for route in http_routes + tls_routes:
        route_labels = route.get("metadata", {}).get("labels", {})
        api_name = route_labels.get(API_NAME_LABEL, route["metadata"]["name"])
        if api_name in seen_api_names:
            continue
        seen_api_names.add(api_name)

        # Extract path from route spec
        route_path = None
        rules = route.get("spec", {}).get("rules", [])
        if rules:
            matches = rules[0].get("matches", [])
            if matches:
                route_path = matches[0].get("path", {}).get("value")

        if not route_path:
            continue

        # Match: exact or prefix
        normalized_route_path = _normalize_path(route_path)
        if normalized_route_path != search_path:
            continue

        existing = _fetch_existing_api(rm, api_name)
        if not existing:
            continue

        payload = _reconstruct_api_gateway_payload(rm, api_name, existing, target_gateway)
        payload["_metadata"] = {
            "routeType": existing["route_kind"],
            "namespace": route.get("metadata", {}).get("namespace", rm.namespace),
            "createdAt": route.get("metadata", {}).get("creationTimestamp"),
            "policiesCount": len(existing.get("policies", [])),
            "swaggerRoutesCount": len(existing.get("swagger_routes", [])),
        }
        apis.append(payload)

    return ApiGatewayListResponse(
        items=apis,
        total=len(apis),
        target_gateway=target_gateway,
        namespace=rm.namespace,
    )


# ==================== Get API ====================

@router.get(
    "/api/{name}",
    response_model=ApiGatewayDetailResponse,
    responses={404: {"model": ErrorResponse}},
    summary="Get an API",
    description="Get detailed information about a specific API including its routes, backend, and policies.",
)
def get_api(
    name: str,
    target_gateway: str = Query(
        ..., alias="targetGateway", description="Target gateway identifier"
    ),
):
    """Get API details by name."""
    try:
        rm = get_resource_manager(target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

    existing = _fetch_existing_api(rm, name)
    if not existing:
        raise HTTPException(status_code=404, detail=f"API '{name}' not found")

    if not existing["managed"]:
        raise HTTPException(
            status_code=404,
            detail=f"API '{name}' not found (route exists but is not managed by API management)"
        )

    # Reconstruct user-facing payload for copy-paste into update
    payload = _reconstruct_api_gateway_payload(rm, name, existing, target_gateway)

    return ApiGatewayDetailResponse(
        api_name=name,
        description=existing["description"],
        api_type=existing["api_type"],
        tags=existing["tags"],
        target_gateway=target_gateway,
        namespace=rm.namespace,
        route=existing["route"],
        swagger_routes=existing["swagger_routes"] if existing["swagger_routes"] else None,
        policies=existing["policies"] if existing["policies"] else None,
        backend=existing["backend"],
        update_payload=payload,
    )


# ==================== Update API ====================

@router.put(
    "/api/{name}",
    response_model=ApiGatewayResponse,
    responses={404: {"model": ErrorResponse}, 422: {"model": ErrorResponse}},
    summary="Update an API",
    description="""
Update an existing API using a diff-based approach. This will:

1. **Fetch** the full existing API state (route, backend, policies)
2. **Compare** every field against the incoming payload
3. **Apply** only the changes that differ (no unnecessary deletes/recreates)
4. **Return** a list of `updatedFields` showing old vs new values

### What gets compared:
| Field | Behavior if changed |
|---|---|
| `description` | Route annotations updated |
| `path` | Route spec updated |
| `tags` | Route labels/annotations updated |
| `api-type` | Old route deleted, new route kind created |
| `upstream.url` | Backend service updated |
| `upstream.tls-certificate` | Backend annotations updated |
| `policy-payload` | Diff: remove stale policies, add new ones, keep unchanged |
| `swagger` | Swagger paths consolidated as additional rules within the main route (single K8s resource) |

If **nothing** has changed, the response status will be `unchanged`.

All 10 policy types supported (all optional):
JWT-validation, cors, api-key, basic-auth, ip-allow, ip-block, external-auth, rate-limit, circuit-breaker, retry.
""",
)
def update_api(
    name: str,
    response: Response,
    payload: ApiGatewayUpdateRequest = Body(
        ...,
        openapi_examples=_UPDATE_EXAMPLES,
    ),
):
    """Update an existing API by comparing with existing state and updating only changed fields."""
    api_config = payload.api_gateway
    target_gateway = api_config.target_gateway

    try:
        rm = get_resource_manager(target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

    gateway_config = get_gateway_config(target_gateway)

    # ---- Step 1: Fetch existing API state ----
    existing = _fetch_existing_api(rm, name)
    if not existing:
        raise HTTPException(status_code=404, detail=f"API '{name}' not found")

    if not existing["managed"]:
        raise HTTPException(
            status_code=404,
            detail=f"API '{name}' not found (route exists but is not managed by API management)",
        )

    labels = _build_api_labels(api_config.name, api_config.tags)
    annotations = _build_api_annotations(
        api_config.description, api_config.api_type.value, api_config.tags
    )

    updated_resources = []
    errors = []
    updated_fields = []
    backend_name = f"{name}-backend"
    new_path = _normalize_path(api_config.path)
    hostname, backend_port, uses_tls = _parse_upstream_url(api_config.upstream.url)
    new_route_kind = "TLSRoute" if api_config.api_type.value == "tls" else "HTTPRoute"
    old_route_kind = existing["route_kind"]

    # Path uniqueness check if path is changing
    if existing["path"] != new_path:
        conflicting_api = _check_path_uniqueness(rm, new_path, exclude_api_name=name)
        if conflicting_api:
            raise HTTPException(
                status_code=409,
                detail={
                    "error": f"Path '{new_path}' is already in use",
                    "conflictingApi": conflicting_api,
                    "requestedPath": new_path,
                    "currentPath": existing["path"],
                    "message": f"Cannot update path to '{new_path}' — already used by API '{conflicting_api}' on this gateway.",
                },
            )

    # ---- Step 2: Compare fields to detect changes ----

    # 2a. Description
    description_changed = existing["description"] != api_config.description
    if description_changed:
        updated_fields.append({
            "field": "description",
            "old": existing["description"],
            "new": api_config.description,
        })

    # 2b. Path
    path_changed = existing["path"] != new_path
    if path_changed:
        updated_fields.append({
            "field": "path",
            "old": existing["path"],
            "new": new_path,
        })

    # 2c. Tags
    old_tags = existing["tags"]
    new_tags = api_config.tags or []
    tags_changed = sorted(old_tags) != sorted(new_tags)
    if tags_changed:
        updated_fields.append({
            "field": "tags",
            "old": old_tags,
            "new": new_tags,
        })

    # 2d. API type (route kind change)
    api_type_changed = existing["api_type"] != api_config.api_type.value
    if api_type_changed:
        updated_fields.append({
            "field": "api-type",
            "old": existing["api_type"],
            "new": api_config.api_type.value,
        })

    # 2e. Upstream URL
    old_upstream_url = None
    old_tls_cert = None
    if existing["backend"]:
        backend_meta = existing["backend"].get("metadata") or {}
        backend_annots = backend_meta.get("annotations") or {}
        old_upstream_url = backend_annots.get("envoy-agent.io/upstream-url")
        old_tls_cert = backend_annots.get("envoy-agent.io/tls-certificate")

    upstream_url_changed = old_upstream_url != api_config.upstream.url
    if upstream_url_changed:
        updated_fields.append({
            "field": "upstream.url",
            "old": old_upstream_url,
            "new": api_config.upstream.url,
        })

    # 2f. TLS certificate
    tls_cert_changed = old_tls_cert != api_config.upstream.tls_certificate
    if tls_cert_changed:
        updated_fields.append({
            "field": "upstream.tls-certificate",
            "old": old_tls_cert,
            "new": api_config.upstream.tls_certificate,
        })

    # 2g. Policies — compute diff (add / remove / unchanged)
    policy_payload = api_config.policy_payload or []
    new_parsed_policies = []
    if policy_payload:
        try:
            new_parsed_policies = _parse_policy_payload(policy_payload)
        except ValueError as e:
            errors.append(str(e))

    # Build set of new policy (kind, resolved_name)
    new_policy_map = {}
    for ptype, pname, config in new_parsed_policies:
        normalized = ptype.lower().replace("_", "-")
        type_info = SUPPORTED_POLICY_TYPES.get(normalized)
        if type_info:
            resolved = _resolve_policy_name(pname, name, type_info["default_suffix"])
            new_policy_map[(type_info["kind"], resolved)] = (ptype, pname, config)

    # Build set of existing policy (kind, name)
    old_policy_set = set()
    for p in existing["policies"]:
        p_name = p.get("metadata", {}).get("name")
        p_kind = p.get("kind", "SecurityPolicy")
        old_policy_set.add((p_kind, p_name))

    new_policy_set = set(new_policy_map.keys())
    policies_to_remove = old_policy_set - new_policy_set
    policies_to_add = new_policy_set - old_policy_set
    policies_unchanged = old_policy_set & new_policy_set
    policies_changed = bool(policies_to_remove or policies_to_add)

    if policies_changed:
        updated_fields.append({
            "field": "policies",
            "removed": [{"kind": k, "name": n} for k, n in sorted(policies_to_remove)],
            "added": [{"kind": k, "name": n} for k, n in sorted(policies_to_add)],
            "unchanged": [{"kind": k, "name": n} for k, n in sorted(policies_unchanged)],
        })

    # 2h. Swagger — parse if provided, otherwise preserve existing swagger rules
    # Paths are deduplicated and method-aware (see _build_swagger_rules).
    swagger_rules = []
    swagger_changed = False
    if payload.swagger:
        try:
            parser = OpenAPIParser(payload.swagger)
            spec_routes = parser.parse_routes()

            swagger_rules = _build_swagger_rules(spec_routes, new_path, backend_name, backend_port)

            swagger_changed = True
            updated_fields.append({"field": "swagger", "action": "refreshed"})
        except Exception as e:
            logger.exception("Failed to parse swagger spec during update of API '%s'", name)
            errors.append(f"Failed to parse swagger spec: {str(e)}")
            # Fallback: preserve existing swagger rules
            swagger_rules = existing.get("swagger_routes", [])
    else:
        # Preserve existing swagger rules from the main route
        swagger_rules = existing.get("swagger_routes", [])

    route_needs_update = description_changed or path_changed or tags_changed or api_type_changed or swagger_changed
    backend_needs_update = upstream_url_changed or tls_cert_changed

    # ---- Step 3: Apply changes ----

    # 3a. Update Backend CRD if upstream changed
    if backend_needs_update:
        try:
            app_protocol = "https" if uses_tls else "http"
            
            # Build Backend CRD spec with FQDN endpoint
            new_backend_spec = {
                "endpoints": [
                    {
                        "fqdn": {
                            "hostname": hostname,
                            "port": backend_port,
                        }
                    }
                ],
                "appProtocols": [app_protocol],
            }
            backend_annotations_new = {"envoy-agent.io/upstream-url": api_config.upstream.url}
            if api_config.upstream.tls_certificate:
                backend_annotations_new["envoy-agent.io/tls-certificate"] = api_config.upstream.tls_certificate

            if existing["backend"]:
                rm.update_custom_resource(kind="Backend", name=backend_name, spec=new_backend_spec, annotations=backend_annotations_new)
            else:
                rm.create_custom_resource(kind="Backend", name=backend_name, spec=new_backend_spec, labels=labels, annotations=backend_annotations_new)

            updated_resources.append(ApiCreatedResource(
                resource_type="Backend",
                resource_name=backend_name,
                status="updated" if existing["backend"] else "created",
            ))
            logger.info(f"{'Updated' if existing['backend'] else 'Created'} Backend CRD: {backend_name}")
        except ApiException as e:
            logger.exception("Failed to update Backend CRD '%s'", backend_name)
            errors.append(f"Failed to update Backend CRD: {e.body}")
        except Exception as e:
            logger.exception("Failed to update Backend CRD '%s'", backend_name)
            errors.append(f"Failed to update Backend CRD: {str(e)}")

    # 3b. Update (or recreate) main route (swagger rules consolidated within)
    if route_needs_update:
        try:
            parent_ref = _build_parent_ref(gateway_config.gateway_name)
            backend_ref = _build_backend_ref(backend_name, backend_port)

            # Build annotations for swagger tracking
            update_annotations = annotations.copy() if annotations else {}
            if swagger_rules:
                update_annotations["envoy-agent.io/swagger-imported"] = "true"
                update_annotations["envoy-agent.io/swagger-paths-count"] = str(len(swagger_rules))

            if api_type_changed and old_route_kind != new_route_kind:
                # Delete old route type and any shards
                rm.delete_custom_resource(old_route_kind, name)
                _cleanup_old_shards(rm, name, 0)
                logger.info(f"Deleted old {old_route_kind}: {name} (api-type changed)")

                if new_route_kind == "TLSRoute":
                    new_spec = {
                        "parentRefs": [parent_ref],
                        "hostnames": [api_config.name],
                        "rules": [{"backendRefs": [backend_ref]}],
                    }
                    rm.create_custom_resource(
                        kind=new_route_kind, name=name, spec=new_spec,
                        labels=labels, annotations=update_annotations,
                    )
                    updated_resources.append(ApiCreatedResource(
                        resource_type=new_route_kind,
                        resource_name=name,
                        status="recreated",
                    ))
                else:
                    match_rule = {"path": {"type": "PathPrefix", "value": new_path}}
                    main_rule = {"matches": [match_rule], "backendRefs": [backend_ref]}
                    all_rules = [main_rule] + swagger_rules
                    
                    # Create HTTPRoute(s) with automatic sharding if needed
                    route_resources = _create_or_update_http_routes_with_sharding(
                        rm=rm,
                        api_name=name,
                        all_rules=all_rules,
                        parent_ref=parent_ref,
                        labels=labels,
                        annotations=update_annotations,
                        is_update=False,  # New route after type change
                    )
                    updated_resources.extend(route_resources)
            else:
                if new_route_kind == "TLSRoute":
                    new_spec = {
                        "parentRefs": [parent_ref],
                        "hostnames": [api_config.name],
                        "rules": [{"backendRefs": [backend_ref]}],
                    }
                    rm.update_custom_resource(
                        new_route_kind, name, new_spec,
                        annotations=update_annotations if update_annotations else None,
                    )
                    updated_resources.append(ApiCreatedResource(
                        resource_type=new_route_kind,
                        resource_name=name,
                        status="updated",
                    ))
                else:
                    match_rule = {"path": {"type": "PathPrefix", "value": new_path}}
                    main_rule = {"matches": [match_rule], "backendRefs": [backend_ref]}
                    all_rules = [main_rule] + swagger_rules
                    
                    # Update HTTPRoute(s) with automatic sharding if needed
                    route_resources = _create_or_update_http_routes_with_sharding(
                        rm=rm,
                        api_name=name,
                        all_rules=all_rules,
                        parent_ref=parent_ref,
                        labels=labels,
                        annotations=update_annotations,
                        is_update=True,
                    )
                    updated_resources.extend(route_resources)

            logger.info(f"Updated {new_route_kind}: {name}")
        except ApiException as e:
            logger.exception("Failed to update %s route '%s'", new_route_kind, name)
            errors.append(f"Failed to update route: {e.body}")
        except Exception as e:
            logger.exception("Failed to update %s route '%s'", new_route_kind, name)
            errors.append(f"Failed to update route: {str(e)}")

    # 3c. Policy diff — remove stale, add new, keep unchanged
    policies_attached = 0

    for policy_kind, policy_name in policies_to_remove:
        try:
            rm.delete_custom_resource(policy_kind, policy_name)
            updated_resources.append(ApiCreatedResource(
                resource_type=policy_kind,
                resource_name=policy_name,
                status="deleted",
            ))
            logger.info(f"Removed stale policy {policy_kind}/{policy_name}")
        except Exception as e:
            logger.exception("Failed to remove policy '%s' (%s) from API '%s'", policy_name, policy_kind, name)
            errors.append(f"Failed to remove policy '{policy_name}': {str(e)}")

    for key in policies_to_add:
        ptype, pname, config = new_policy_map[key]
        try:
            resource = _create_policy_resource(
                rm, ptype, pname, name, name, labels, config
            )
            updated_resources.append(resource)
            policies_attached += 1
        except ValueError as e:
            logger.exception("Invalid policy config for '%s' during update of API '%s'", pname or ptype, name)
            errors.append(str(e))
        except ApiException as e:
            logger.exception("Failed to create policy '%s' during update of API '%s'", pname or ptype, name)
            errors.append(f"Failed to create policy '{pname or ptype}': {e.body}")
        except Exception as e:
            logger.exception("Failed to create policy '%s' during update of API '%s'", pname or ptype, name)
            errors.append(f"Failed to create policy '{pname or ptype}': {str(e)}")

    policies_kept = len(policies_unchanged)

    # ---- Step 4: Build response ----
    has_changes = bool(updated_fields)
    if not has_changes:
        status_msg = "unchanged"
        message = f"API '{name}' is already up to date — no changes detected"
    elif errors:
        status_msg = "partial"
        message = f"API '{name}' partially updated with {len(errors)} error(s)"
        # Set HTTP status code to 206 for partial success
        response.status_code = 206
    else:
        status_msg = "updated"
        message = f"API '{name}' updated successfully"

    return ApiGatewayResponse(
        status=status_msg,
        message=message,
        api_name=name,
        namespace=rm.namespace,
        target_gateway=target_gateway,
        resources_created=updated_resources if updated_resources else None,
        errors=errors if errors else None,
        details={
            "apiType": api_config.api_type.value,
            "path": new_path,
            "backendName": backend_name,
            "upstreamUrl": api_config.upstream.url,
            "routeType": new_route_kind,
            "updatedFields": updated_fields,
            "policiesAdded": len(policies_to_add),
            "policiesRemoved": len(policies_to_remove),
            "policiesUnchanged": policies_kept,
        },
    )


# ==================== Delete API ====================

@router.delete(
    "/api/{name}",
    response_model=ApiGatewayResponse,
    responses={404: {"model": ErrorResponse}},
    summary="Delete an API",
    description="""
Delete an API and all its associated resources.

**Deletion order:**
1. Attached policies (SecurityPolicy + BackendTrafficPolicy)
2. Backend service
3. Main route (HTTPRoute or TLSRoute) — **deleted last**

Swagger paths are consolidated within the main route (not separate resources),
so deleting the main route automatically removes all swagger-imported paths.

**Safety:** If any sub-resource deletion fails, the operation **stops immediately**.
The main API route is preserved so you can investigate and retry.
The response shows which resources were successfully deleted and which failed.
""",
)
def delete_api(
    name: str,
    target_gateway: str = Query(
        ..., alias="targetGateway", description="Target gateway identifier"
    ),
    delete_backend: bool = Query(
        True, alias="deleteBackend", description="Also delete the backend service"
    ),
    delete_policies: bool = Query(
        True, alias="deletePolicies", description="Also delete attached policies"
    ),
):
    """Delete an API and all associated resources (fails safe — main route kept if sub-resource deletion fails)."""
    try:
        rm = get_resource_manager(target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

    # ---- Step 1: Fetch full API state ----
    existing = _fetch_existing_api(rm, name)
    if not existing:
        raise HTTPException(status_code=404, detail=f"API '{name}' not found")

    route_kind = existing["route_kind"]
    backend_name = existing["backend_name"]

    # Build summary of what will be deleted
    # Note: swagger paths are consolidated into the main route (no separate resources)
    resources_to_delete = []
    if delete_policies:
        for p in existing.get("policies", []):
            p_kind = p.get("kind", "SecurityPolicy")
            p_name = p.get("metadata", {}).get("name", "")
            resources_to_delete.append((p_kind, p_name, "policy"))
    if delete_backend and existing.get("backend"):
        resources_to_delete.append(("Backend", backend_name, "backend"))
    # Main route is always last (includes any swagger rules within it)
    resources_to_delete.append((route_kind, name, "main-route"))

    deleted_resources = []
    errors = []

    # ---- Step 2: Delete sub-resources one by one, stop on first failure ----

    # 2a. Policies
    if delete_policies:
        for p in existing.get("policies", []):
            p_kind = p.get("kind", "SecurityPolicy")
            p_name = p.get("metadata", {}).get("name", "")
            try:
                rm.delete_custom_resource(p_kind, p_name)
                deleted_resources.append(ApiCreatedResource(
                    resource_type=p_kind,
                    resource_name=p_name,
                    status="deleted",
                ))
                logger.info(f"Deleted {p_kind}: {p_name}")
            except Exception as e:
                logger.exception("Failed to delete policy '%s' (%s) from API '%s'", p_name, p_kind, name)
                errors.append(f"Failed to delete policy '{p_name}' ({p_kind}): {str(e)}")
                return _delete_failed_response(
                    name, rm, target_gateway, deleted_resources, errors,
                    resources_to_delete,
                )

    # 2b. Backend CRD
    if delete_backend and existing.get("backend"):
        try:
            rm.delete_custom_resource(kind="Backend", name=backend_name)
            deleted_resources.append(ApiCreatedResource(
                resource_type="Backend",
                resource_name=backend_name,
                status="deleted",
            ))
            logger.info(f"Deleted Backend CRD: {backend_name}")
        except Exception as e:
            logger.exception("Failed to delete Backend CRD '%s' for API '%s'", backend_name, name)
            errors.append(f"Failed to delete Backend CRD '{backend_name}': {str(e)}")
            return _delete_failed_response(
                name, rm, target_gateway, deleted_resources, errors,
                resources_to_delete,
            )

    # ---- Step 3: All sub-resources deleted — now delete the main route and any shards ----
    try:
        rm.delete_custom_resource(route_kind, name)
        deleted_resources.append(ApiCreatedResource(
            resource_type=route_kind,
            resource_name=name,
            status="deleted",
        ))
        logger.info(f"Deleted {route_kind}: {name}")
        
        # Delete any sharded routes (HTTPRoute only)
        if route_kind == "HTTPRoute":
            _cleanup_old_shards(rm, name, 0)
            
    except Exception as e:
        logger.exception("Failed to delete main route '%s' (%s)", name, route_kind)
        errors.append(f"Failed to delete main route '{name}' ({route_kind}): {str(e)}")
        return _delete_failed_response(
            name, rm, target_gateway, deleted_resources, errors,
            resources_to_delete,
        )

    return ApiGatewayResponse(
        status="deleted",
        message=f"API '{name}' and all {len(deleted_resources)} resources deleted successfully",
        api_name=name,
        namespace=rm.namespace,
        target_gateway=target_gateway,
        resources_created=deleted_resources,
        details={
            "totalDeleted": len(deleted_resources),
            "resourcesDeleted": [
                {"type": r.resource_type, "name": r.resource_name}
                for r in deleted_resources
            ],
        },
    )


def _delete_failed_response(
    api_name: str,
    rm: ResourceManager,
    target_gateway: str,
    deleted_so_far: List[ApiCreatedResource],
    errors: List[str],
    all_planned: List[tuple],
) -> ApiGatewayResponse:
    """
    Build a response when a delete operation fails partway through.
    The main API route is NOT deleted — the user can investigate and retry.
    """
    deleted_names = {r.resource_name for r in deleted_so_far}
    skipped = [
        {"type": kind, "name": rname, "category": cat}
        for kind, rname, cat in all_planned
        if rname not in deleted_names
    ]

    return ApiGatewayResponse(
        status="failed",
        message=(
            f"API '{api_name}' deletion stopped — {len(errors)} error(s). "
            f"{len(deleted_so_far)} resource(s) deleted, {len(skipped)} skipped. "
            f"Main API route preserved."
        ),
        api_name=api_name,
        namespace=rm.namespace,
        target_gateway=target_gateway,
        resources_created=deleted_so_far if deleted_so_far else None,
        errors=errors,
        details={
            "totalDeleted": len(deleted_so_far),
            "totalSkipped": len(skipped),
            "skippedResources": skipped,
        },
    )
