"""
API routes for Envoy Gateway policies.
Uses targetGateway to determine cluster/namespace.
"""

from fastapi import APIRouter, HTTPException, Query
from typing import Optional
from kubernetes.client.rest import ApiException

from ..models.policies.backend_traffic import (
    BackendTrafficPolicyCreate, BackendTrafficPolicyUpdate, BackendTrafficPolicyResponse,
    SimpleRateLimitPolicy, SimpleCircuitBreakerPolicy, SimpleRetryPolicy,
)
from ..models.policies.security import (
    SecurityPolicyCreate, SecurityPolicyUpdate, SecurityPolicyResponse,
    SimpleJWTPolicy, SimpleOIDCPolicy, SimpleCORSPolicy, SimpleAPIKeyPolicy, 
    SimpleBasicAuthPolicy, SimpleIPAllowlistPolicy, SimpleIPBlocklistPolicy,
    SimpleExternalAuthPolicy,
)
from ..models.policies.client_traffic import (
    ClientTrafficPolicyCreate, ClientTrafficPolicyUpdate, ClientTrafficPolicyResponse,
    SimpleTLSPolicy, SimpleTimeoutPolicy, SimpleHTTP2Policy,
)
from ..models.policies.extension import (
    EnvoyPatchPolicyCreate, EnvoyPatchPolicyUpdate, EnvoyPatchPolicyResponse,
    EnvoyExtensionPolicyCreate, EnvoyExtensionPolicyUpdate, EnvoyExtensionPolicyResponse,
    SimpleWasmExtension, SimpleExtProcExtension,
)
from ..models.policies.logging import (
    EnvoyProxyCreate, EnvoyProxyResponse,
    SimpleAccessLogConfig, SimpleOTLPLoggingConfig,
)
from ..models.common import ResourceResponse, ResourceListResponse, ErrorResponse
from ..services.resource_manager import ResourceManager
from ..utils.helpers import build_target_ref

router = APIRouter(prefix="/policies", tags=["Policies"])


def get_resource_manager(target_gateway: str) -> ResourceManager:
    """Get resource manager for the specified target gateway."""
    return ResourceManager(target_gateway=target_gateway)


# ==================== BackendTrafficPolicy ====================

@router.post(
    "/backend-traffic",
    response_model=ResourceResponse,
    status_code=201,
    summary="Create a BackendTrafficPolicy",
    description="Create a BackendTrafficPolicy for rate limiting, circuit breaker, retries, etc.",
)
def create_backend_traffic_policy(
    payload: BackendTrafficPolicyCreate,
    target_gateway: str = Query(..., alias="targetGateway", description="Target gateway identifier"),
):
    try:
        rm = get_resource_manager(target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    
    if rm.resource_exists("BackendTrafficPolicy", payload.metadata.name):
        raise HTTPException(status_code=409, detail=f"BackendTrafficPolicy '{payload.metadata.name}' already exists")
    
    try:
        spec = payload.spec.model_dump(by_alias=True, exclude_none=True)
        rm.create_custom_resource(
            kind="BackendTrafficPolicy",
            name=payload.metadata.name,
            spec=spec,
            labels=payload.metadata.labels,
        )
        return ResourceResponse(
            status="created",
            message=f"BackendTrafficPolicy '{payload.metadata.name}' created",
            resource_name=payload.metadata.name,
            namespace=rm.namespace,
            resource_type="BackendTrafficPolicy",
            details={"targetGateway": target_gateway},
        )
    except ApiException as e:
        raise HTTPException(status_code=422, detail=f"Failed to create policy: {e.body}")


@router.get("/backend-traffic", response_model=ResourceListResponse, summary="List BackendTrafficPolicies")
def list_backend_traffic_policies(
    target_gateway: str = Query(..., alias="targetGateway", description="Target gateway identifier"),
):
    try:
        rm = get_resource_manager(target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    
    items = rm.list_custom_resources("BackendTrafficPolicy")
    return ResourceListResponse(items=items, total=len(items), namespace=rm.namespace)


@router.get("/backend-traffic/{name}", response_model=BackendTrafficPolicyResponse, summary="Get a BackendTrafficPolicy")
def get_backend_traffic_policy(
    name: str,
    target_gateway: str = Query(..., alias="targetGateway", description="Target gateway identifier"),
):
    try:
        rm = get_resource_manager(target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    
    policy = rm.get_custom_resource("BackendTrafficPolicy", name)
    if not policy:
        raise HTTPException(status_code=404, detail=f"BackendTrafficPolicy '{name}' not found")
    return BackendTrafficPolicyResponse(**policy)


@router.put("/backend-traffic/{name}", response_model=ResourceResponse, summary="Update a BackendTrafficPolicy")
def update_backend_traffic_policy(
    name: str,
    payload: BackendTrafficPolicyUpdate,
    target_gateway: str = Query(..., alias="targetGateway", description="Target gateway identifier"),
):
    try:
        rm = get_resource_manager(target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    
    if not rm.resource_exists("BackendTrafficPolicy", name):
        raise HTTPException(status_code=404, detail=f"BackendTrafficPolicy '{name}' not found")
    
    try:
        spec = payload.spec.model_dump(by_alias=True, exclude_none=True)
        rm.update_custom_resource("BackendTrafficPolicy", name, spec)
        return ResourceResponse(status="updated", message=f"BackendTrafficPolicy '{name}' updated", resource_name=name, namespace=rm.namespace, resource_type="BackendTrafficPolicy")
    except ApiException as e:
        raise HTTPException(status_code=422, detail=f"Failed to update policy: {e.body}")


@router.delete("/backend-traffic/{name}", response_model=ResourceResponse, summary="Delete a BackendTrafficPolicy")
def delete_backend_traffic_policy(
    name: str,
    target_gateway: str = Query(..., alias="targetGateway", description="Target gateway identifier"),
):
    try:
        rm = get_resource_manager(target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    
    if not rm.delete_custom_resource("BackendTrafficPolicy", name):
        raise HTTPException(status_code=404, detail=f"BackendTrafficPolicy '{name}' not found")
    return ResourceResponse(status="deleted", message=f"BackendTrafficPolicy '{name}' deleted", resource_name=name, namespace=rm.namespace, resource_type="BackendTrafficPolicy")


# ==================== Simple BackendTrafficPolicy Creation ====================

@router.post("/backend-traffic/rate-limit", response_model=ResourceResponse, status_code=201, summary="Create a rate limit policy")
def create_simple_rate_limit(
    payload: SimpleRateLimitPolicy,
    target_gateway: str = Query(..., alias="targetGateway", description="Target gateway identifier"),
):
    try:
        rm = get_resource_manager(target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    
    if rm.resource_exists("BackendTrafficPolicy", payload.name):
        raise HTTPException(status_code=409, detail=f"Policy '{payload.name}' already exists")
    
    spec = {
        "targetRef": build_target_ref("HTTPRoute", payload.target_route),
        "rateLimit": {
            "type": "Global",
            "global": {
                "rules": [{"limit": {"requests": payload.requests, "unit": payload.unit.value}}]
            }
        }
    }
    
    try:
        rm.create_custom_resource("BackendTrafficPolicy", payload.name, spec)
        return ResourceResponse(status="created", message=f"Rate limit policy '{payload.name}' created", resource_name=payload.name, namespace=rm.namespace, resource_type="BackendTrafficPolicy", details={"requests": payload.requests, "unit": payload.unit.value, "targetGateway": target_gateway})
    except ApiException as e:
        raise HTTPException(status_code=422, detail=f"Failed to create policy: {e.body}")


@router.post("/backend-traffic/circuit-breaker", response_model=ResourceResponse, status_code=201, summary="Create a circuit breaker policy")
def create_simple_circuit_breaker(
    payload: SimpleCircuitBreakerPolicy,
    target_gateway: str = Query(..., alias="targetGateway", description="Target gateway identifier"),
):
    try:
        rm = get_resource_manager(target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    
    if rm.resource_exists("BackendTrafficPolicy", payload.name):
        raise HTTPException(status_code=409, detail=f"Policy '{payload.name}' already exists")
    
    spec = {
        "targetRef": build_target_ref("HTTPRoute", payload.target_route),
        "circuitBreaker": {
            "maxConnections": payload.max_connections,
            "maxPendingRequests": payload.max_pending_requests,
            "maxParallelRequests": payload.max_parallel_requests,
        }
    }
    
    try:
        rm.create_custom_resource("BackendTrafficPolicy", payload.name, spec)
        return ResourceResponse(status="created", message=f"Circuit breaker policy '{payload.name}' created", resource_name=payload.name, namespace=rm.namespace, resource_type="BackendTrafficPolicy", details={"targetGateway": target_gateway})
    except ApiException as e:
        raise HTTPException(status_code=422, detail=f"Failed to create policy: {e.body}")


@router.post("/backend-traffic/retry", response_model=ResourceResponse, status_code=201, summary="Create a retry policy")
def create_simple_retry(
    payload: SimpleRetryPolicy,
    target_gateway: str = Query(..., alias="targetGateway", description="Target gateway identifier"),
):
    try:
        rm = get_resource_manager(target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    
    if rm.resource_exists("BackendTrafficPolicy", payload.name):
        raise HTTPException(status_code=409, detail=f"Policy '{payload.name}' already exists")
    
    triggers = []
    if payload.retry_on_5xx:
        triggers.append("5xx")
    if payload.retry_on_connect_failure:
        triggers.append("connect-failure")
    
    spec = {
        "targetRef": build_target_ref("HTTPRoute", payload.target_route),
        "retry": {
            "numRetries": payload.num_retries,
            "retryOn": {"triggers": triggers} if triggers else None,
            "perRetry": {"timeout": payload.per_retry_timeout},
        }
    }
    
    try:
        rm.create_custom_resource("BackendTrafficPolicy", payload.name, spec)
        return ResourceResponse(status="created", message=f"Retry policy '{payload.name}' created", resource_name=payload.name, namespace=rm.namespace, resource_type="BackendTrafficPolicy", details={"targetGateway": target_gateway})
    except ApiException as e:
        raise HTTPException(status_code=422, detail=f"Failed to create policy: {e.body}")


# ==================== SecurityPolicy ====================

@router.post("/security", response_model=ResourceResponse, status_code=201, summary="Create a SecurityPolicy")
def create_security_policy(
    payload: SecurityPolicyCreate,
    target_gateway: str = Query(..., alias="targetGateway", description="Target gateway identifier"),
):
    try:
        rm = get_resource_manager(target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    
    if rm.resource_exists("SecurityPolicy", payload.metadata.name):
        raise HTTPException(status_code=409, detail=f"SecurityPolicy '{payload.metadata.name}' already exists")
    
    try:
        spec = payload.spec.model_dump(by_alias=True, exclude_none=True)
        rm.create_custom_resource("SecurityPolicy", payload.metadata.name, spec, labels=payload.metadata.labels)
        return ResourceResponse(status="created", message=f"SecurityPolicy '{payload.metadata.name}' created", resource_name=payload.metadata.name, namespace=rm.namespace, resource_type="SecurityPolicy", details={"targetGateway": target_gateway})
    except ApiException as e:
        raise HTTPException(status_code=422, detail=f"Failed to create policy: {e.body}")


@router.get("/security", response_model=ResourceListResponse, summary="List SecurityPolicies")
def list_security_policies(
    target_gateway: str = Query(..., alias="targetGateway", description="Target gateway identifier"),
):
    try:
        rm = get_resource_manager(target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    
    items = rm.list_custom_resources("SecurityPolicy")
    return ResourceListResponse(items=items, total=len(items), namespace=rm.namespace)


@router.get("/security/{name}", response_model=SecurityPolicyResponse, summary="Get a SecurityPolicy")
def get_security_policy(
    name: str,
    target_gateway: str = Query(..., alias="targetGateway", description="Target gateway identifier"),
):
    try:
        rm = get_resource_manager(target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    
    policy = rm.get_custom_resource("SecurityPolicy", name)
    if not policy:
        raise HTTPException(status_code=404, detail=f"SecurityPolicy '{name}' not found")
    return SecurityPolicyResponse(**policy)


@router.put("/security/{name}", response_model=ResourceResponse, summary="Update a SecurityPolicy")
def update_security_policy(
    name: str,
    payload: SecurityPolicyUpdate,
    target_gateway: str = Query(..., alias="targetGateway", description="Target gateway identifier"),
):
    try:
        rm = get_resource_manager(target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    
    if not rm.resource_exists("SecurityPolicy", name):
        raise HTTPException(status_code=404, detail=f"SecurityPolicy '{name}' not found")
    try:
        spec = payload.spec.model_dump(by_alias=True, exclude_none=True)
        rm.update_custom_resource("SecurityPolicy", name, spec)
        return ResourceResponse(status="updated", message=f"SecurityPolicy '{name}' updated", resource_name=name, namespace=rm.namespace, resource_type="SecurityPolicy")
    except ApiException as e:
        raise HTTPException(status_code=422, detail=f"Failed to update policy: {e.body}")


@router.delete("/security/{name}", response_model=ResourceResponse, summary="Delete a SecurityPolicy")
def delete_security_policy(
    name: str,
    target_gateway: str = Query(..., alias="targetGateway", description="Target gateway identifier"),
):
    try:
        rm = get_resource_manager(target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    
    if not rm.delete_custom_resource("SecurityPolicy", name):
        raise HTTPException(status_code=404, detail=f"SecurityPolicy '{name}' not found")
    return ResourceResponse(status="deleted", message=f"SecurityPolicy '{name}' deleted", resource_name=name, namespace=rm.namespace, resource_type="SecurityPolicy")


# ==================== Simple SecurityPolicy Creation ====================

@router.post("/security/jwt", response_model=ResourceResponse, status_code=201, summary="Create a JWT authentication policy")
def create_jwt_policy(
    payload: SimpleJWTPolicy,
    target_gateway: str = Query(..., alias="targetGateway", description="Target gateway identifier"),
):
    try:
        rm = get_resource_manager(target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    
    if rm.resource_exists("SecurityPolicy", payload.name):
        raise HTTPException(status_code=409, detail=f"Policy '{payload.name}' already exists")
    
    provider = {"name": payload.name, "issuer": payload.issuer, "remoteJWKS": {"uri": str(payload.jwks_uri)}}
    if payload.audiences:
        provider["audiences"] = payload.audiences
    if payload.claim_to_headers:
        provider["claimToHeaders"] = [{"claim": k, "header": v} for k, v in payload.claim_to_headers.items()]
    
    spec = {"targetRef": build_target_ref("HTTPRoute", payload.target_route), "jwt": {"providers": [provider]}}
    
    try:
        rm.create_custom_resource("SecurityPolicy", payload.name, spec)
        return ResourceResponse(status="created", message=f"JWT policy '{payload.name}' created", resource_name=payload.name, namespace=rm.namespace, resource_type="SecurityPolicy", details={"targetGateway": target_gateway})
    except ApiException as e:
        raise HTTPException(status_code=422, detail=f"Failed to create policy: {e.body}")


@router.post("/security/cors", response_model=ResourceResponse, status_code=201, summary="Create a CORS policy")
def create_cors_policy(
    payload: SimpleCORSPolicy,
    target_gateway: str = Query(..., alias="targetGateway", description="Target gateway identifier"),
):
    try:
        rm = get_resource_manager(target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    
    if rm.resource_exists("SecurityPolicy", payload.name):
        raise HTTPException(status_code=409, detail=f"Policy '{payload.name}' already exists")
    
    # Envoy Gateway CRD requires origins to be '*' or full URLs (http:// or https://)
    normalized_origins = []
    for o in payload.allowed_origins:
        if o == "*" or o.startswith("http://") or o.startswith("https://"):
            normalized_origins.append(o)
        else:
            normalized_origins.append(f"https://{o}")

    cors_config = {
        "allowOrigins": normalized_origins,
        "allowMethods": payload.allowed_methods,
        "allowHeaders": payload.allowed_headers,
        "allowCredentials": payload.allow_credentials,
        "maxAge": payload.max_age,
    }
    if payload.expose_headers:
        cors_config["exposeHeaders"] = payload.expose_headers
    
    spec = {"targetRef": build_target_ref("HTTPRoute", payload.target_route), "cors": cors_config}
    
    try:
        rm.create_custom_resource("SecurityPolicy", payload.name, spec)
        return ResourceResponse(status="created", message=f"CORS policy '{payload.name}' created", resource_name=payload.name, namespace=rm.namespace, resource_type="SecurityPolicy", details={"targetGateway": target_gateway})
    except ApiException as e:
        raise HTTPException(status_code=422, detail=f"Failed to create policy: {e.body}")


@router.post("/security/api-key", response_model=ResourceResponse, status_code=201, summary="Create an API key policy")
def create_api_key_policy(
    payload: SimpleAPIKeyPolicy,
    target_gateway: str = Query(..., alias="targetGateway", description="Target gateway identifier"),
):
    try:
        rm = get_resource_manager(target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    
    if rm.resource_exists("SecurityPolicy", payload.name):
        raise HTTPException(status_code=409, detail=f"Policy '{payload.name}' already exists")
    
    spec = {
        "targetRef": build_target_ref("HTTPRoute", payload.target_route),
        "apiKey": {
            "extractFrom": {"headers": [payload.header_name]},
            "credentials": [{"kind": "Secret", "name": payload.api_keys_secret}],
        }
    }
    
    try:
        rm.create_custom_resource("SecurityPolicy", payload.name, spec)
        return ResourceResponse(status="created", message=f"API key policy '{payload.name}' created", resource_name=payload.name, namespace=rm.namespace, resource_type="SecurityPolicy", details={"targetGateway": target_gateway})
    except ApiException as e:
        raise HTTPException(status_code=422, detail=f"Failed to create policy: {e.body}")


@router.post("/security/basic-auth", response_model=ResourceResponse, status_code=201, summary="Create a basic auth policy")
def create_basic_auth_policy(
    payload: SimpleBasicAuthPolicy,
    target_gateway: str = Query(..., alias="targetGateway", description="Target gateway identifier"),
):
    try:
        rm = get_resource_manager(target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    
    if rm.resource_exists("SecurityPolicy", payload.name):
        raise HTTPException(status_code=409, detail=f"Policy '{payload.name}' already exists")
    
    spec = {
        "targetRef": build_target_ref("HTTPRoute", payload.target_route),
        "basicAuth": {"users": {"kind": "Secret", "name": payload.users_secret}},
    }
    
    try:
        rm.create_custom_resource("SecurityPolicy", payload.name, spec)
        return ResourceResponse(status="created", message=f"Basic auth policy '{payload.name}' created", resource_name=payload.name, namespace=rm.namespace, resource_type="SecurityPolicy", details={"targetGateway": target_gateway})
    except ApiException as e:
        raise HTTPException(status_code=422, detail=f"Failed to create policy: {e.body}")


@router.post("/security/ip-allowlist", response_model=ResourceResponse, status_code=201, summary="Create an IP allowlist policy")
def create_ip_allowlist_policy(
    payload: SimpleIPAllowlistPolicy,
    target_gateway: str = Query(..., alias="targetGateway", description="Target gateway identifier"),
):
    """Create a policy that only allows requests from specified CIDR ranges."""
    try:
        rm = get_resource_manager(target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    
    if rm.resource_exists("SecurityPolicy", payload.name):
        raise HTTPException(status_code=409, detail=f"Policy '{payload.name}' already exists")
    
    spec = {
        "targetRef": build_target_ref("HTTPRoute", payload.target_route),
        "authorization": {
            "defaultAction": "Deny",
            "rules": [{
                "name": "allow-cidrs",
                "action": "Allow",
                "principal": {"clientCIDRs": payload.allowed_cidrs}
            }]
        }
    }
    
    try:
        rm.create_custom_resource("SecurityPolicy", payload.name, spec)
        return ResourceResponse(status="created", message=f"IP allowlist policy '{payload.name}' created", resource_name=payload.name, namespace=rm.namespace, resource_type="SecurityPolicy", details={"allowed_cidrs": payload.allowed_cidrs, "targetGateway": target_gateway})
    except ApiException as e:
        raise HTTPException(status_code=422, detail=f"Failed to create policy: {e.body}")


@router.post("/security/ip-blocklist", response_model=ResourceResponse, status_code=201, summary="Create an IP blocklist policy")
def create_ip_blocklist_policy(
    payload: SimpleIPBlocklistPolicy,
    target_gateway: str = Query(..., alias="targetGateway", description="Target gateway identifier"),
):
    """Create a policy that blocks requests from specified CIDR ranges."""
    try:
        rm = get_resource_manager(target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    
    if rm.resource_exists("SecurityPolicy", payload.name):
        raise HTTPException(status_code=409, detail=f"Policy '{payload.name}' already exists")
    
    spec = {
        "targetRef": build_target_ref("HTTPRoute", payload.target_route),
        "authorization": {
            "defaultAction": "Allow",
            "rules": [{
                "name": "block-cidrs",
                "action": "Deny",
                "principal": {"clientCIDRs": payload.blocked_cidrs}
            }]
        }
    }
    
    try:
        rm.create_custom_resource("SecurityPolicy", payload.name, spec)
        return ResourceResponse(status="created", message=f"IP blocklist policy '{payload.name}' created", resource_name=payload.name, namespace=rm.namespace, resource_type="SecurityPolicy", details={"blocked_cidrs": payload.blocked_cidrs, "targetGateway": target_gateway})
    except ApiException as e:
        raise HTTPException(status_code=422, detail=f"Failed to create policy: {e.body}")


@router.post("/security/external-auth", response_model=ResourceResponse, status_code=201, summary="Create an external auth policy")
def create_external_auth_policy(
    payload: SimpleExternalAuthPolicy,
    target_gateway: str = Query(..., alias="targetGateway", description="Target gateway identifier"),
):
    """Create a policy that delegates authentication to an external service."""
    try:
        rm = get_resource_manager(target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    
    if rm.resource_exists("SecurityPolicy", payload.name):
        raise HTTPException(status_code=409, detail=f"Policy '{payload.name}' already exists")
    
    spec = {
        "targetRef": build_target_ref("HTTPRoute", payload.target_route),
        "extAuth": {
            "http": {
                "backendRef": {"name": payload.auth_service_name, "port": payload.auth_service_port},
                "path": payload.auth_path,
                "headersToBackend": payload.headers_to_auth,
            },
            "headersToExtAuth": payload.headers_to_auth,
            "failureMode": payload.failure_mode.value,
        }
    }
    
    try:
        rm.create_custom_resource("SecurityPolicy", payload.name, spec)
        return ResourceResponse(status="created", message=f"External auth policy '{payload.name}' created", resource_name=payload.name, namespace=rm.namespace, resource_type="SecurityPolicy", details={"auth_service": f"{payload.auth_service_name}:{payload.auth_service_port}", "targetGateway": target_gateway})
    except ApiException as e:
        raise HTTPException(status_code=422, detail=f"Failed to create policy: {e.body}")


# ==================== ClientTrafficPolicy ====================

@router.post("/client-traffic", response_model=ResourceResponse, status_code=201, summary="Create a ClientTrafficPolicy")
def create_client_traffic_policy(
    payload: ClientTrafficPolicyCreate,
    target_gateway: str = Query(..., alias="targetGateway", description="Target gateway identifier"),
):
    try:
        rm = get_resource_manager(target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    
    if rm.resource_exists("ClientTrafficPolicy", payload.metadata.name):
        raise HTTPException(status_code=409, detail=f"ClientTrafficPolicy '{payload.metadata.name}' already exists")
    
    try:
        spec = payload.spec.model_dump(by_alias=True, exclude_none=True)
        rm.create_custom_resource("ClientTrafficPolicy", payload.metadata.name, spec, labels=payload.metadata.labels)
        return ResourceResponse(status="created", message=f"ClientTrafficPolicy '{payload.metadata.name}' created", resource_name=payload.metadata.name, namespace=rm.namespace, resource_type="ClientTrafficPolicy", details={"targetGateway": target_gateway})
    except ApiException as e:
        raise HTTPException(status_code=422, detail=f"Failed to create policy: {e.body}")


@router.get("/client-traffic", response_model=ResourceListResponse, summary="List ClientTrafficPolicies")
def list_client_traffic_policies(
    target_gateway: str = Query(..., alias="targetGateway", description="Target gateway identifier"),
):
    try:
        rm = get_resource_manager(target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    
    items = rm.list_custom_resources("ClientTrafficPolicy")
    return ResourceListResponse(items=items, total=len(items), namespace=rm.namespace)


@router.get("/client-traffic/{name}", response_model=ClientTrafficPolicyResponse, summary="Get a ClientTrafficPolicy")
def get_client_traffic_policy(
    name: str,
    target_gateway: str = Query(..., alias="targetGateway", description="Target gateway identifier"),
):
    try:
        rm = get_resource_manager(target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    
    policy = rm.get_custom_resource("ClientTrafficPolicy", name)
    if not policy:
        raise HTTPException(status_code=404, detail=f"ClientTrafficPolicy '{name}' not found")
    return ClientTrafficPolicyResponse(**policy)


@router.delete("/client-traffic/{name}", response_model=ResourceResponse, summary="Delete a ClientTrafficPolicy")
def delete_client_traffic_policy(
    name: str,
    target_gateway: str = Query(..., alias="targetGateway", description="Target gateway identifier"),
):
    try:
        rm = get_resource_manager(target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    
    if not rm.delete_custom_resource("ClientTrafficPolicy", name):
        raise HTTPException(status_code=404, detail=f"ClientTrafficPolicy '{name}' not found")
    return ResourceResponse(status="deleted", message=f"ClientTrafficPolicy '{name}' deleted", resource_name=name, namespace=rm.namespace, resource_type="ClientTrafficPolicy")


# ==================== Simple ClientTrafficPolicy Creation ====================

@router.post("/client-traffic/tls", response_model=ResourceResponse, status_code=201, summary="Create a TLS policy")
def create_tls_policy(
    payload: SimpleTLSPolicy,
    target_gateway: str = Query(..., alias="targetGateway", description="Target gateway identifier"),
):
    try:
        rm = get_resource_manager(target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    
    if rm.resource_exists("ClientTrafficPolicy", payload.name):
        raise HTTPException(status_code=409, detail=f"Policy '{payload.name}' already exists")
    
    spec = {
        "targetRef": build_target_ref("Gateway", payload.target_gateway),
        "tls": {"minVersion": payload.min_version.value, "maxVersion": payload.max_version.value},
    }
    if payload.ciphers:
        spec["tls"]["ciphers"] = payload.ciphers
    
    try:
        rm.create_custom_resource("ClientTrafficPolicy", payload.name, spec)
        return ResourceResponse(status="created", message=f"TLS policy '{payload.name}' created", resource_name=payload.name, namespace=rm.namespace, resource_type="ClientTrafficPolicy", details={"targetGateway": target_gateway})
    except ApiException as e:
        raise HTTPException(status_code=422, detail=f"Failed to create policy: {e.body}")


@router.post("/client-traffic/timeout", response_model=ResourceResponse, status_code=201, summary="Create a timeout policy")
def create_timeout_policy(
    payload: SimpleTimeoutPolicy,
    target_gateway: str = Query(..., alias="targetGateway", description="Target gateway identifier"),
):
    try:
        rm = get_resource_manager(target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    
    if rm.resource_exists("ClientTrafficPolicy", payload.name):
        raise HTTPException(status_code=409, detail=f"Policy '{payload.name}' already exists")
    
    spec = {
        "targetRef": build_target_ref("Gateway", payload.target_gateway),
        "timeout": {
            "tcp": {"connectTimeout": payload.connect_timeout},
            "http": {"requestReceivedTimeout": payload.request_timeout, "idleTimeout": payload.idle_timeout},
        },
    }
    
    try:
        rm.create_custom_resource("ClientTrafficPolicy", payload.name, spec)
        return ResourceResponse(status="created", message=f"Timeout policy '{payload.name}' created", resource_name=payload.name, namespace=rm.namespace, resource_type="ClientTrafficPolicy", details={"targetGateway": target_gateway})
    except ApiException as e:
        raise HTTPException(status_code=422, detail=f"Failed to create policy: {e.body}")


# ==================== EnvoyPatchPolicy ====================

@router.post("/envoy-patch", response_model=ResourceResponse, status_code=201, summary="Create an EnvoyPatchPolicy")
def create_envoy_patch_policy(
    payload: EnvoyPatchPolicyCreate,
    target_gateway: str = Query(..., alias="targetGateway", description="Target gateway identifier"),
):
    try:
        rm = get_resource_manager(target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    
    if rm.resource_exists("EnvoyPatchPolicy", payload.metadata.name):
        raise HTTPException(status_code=409, detail=f"EnvoyPatchPolicy '{payload.metadata.name}' already exists")
    
    try:
        spec = payload.spec.model_dump(by_alias=True, exclude_none=True)
        rm.create_custom_resource("EnvoyPatchPolicy", payload.metadata.name, spec, labels=payload.metadata.labels)
        return ResourceResponse(status="created", message=f"EnvoyPatchPolicy '{payload.metadata.name}' created", resource_name=payload.metadata.name, namespace=rm.namespace, resource_type="EnvoyPatchPolicy", details={"targetGateway": target_gateway})
    except ApiException as e:
        raise HTTPException(status_code=422, detail=f"Failed to create policy: {e.body}")


@router.get("/envoy-patch", response_model=ResourceListResponse, summary="List EnvoyPatchPolicies")
def list_envoy_patch_policies(
    target_gateway: str = Query(..., alias="targetGateway", description="Target gateway identifier"),
):
    try:
        rm = get_resource_manager(target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    
    items = rm.list_custom_resources("EnvoyPatchPolicy")
    return ResourceListResponse(items=items, total=len(items), namespace=rm.namespace)


@router.delete("/envoy-patch/{name}", response_model=ResourceResponse, summary="Delete an EnvoyPatchPolicy")
def delete_envoy_patch_policy(
    name: str,
    target_gateway: str = Query(..., alias="targetGateway", description="Target gateway identifier"),
):
    try:
        rm = get_resource_manager(target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    
    if not rm.delete_custom_resource("EnvoyPatchPolicy", name):
        raise HTTPException(status_code=404, detail=f"EnvoyPatchPolicy '{name}' not found")
    return ResourceResponse(status="deleted", message=f"EnvoyPatchPolicy '{name}' deleted", resource_name=name, namespace=rm.namespace, resource_type="EnvoyPatchPolicy")


# ==================== EnvoyExtensionPolicy ====================

@router.post("/envoy-extension", response_model=ResourceResponse, status_code=201, summary="Create an EnvoyExtensionPolicy")
def create_envoy_extension_policy(
    payload: EnvoyExtensionPolicyCreate,
    target_gateway: str = Query(..., alias="targetGateway", description="Target gateway identifier"),
):
    try:
        rm = get_resource_manager(target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    
    if rm.resource_exists("EnvoyExtensionPolicy", payload.metadata.name):
        raise HTTPException(status_code=409, detail=f"EnvoyExtensionPolicy '{payload.metadata.name}' already exists")
    
    try:
        spec = payload.spec.model_dump(by_alias=True, exclude_none=True)
        rm.create_custom_resource("EnvoyExtensionPolicy", payload.metadata.name, spec, labels=payload.metadata.labels)
        return ResourceResponse(status="created", message=f"EnvoyExtensionPolicy '{payload.metadata.name}' created", resource_name=payload.metadata.name, namespace=rm.namespace, resource_type="EnvoyExtensionPolicy", details={"targetGateway": target_gateway})
    except ApiException as e:
        raise HTTPException(status_code=422, detail=f"Failed to create policy: {e.body}")


@router.get("/envoy-extension", response_model=ResourceListResponse, summary="List EnvoyExtensionPolicies")
def list_envoy_extension_policies(
    target_gateway: str = Query(..., alias="targetGateway", description="Target gateway identifier"),
):
    try:
        rm = get_resource_manager(target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    
    items = rm.list_custom_resources("EnvoyExtensionPolicy")
    return ResourceListResponse(items=items, total=len(items), namespace=rm.namespace)


@router.delete("/envoy-extension/{name}", response_model=ResourceResponse, summary="Delete an EnvoyExtensionPolicy")
def delete_envoy_extension_policy(
    name: str,
    target_gateway: str = Query(..., alias="targetGateway", description="Target gateway identifier"),
):
    try:
        rm = get_resource_manager(target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    
    if not rm.delete_custom_resource("EnvoyExtensionPolicy", name):
        raise HTTPException(status_code=404, detail=f"EnvoyExtensionPolicy '{name}' not found")
    return ResourceResponse(status="deleted", message=f"EnvoyExtensionPolicy '{name}' deleted", resource_name=name, namespace=rm.namespace, resource_type="EnvoyExtensionPolicy")


# ==================== Simple Extension Creation ====================

@router.post("/envoy-extension/wasm", response_model=ResourceResponse, status_code=201, summary="Create a WASM extension policy")
def create_wasm_extension(
    payload: SimpleWasmExtension,
    target_gateway: str = Query(..., alias="targetGateway", description="Target gateway identifier"),
):
    try:
        rm = get_resource_manager(target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    
    if rm.resource_exists("EnvoyExtensionPolicy", payload.name):
        raise HTTPException(status_code=409, detail=f"Policy '{payload.name}' already exists")
    
    code_source = {"type": "HTTP", "http": {"url": payload.wasm_url}}
    if payload.wasm_url.startswith("oci://"):
        code_source = {"type": "Image", "image": {"url": payload.wasm_url}}
    
    spec = {
        "targetRef": build_target_ref("HTTPRoute", payload.target_route),
        "wasm": [{"name": payload.wasm_name, "code": code_source, "config": payload.wasm_config, "failOpen": payload.fail_open}],
    }
    
    try:
        rm.create_custom_resource("EnvoyExtensionPolicy", payload.name, spec)
        return ResourceResponse(status="created", message=f"WASM extension '{payload.name}' created", resource_name=payload.name, namespace=rm.namespace, resource_type="EnvoyExtensionPolicy", details={"targetGateway": target_gateway})
    except ApiException as e:
        raise HTTPException(status_code=422, detail=f"Failed to create policy: {e.body}")


@router.post("/envoy-extension/ext-proc", response_model=ResourceResponse, status_code=201, summary="Create an external processor policy")
def create_ext_proc_extension(
    payload: SimpleExtProcExtension,
    target_gateway: str = Query(..., alias="targetGateway", description="Target gateway identifier"),
):
    try:
        rm = get_resource_manager(target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    
    if rm.resource_exists("EnvoyExtensionPolicy", payload.name):
        raise HTTPException(status_code=409, detail=f"Policy '{payload.name}' already exists")
    
    processing_mode = {}
    if payload.process_request_headers or payload.process_request_body:
        processing_mode["request"] = {}
        if payload.process_request_headers:
            processing_mode["request"]["headers"] = "SEND"
        if payload.process_request_body:
            processing_mode["request"]["body"] = "BUFFERED"
    if payload.process_response_headers or payload.process_response_body:
        processing_mode["response"] = {}
        if payload.process_response_headers:
            processing_mode["response"]["headers"] = "SEND"
        if payload.process_response_body:
            processing_mode["response"]["body"] = "BUFFERED"
    
    spec = {
        "targetRef": build_target_ref("HTTPRoute", payload.target_route),
        "extProc": [{"backendRefs": [{"name": payload.service_name, "port": payload.service_port}], "processingMode": processing_mode if processing_mode else None, "failureMode": payload.failure_mode}],
    }
    
    try:
        rm.create_custom_resource("EnvoyExtensionPolicy", payload.name, spec)
        return ResourceResponse(status="created", message=f"ExtProc extension '{payload.name}' created", resource_name=payload.name, namespace=rm.namespace, resource_type="EnvoyExtensionPolicy", details={"targetGateway": target_gateway})
    except ApiException as e:
        raise HTTPException(status_code=422, detail=f"Failed to create policy: {e.body}")


# ==================== Access Logging (EnvoyProxy) ====================

@router.post("/logging/access-log", response_model=ResourceResponse, status_code=201, summary="Configure access logging")
def create_access_log_config(
    payload: SimpleAccessLogConfig,
    target_gateway: str = Query(..., alias="targetGateway", description="Target gateway identifier"),
):
    """Configure access logging via EnvoyProxy resource."""
    try:
        rm = get_resource_manager(target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    
    if rm.resource_exists("EnvoyProxy", payload.name):
        raise HTTPException(status_code=409, detail=f"EnvoyProxy config '{payload.name}' already exists")
    
    sink = {"type": "File", "file": {"path": payload.output}}
    settings = {"sinks": [sink]}
    
    if payload.format.value == "JSON":
        json_format = {
            "start_time": "%START_TIME%", "method": "%REQ(:METHOD)%", "path": "%REQ(X-ENVOY-ORIGINAL-PATH?:PATH)%",
            "protocol": "%PROTOCOL%", "response_code": "%RESPONSE_CODE%", "response_flags": "%RESPONSE_FLAGS%",
            "bytes_received": "%BYTES_RECEIVED%", "bytes_sent": "%BYTES_SENT%", "duration": "%DURATION%",
            "upstream_host": "%UPSTREAM_HOST%", "x_forwarded_for": "%REQ(X-FORWARDED-FOR)%",
            "user_agent": "%REQ(USER-AGENT)%", "request_id": "%REQ(X-REQUEST-ID)%", "authority": "%REQ(:AUTHORITY)%",
        }
        if payload.include_headers:
            for header in payload.include_headers:
                json_format[header.lower().replace("-", "_")] = f"%REQ({header})%"
        settings["json"] = {"json": json_format}
    else:
        settings["text"] = {"text": '[%START_TIME%] "%REQ(:METHOD)% %REQ(X-ENVOY-ORIGINAL-PATH?:PATH)% %PROTOCOL%" %RESPONSE_CODE% %RESPONSE_FLAGS% %BYTES_RECEIVED% %BYTES_SENT% %DURATION% "%REQ(X-FORWARDED-FOR)%" "%REQ(USER-AGENT)%" "%REQ(X-REQUEST-ID)%" "%REQ(:AUTHORITY)%" "%UPSTREAM_HOST%"'}
    
    spec = {"telemetry": {"accessLog": {"disable": not payload.enabled, "settings": [settings]}}}
    
    try:
        rm.create_custom_resource("EnvoyProxy", payload.name, spec)
        return ResourceResponse(status="created", message=f"Access logging config '{payload.name}' created", resource_name=payload.name, namespace=rm.namespace, resource_type="EnvoyProxy", details={"format": payload.format.value, "output": payload.output, "targetGateway": target_gateway})
    except ApiException as e:
        raise HTTPException(status_code=422, detail=f"Failed to create config: {e.body}")


@router.post("/logging/otlp", response_model=ResourceResponse, status_code=201, summary="Configure OpenTelemetry logging")
def create_otlp_logging_config(
    payload: SimpleOTLPLoggingConfig,
    target_gateway: str = Query(..., alias="targetGateway", description="Target gateway identifier"),
):
    """Configure OpenTelemetry logging via EnvoyProxy resource."""
    try:
        rm = get_resource_manager(target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    
    if rm.resource_exists("EnvoyProxy", payload.name):
        raise HTTPException(status_code=409, detail=f"EnvoyProxy config '{payload.name}' already exists")
    
    spec = {
        "telemetry": {
            "accessLog": {
                "settings": [{"sinks": [{"type": "OpenTelemetry", "openTelemetry": {"host": payload.otlp_host, "port": payload.otlp_port, "resources": {"service.name": payload.service_name}}}]}]
            }
        }
    }
    
    try:
        rm.create_custom_resource("EnvoyProxy", payload.name, spec)
        return ResourceResponse(status="created", message=f"OTLP logging config '{payload.name}' created", resource_name=payload.name, namespace=rm.namespace, resource_type="EnvoyProxy", details={"otlp_endpoint": f"{payload.otlp_host}:{payload.otlp_port}", "targetGateway": target_gateway})
    except ApiException as e:
        raise HTTPException(status_code=422, detail=f"Failed to create config: {e.body}")


@router.get("/logging", response_model=ResourceListResponse, summary="List logging configurations")
def list_logging_configs(
    target_gateway: str = Query(..., alias="targetGateway", description="Target gateway identifier"),
):
    """List EnvoyProxy configurations (used for logging)."""
    try:
        rm = get_resource_manager(target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    
    items = rm.list_custom_resources("EnvoyProxy")
    return ResourceListResponse(items=items, total=len(items), namespace=rm.namespace)


@router.delete("/logging/{name}", response_model=ResourceResponse, summary="Delete a logging configuration")
def delete_logging_config(
    name: str,
    target_gateway: str = Query(..., alias="targetGateway", description="Target gateway identifier"),
):
    try:
        rm = get_resource_manager(target_gateway)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    
    if not rm.delete_custom_resource("EnvoyProxy", name):
        raise HTTPException(status_code=404, detail=f"EnvoyProxy config '{name}' not found")
    return ResourceResponse(status="deleted", message=f"Logging config '{name}' deleted", resource_name=name, namespace=rm.namespace, resource_type="EnvoyProxy")
