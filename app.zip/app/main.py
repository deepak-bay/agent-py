"""
Envoy Gateway Agent API
A comprehensive REST API for managing Envoy Gateway resources on Kubernetes.

Author: GKNQT (Ajay Vunnam)
"""

import logging
from contextlib import asynccontextmanager
from datetime import datetime

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi.openapi.docs import get_swagger_ui_html, get_redoc_html
from fastapi.openapi.utils import get_openapi

from .config import get_settings, get_current_env, get_available_gateways
from .routers import (
    routes_router,
    backends_router,
    policies_router,
    secrets_router,
    openapi_router,
    gateways_router,
    ai_gateway_router,
    api_management_router,
    api_management_v2_router,
    configmaps_router,
)
from .services.k8s_client import get_k8s_client
from .models.common import HealthResponse, ErrorResponse

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan manager."""
    settings = get_settings()
    env = get_current_env()
    gateways = get_available_gateways()
    
    logger.info("=" * 60)
    logger.info("Starting Envoy Gateway Agent API")
    logger.info("=" * 60)
    logger.info(f"Environment: {env.upper()}")
    logger.info(f"Debug Mode: {settings.debug}")
    logger.info(f"Log Level: {settings.log_level}")
    logger.info(f"Default Cluster: {settings.eks_cluster_name}")
    logger.info(f"Default Namespace: {settings.k8s_namespace}")
    logger.info(f"Available Gateways: {', '.join(gateways.keys())}")
    logger.info("=" * 60)
    yield
    logger.info("Shutting down Envoy Gateway Agent API...")


# Create FastAPI application
settings = get_settings()

app = FastAPI(
    title=settings.api_title,
    description="""
## Envoy Gateway Agent API

A REST API for managing Envoy Gateway resources on Kubernetes/EKS.

### Features

- **Route Management**: Manage HTTPRoute, GRPCRoute, TLSRoute, TCPRoute, and UDPRoute
- **Backend Management**: Configure Backend services and ExternalName services
- **Policy Management**: Apply traffic and security policies including:
  - **BackendTrafficPolicy**: Rate limiting, circuit breaker, retries, timeouts, health checks, load balancing
  - **SecurityPolicy**: JWT, OIDC, Basic Auth, API Keys, CORS, External Auth
  - **ClientTrafficPolicy**: TLS settings, HTTP/2 configuration, timeouts
  - **EnvoyPatchPolicy**: Custom Envoy configuration patches
  - **EnvoyExtensionPolicy**: WASM and External Processor extensions
- **AI Gateway**: Route traffic to AI/LLM providers (OpenAI, Azure OpenAI, AWS Bedrock) with token rate limiting and model routing
- **Secret Management**: TLS certificates, credentials, and API keys

### Authentication

This API uses AWS IAM authentication to connect to EKS clusters.

### Namespace

All resources are created in the configured namespace by default. Use the
`namespace` query parameter to override.
    """,
    version=settings.api_version,
    docs_url=None,
    redoc_url=None,
    openapi_url=f"{settings.api_prefix}/openapi.json",
    lifespan=lifespan,
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# Custom OpenAPI schema
def custom_openapi():
    if app.openapi_schema:
        return app.openapi_schema
    
    openapi_schema = get_openapi(
        title=settings.api_title,
        version=settings.api_version,
        description=app.description,
        routes=app.routes,
    )
    
    openapi_schema["info"]["contact"] = {
        "name": "GKNQT (Ajay Vunnam)",
    }
    openapi_schema["info"]["license"] = {
        "name": "Apache 2.0",
        "url": "https://www.apache.org/licenses/LICENSE-2.0.html",
    }
    
    openapi_schema["servers"] = [
        {"url": f"http://localhost:{settings.port}", "description": "Local development"},
        {"url": "https://envoy-agent-api.integration-sbx.int.bayer.com", "description": "Innovation Account Sandbox"},
        {"url": "https://envoy-agent-api-np.agro.services", "description": "Envoy sbx"},
    ]
    
    openapi_schema["tags"] = [
        {"name": "Health", "description": "Health check and cluster info endpoints"},
        {"name": "Gateways", "description": "List and view target gateway configurations"},
        {"name": "API Management", "description": "Create, update, delete, and list APIs with automatic route, backend, and policy orchestration"},
        {"name": "AI Gateway", "description": "Manage AI/LLM service backends, routes, and policies for providers like OpenAI, Azure OpenAI, AWS Bedrock"},
        {"name": "Routes", "description": "Manage HTTPRoute, GRPCRoute, TLSRoute, TCPRoute, and UDPRoute resources"},
        {"name": "Backends", "description": "Manage Backend and Service resources for upstream services"},
        {"name": "ConfigMaps", "description": "Manage ConfigMaps for CA certificates and TLS Secrets for mTLS client certificates"},
        {"name": "Policies", "description": "Manage traffic and security policies"},
        {"name": "Secrets", "description": "Manage Kubernetes Secrets for TLS, credentials, and API keys"},
        {"name": "OpenAPI Import", "description": "Import routes from OpenAPI/Swagger specifications"},
    ]
    
    app.openapi_schema = openapi_schema
    return app.openapi_schema


app.openapi = custom_openapi


# ==================== Documentation Routes ====================

@app.get("/docs", include_in_schema=False)
async def custom_swagger_ui_html():
    return get_swagger_ui_html(
        openapi_url=f"{settings.api_prefix}/openapi.json",
        title=f"{settings.api_title} - Swagger UI",
        swagger_js_url="https://cdn.jsdelivr.net/npm/swagger-ui-dist@5/swagger-ui-bundle.js",
        swagger_css_url="https://cdn.jsdelivr.net/npm/swagger-ui-dist@5/swagger-ui.css",
    )


@app.get("/redoc", include_in_schema=False)
async def redoc_html():
    return get_redoc_html(
        openapi_url=f"{settings.api_prefix}/openapi.json",
        title=f"{settings.api_title} - ReDoc",
        redoc_js_url="https://cdn.jsdelivr.net/npm/redoc@next/bundles/redoc.standalone.js",
    )


# ==================== Health and Info Routes ====================

@app.get(
    "/health",
    response_model=HealthResponse,
    tags=["Health"],
    summary="Health Check",
    description="Check if the API is healthy and can connect to Kubernetes.",
)
def health_check():
    """Health check endpoint."""
    k8s = get_k8s_client()
    k8s_connected = k8s.health_check()
    cluster_info = k8s.get_cluster_info() if k8s_connected else None
    
    return HealthResponse(
        status="healthy" if k8s_connected else "degraded",
        version=settings.api_version,
        kubernetes_connected=k8s_connected,
        cluster_name=cluster_info.get("cluster_name") if cluster_info else None,
        timestamp=datetime.utcnow(),
    )


@app.get(
    "/info",
    tags=["Health"],
    summary="API Information",
    description="Get API and cluster information.",
)
def get_info():
    """Get API and cluster information."""
    k8s = get_k8s_client()
    cluster_info = k8s.get_cluster_info()
    gateways = get_available_gateways()
    
    return {
        "api": {
            "title": settings.api_title,
            "version": settings.api_version,
            "prefix": settings.api_prefix,
        },
        "environment": {
            "name": get_current_env(),
            "debug": settings.debug,
            "log_level": settings.log_level,
        },
        "cluster": cluster_info,
        "defaults": {
            "namespace": settings.k8s_namespace,
            "gateway_name": settings.default_gateway_name,
        },
        "available_gateways": list(gateways.keys()),
    }


@app.get(
    "/whoami",
    tags=["Health"],
    summary="AWS Identity",
    description="Get the current AWS caller identity.",
)
def whoami():
    """Get AWS caller identity."""
    import boto3
    sts = boto3.client("sts", region_name=settings.aws_region)
    return sts.get_caller_identity()


# ==================== Exception Handlers ====================

@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    """Global exception handler."""
    logger.error(f"Unhandled exception: {exc}", exc_info=True)
    return JSONResponse(
        status_code=500,
        content={
            "error": "InternalServerError",
            "message": str(exc),
            "timestamp": datetime.utcnow().isoformat(),
        },
    )


# ==================== Include Routers ====================

app.include_router(gateways_router, prefix=settings.api_prefix)
app.include_router(api_management_router, prefix=settings.api_prefix)
app.include_router(api_management_v2_router, prefix=settings.api_prefix)  # V2 unified endpoint
app.include_router(routes_router, prefix=settings.api_prefix)
app.include_router(backends_router, prefix=settings.api_prefix)
app.include_router(configmaps_router, prefix=settings.api_prefix)
app.include_router(policies_router, prefix=settings.api_prefix)
app.include_router(secrets_router, prefix=settings.api_prefix)
app.include_router(openapi_router, prefix=settings.api_prefix)
app.include_router(ai_gateway_router, prefix=settings.api_prefix)


# ==================== Root Route ====================

@app.get("/", include_in_schema=False)
def root():
    """Root endpoint with API information."""
    return {
        "name": settings.api_title,
        "version": settings.api_version,
        "docs": "/docs",
        "redoc": "/redoc",
        "openapi": f"{settings.api_prefix}/openapi.json",
        "health": "/health",
    }


# ==================== Entry Point ====================

def run():
    """Run the application with Hypercorn."""
    import asyncio
    from hypercorn.asyncio import serve
    from hypercorn.config import Config
    
    config = Config()
    config.bind = [f"{settings.host}:{settings.port}"]
    config.use_reloader = settings.debug
    config.accesslog = "-"
    
    logger.info(f"Starting server on {settings.host}:{settings.port}")
    asyncio.run(serve(app, config))


if __name__ == "__main__":
    run()
