"""
Shared Backend Service - Single source of truth for Backend CRD operations.

This service is used by both:
- POST /api/v1/api (api_management.py)
- POST /api/v1/routes/http (routes.py)
- POST /api/v2/api (api_management_v2.py)

Any fix or feature added here automatically works in all endpoints.
"""

import logging
from typing import Optional, Tuple, Dict, Any
from urllib.parse import urlparse

from .resource_manager import ResourceManager

logger = logging.getLogger(__name__)


def parse_upstream_url(url: str) -> Tuple[str, int, bool]:
    """
    Parse an upstream URL to extract hostname, port, and TLS flag.
    
    Args:
        url: The upstream URL (e.g., "https://api.example.com:8443")
        
    Returns:
        Tuple of (hostname, port, uses_tls)
    """
    parsed = urlparse(url)
    scheme = parsed.scheme.lower() if parsed.scheme else "http"
    uses_tls = scheme == "https"
    hostname = parsed.hostname or url
    port = parsed.port or (443 if uses_tls else 80)
    return hostname, port, uses_tls


def create_backend(
    rm: ResourceManager,
    name: str,
    upstream_url: Optional[str] = None,
    hostname: Optional[str] = None,
    port: Optional[int] = None,
    labels: Optional[Dict[str, str]] = None,
    annotations: Optional[Dict[str, str]] = None,
    tls_certificate: Optional[str] = None,
    app_protocol: Optional[str] = None,
    backend_tls: Optional[Dict[str, Any]] = None,
    uses_tls: bool = False,
) -> Dict[str, Any]:
    """
    Create an Envoy Gateway Backend CRD.
    
    This is the SINGLE source of truth for Backend creation.
    All endpoints should use this function.
    
    Args:
        rm: ResourceManager instance for the target gateway
        name: Backend resource name
        upstream_url: The upstream service URL (e.g., "https://api.example.com")
                      If provided, hostname/port/uses_tls are extracted from it.
        hostname: Backend hostname (alternative to upstream_url)
        port: Backend port (alternative to upstream_url)
        labels: Optional labels to apply to the Backend
        annotations: Optional annotations to apply to the Backend
        tls_certificate: Optional TLS certificate secret reference
        app_protocol: Optional protocol (ONLY valid values: "gateway.envoyproxy.io/h2c", 
                      "gateway.envoyproxy.io/ws", "gateway.envoyproxy.io/wss")
                      Do NOT pass "http" or "https" - these are invalid!
        backend_tls: Optional Backend TLS configuration for upstream TLS verification
                     Example: {"caCertificateRefs": [{"name": "ca-cert", "kind": "ConfigMap"}]}
        uses_tls: Whether the backend uses TLS (only used if upstream_url not provided)
    
    Returns:
        The created Backend spec dict
        
    Note:
        - appProtocols field only supports h2c, ws, wss (NOT http/https)
        - For standard HTTP/HTTPS backends, do NOT include appProtocols
        - TLS to upstream is determined by the URL scheme (https://)
    """
    # Parse the upstream URL if provided, otherwise use hostname/port directly
    if upstream_url:
        final_hostname, final_port, uses_tls = parse_upstream_url(upstream_url)
    else:
        final_hostname = hostname or "localhost"
        final_port = port or 80
    
    # Build Backend CRD spec with FQDN endpoint
    backend_spec: Dict[str, Any] = {
        "endpoints": [
            {
                "fqdn": {
                    "hostname": final_hostname,
                    "port": final_port,
                }
            }
        ],
    }
    
    # IMPORTANT: Only add appProtocols if explicitly provided AND valid
    # Valid values: "gateway.envoyproxy.io/h2c", "gateway.envoyproxy.io/ws", "gateway.envoyproxy.io/wss"
    # Do NOT add "http" or "https" - they are INVALID for Envoy Gateway Backend CRD
    if app_protocol:
        valid_protocols = [
            "gateway.envoyproxy.io/h2c",
            "gateway.envoyproxy.io/ws", 
            "gateway.envoyproxy.io/wss",
        ]
        if app_protocol in valid_protocols:
            backend_spec["appProtocols"] = [app_protocol]
        else:
            logger.warning(
                f"Invalid appProtocol '{app_protocol}' ignored. "
                f"Valid values: {valid_protocols}"
            )
    
    # Add Backend TLS configuration if provided (for upstream TLS verification)
    if backend_tls:
        backend_spec["backendTLS"] = backend_tls
    
    # Build annotations
    final_annotations = annotations.copy() if annotations else {}
    if upstream_url:
        final_annotations["envoy-agent.io/upstream-url"] = upstream_url
    if tls_certificate:
        final_annotations["envoy-agent.io/tls-certificate"] = tls_certificate
    
    # Create the Backend CRD
    rm.create_custom_resource(
        kind="Backend",
        name=name,
        spec=backend_spec,
        labels=labels or {},
        annotations=final_annotations,
    )
    
    logger.info(f"Created Backend CRD: {name}")
    
    return backend_spec


def update_backend(
    rm: ResourceManager,
    name: str,
    upstream_url: Optional[str] = None,
    hostname: Optional[str] = None,
    port: Optional[int] = None,
    annotations: Optional[Dict[str, str]] = None,
    tls_certificate: Optional[str] = None,
    app_protocol: Optional[str] = None,
    backend_tls: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """
    Update an existing Envoy Gateway Backend CRD.
    
    Args:
        rm: ResourceManager instance for the target gateway
        name: Backend resource name
        upstream_url: The upstream service URL (optional, alternative to hostname/port)
        hostname: Backend hostname
        port: Backend port
        annotations: Optional annotations to update
        tls_certificate: Optional TLS certificate secret reference
        app_protocol: Optional protocol (ONLY valid: h2c, ws, wss)
        backend_tls: Optional Backend TLS configuration
    
    Returns:
        The updated Backend spec dict
    """
    if upstream_url:
        final_hostname, final_port, _ = parse_upstream_url(upstream_url)
    else:
        final_hostname = hostname or "localhost"
        final_port = port or 80
    
    backend_spec: Dict[str, Any] = {
        "endpoints": [
            {
                "fqdn": {
                    "hostname": final_hostname,
                    "port": final_port,
                }
            }
        ],
    }
    
    # Only add valid appProtocols
    if app_protocol:
        valid_protocols = [
            "gateway.envoyproxy.io/h2c",
            "gateway.envoyproxy.io/ws",
            "gateway.envoyproxy.io/wss",
        ]
        if app_protocol in valid_protocols:
            backend_spec["appProtocols"] = [app_protocol]
    
    if backend_tls:
        backend_spec["backendTLS"] = backend_tls
    
    # Build annotations
    final_annotations = annotations.copy() if annotations else {}
    if upstream_url:
        final_annotations["envoy-agent.io/upstream-url"] = upstream_url
    if tls_certificate:
        final_annotations["envoy-agent.io/tls-certificate"] = tls_certificate
    
    rm.update_custom_resource(
        kind="Backend",
        name=name,
        spec=backend_spec,
        annotations=final_annotations,
    )
    
    logger.info(f"Updated Backend CRD: {name}")
    
    return backend_spec


def backend_exists(rm: ResourceManager, name: str) -> bool:
    """Check if a Backend CRD exists."""
    return rm.resource_exists("Backend", name)


def get_backend(rm: ResourceManager, name: str) -> Optional[Dict[str, Any]]:
    """Get a Backend CRD by name."""
    return rm.get_custom_resource("Backend", name)


def delete_backend(rm: ResourceManager, name: str) -> bool:
    """Delete a Backend CRD."""
    return rm.delete_custom_resource("Backend", name)
