"""
Services for Kubernetes and resource management.
"""

from .k8s_client import K8sClientManager, get_k8s_client
from .resource_manager import ResourceManager
from .backend_service import (
    create_backend,
    update_backend,
    backend_exists,
    get_backend,
    delete_backend,
    parse_upstream_url,
)

__all__ = [
    "K8sClientManager",
    "get_k8s_client",
    "ResourceManager",
    "create_backend",
    "update_backend",
    "backend_exists",
    "get_backend",
    "delete_backend",
    "parse_upstream_url",
]
