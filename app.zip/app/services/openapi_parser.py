"""
OpenAPI specification parser.
Parses OpenAPI 2.0 (Swagger) and OpenAPI 3.x specs to extract routes.
"""

import re
import logging
from typing import Dict, List, Any, Optional, Tuple

logger = logging.getLogger(__name__)


class OpenAPIParser:
    """
    Parser for OpenAPI specifications.
    Supports both OpenAPI 2.0 (Swagger) and OpenAPI 3.x.
    """
    
    HTTP_METHODS = ["get", "post", "put", "patch", "delete", "head", "options"]
    
    def __init__(self, spec: Dict[str, Any]):
        """
        Initialize parser with OpenAPI spec.
        
        Args:
            spec: OpenAPI specification as dictionary
        """
        self.spec = spec
        self.version = self._detect_version()
        self.title = self._get_title()
        self.spec_version = self._get_spec_version()
        self.base_path = self._get_base_path()
    
    def _detect_version(self) -> str:
        """Detect OpenAPI version (2.0 or 3.x)."""
        if "swagger" in self.spec:
            return "2.0"
        elif "openapi" in self.spec:
            version = self.spec["openapi"]
            if version.startswith("3"):
                return "3.x"
        return "unknown"
    
    def _get_title(self) -> Optional[str]:
        """Get API title from spec."""
        info = self.spec.get("info", {})
        return info.get("title")
    
    def _get_spec_version(self) -> Optional[str]:
        """Get API version from spec."""
        info = self.spec.get("info", {})
        return info.get("version")
    
    def _get_base_path(self) -> str:
        """Get base path from spec."""
        if self.version == "2.0":
            return self.spec.get("basePath", "")
        elif self.version == "3.x":
            # OpenAPI 3.x uses servers array
            servers = self.spec.get("servers", [])
            if servers:
                url = servers[0].get("url", "")
                # Extract path from URL
                if url.startswith("http"):
                    # Parse URL to get path
                    from urllib.parse import urlparse
                    parsed = urlparse(url)
                    return parsed.path.rstrip("/")
                return url.rstrip("/")
        return ""
    
    def parse_routes(self, base_path_override: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        Parse all routes from the OpenAPI spec.
        
        Args:
            base_path_override: Optional base path to override spec's base path
            
        Returns:
            List of route dictionaries with path, methods, and metadata
        """
        routes = []
        base = base_path_override if base_path_override is not None else self.base_path
        
        paths = self.spec.get("paths", {})
        
        for path, path_item in paths.items():
            if not isinstance(path_item, dict):
                continue
            
            # Combine base path with endpoint path, avoiding double slashes
            base_normalized = base.rstrip("/") if base else ""
            path_normalized = path if path.startswith("/") else f"/{path}"
            full_path = f"{base_normalized}{path_normalized}".rstrip("/") or "/"
            # Remove any double slashes that might occur
            while "//" in full_path:
                full_path = full_path.replace("//", "/")
            
            # Normalize path parameters from {param} to generic format
            # Envoy uses path prefix matching, so we'll use the path as-is
            normalized_path = self._normalize_path(full_path)
            
            # Collect methods for this path
            methods = []
            operation_info = {}
            
            for method in self.HTTP_METHODS:
                if method in path_item:
                    operation = path_item[method]
                    methods.append(method.upper())
                    
                    # Store operation metadata (use first operation's metadata)
                    if not operation_info:
                        operation_info = {
                            "summary": operation.get("summary"),
                            "description": operation.get("description"),
                            "operation_id": operation.get("operationId"),
                            "tags": operation.get("tags", []),
                        }
            
            if methods:
                route = {
                    "original_path": path,
                    "path": normalized_path,
                    "methods": methods,
                    **operation_info,
                }
                routes.append(route)
        
        return routes
    
    def _normalize_path(self, path: str) -> str:
        """
        Normalize path for Envoy Gateway.
        Converts OpenAPI path parameters to a format suitable for routing.
        
        Gateway API doesn't support {param} style path parameters.
        We truncate at the first path parameter since PathPrefix matching
        will handle the dynamic segments.
        
        Args:
            path: Original path with {param} style parameters
            
        Returns:
            Normalized path without path parameters
        """
        # If path contains path parameters, truncate at the first one
        # /routes/{id} -> /routes
        # /routes/{route}/contracts -> /routes
        if "{" in path:
            # Find the position of the first path parameter
            segments = path.split("/")
            normalized_segments = []
            for segment in segments:
                if "{" in segment:
                    # Stop at the first path parameter
                    break
                normalized_segments.append(segment)
            
            # Reconstruct path
            normalized = "/".join(normalized_segments)
            # Ensure path starts with / and doesn't end with /
            if not normalized.startswith("/"):
                normalized = "/" + normalized
            normalized = normalized.rstrip("/") or "/"
            return normalized
        
        return path
    
    def generate_route_name(self, path: str, methods: List[str], prefix: Optional[str] = None) -> str:
        """
        Generate a valid Kubernetes resource name from path and methods.
        
        Args:
            path: Route path
            methods: HTTP methods
            prefix: Optional prefix for the name
            
        Returns:
            Valid Kubernetes resource name
        """
        # Convert path to name-friendly format
        name = path.strip("/").replace("/", "-").replace("{", "").replace("}", "")
        name = re.sub(r"[^a-z0-9-]", "-", name.lower())
        name = re.sub(r"-+", "-", name)  # Remove consecutive dashes
        name = name.strip("-")
        
        # If path is root, use "root"
        if not name:
            name = "root"
        
        # Add method suffix if single method
        if len(methods) == 1:
            name = f"{name}-{methods[0].lower()}"
        
        # Add prefix if provided
        if prefix:
            name = f"{prefix}-{name}"
        
        # Ensure name is valid (max 63 chars, starts/ends with alphanumeric)
        name = name[:63].strip("-")
        if not name[0].isalnum():
            name = f"r-{name}"
        
        return name
    
    def get_unique_paths(self) -> List[str]:
        """Get list of unique paths from the spec."""
        return list(self.spec.get("paths", {}).keys())
    
    def get_tags(self) -> List[str]:
        """Get all tags defined in the spec."""
        tags = self.spec.get("tags", [])
        return [tag.get("name") for tag in tags if tag.get("name")]
    
    def get_info(self) -> Dict[str, Any]:
        """Get spec info section."""
        return {
            "title": self.title,
            "version": self.spec_version,
            "openapi_version": self.version,
            "base_path": self.base_path,
            "description": self.spec.get("info", {}).get("description"),
        }


def parse_openapi_spec(spec: Dict[str, Any], base_path: Optional[str] = None) -> Tuple[Dict[str, Any], List[Dict[str, Any]]]:
    """
    Convenience function to parse an OpenAPI spec.
    
    Args:
        spec: OpenAPI specification dictionary
        base_path: Optional base path override
        
    Returns:
        Tuple of (spec_info, routes)
    """
    parser = OpenAPIParser(spec)
    info = parser.get_info()
    routes = parser.parse_routes(base_path)
    return info, routes
