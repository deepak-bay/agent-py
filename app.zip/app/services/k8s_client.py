"""
Kubernetes client manager with EKS authentication and token refresh.
Supports multiple clusters/gateways.
"""

import base64
import subprocess
import json
import logging
import time
from typing import Optional, Tuple, Dict
from kubernetes import client
from kubernetes.client.rest import ApiException
import boto3
from functools import lru_cache

from ..config import get_settings, Settings, get_gateway_config, GatewayConfig

logger = logging.getLogger(__name__)


class K8sClientManager:
    """
    Manages Kubernetes API clients with automatic EKS token refresh.
    
    EKS tokens expire after 15 minutes, so this class handles automatic
    token refresh to maintain connectivity.
    """
    
    def __init__(self, settings: Optional[Settings] = None, gateway_config: Optional[GatewayConfig] = None):
        self.settings = settings or get_settings()
        self.gateway_config = gateway_config
        self._api_client: Optional[client.ApiClient] = None
        self._custom_api: Optional[client.CustomObjectsApi] = None
        self._core_api: Optional[client.CoreV1Api] = None
        self._token_expiry: float = 0
        self._cluster_endpoint: Optional[str] = None
        self._cluster_ca: Optional[bytes] = None
        
    @property
    def aws_region(self) -> str:
        """Get the AWS region to use."""
        if self.gateway_config:
            return self.gateway_config.aws_region
        return self.settings.aws_region
    
    @property
    def eks_cluster_name(self) -> str:
        """Get the EKS cluster name to use."""
        if self.gateway_config:
            return self.gateway_config.eks_cluster_name
        return self.settings.eks_cluster_name
    
    @property
    def namespace(self) -> str:
        """Get the Kubernetes namespace to use."""
        if self.gateway_config:
            return self.gateway_config.k8s_namespace
        return self.settings.k8s_namespace
    
    @property
    def gateway_name(self) -> str:
        """Get the gateway name to use."""
        if self.gateway_config:
            return self.gateway_config.gateway_name
        return self.settings.default_gateway_name
        
    def _get_eks_cluster_info(self) -> Tuple[str, bytes]:
        """Get EKS cluster endpoint and CA certificate."""
        if self._cluster_endpoint and self._cluster_ca:
            return self._cluster_endpoint, self._cluster_ca
            
        eks = boto3.client("eks", region_name=self.aws_region)
        cluster = eks.describe_cluster(name=self.eks_cluster_name)["cluster"]
        
        self._cluster_endpoint = cluster["endpoint"]
        self._cluster_ca = base64.b64decode(cluster["certificateAuthority"]["data"])
        
        return self._cluster_endpoint, self._cluster_ca
    
    def _get_eks_token(self) -> str:
        """Get a fresh EKS authentication token using AWS CLI."""
        cmd = [
            "aws", "eks", "get-token",
            "--cluster-name", self.eks_cluster_name,
            "--region", self.aws_region
        ]
        try:
            output = subprocess.check_output(cmd, stderr=subprocess.PIPE)
            token_data = json.loads(output)
            return token_data["status"]["token"]
        except subprocess.CalledProcessError as e:
            logger.error(f"Failed to get EKS token: {e.stderr.decode()}")
            raise RuntimeError(f"Failed to get EKS token: {e.stderr.decode()}")
        except json.JSONDecodeError as e:
            logger.error(f"Failed to parse EKS token response: {e}")
            raise RuntimeError(f"Failed to parse EKS token response: {e}")
    
    def _is_token_expired(self) -> bool:
        """Check if the current token is expired or about to expire."""
        # Refresh 60 seconds before actual expiry
        return time.time() >= (self._token_expiry - 60)
    
    def _get_ca_cert_path(self) -> str:
        """Get unique CA cert path for this cluster."""
        return f"/tmp/eks-ca-{self.eks_cluster_name}-{self.aws_region}.crt"
    
    def _create_api_client(self) -> client.ApiClient:
        """Create a new Kubernetes API client with fresh credentials."""
        endpoint, ca_data = self._get_eks_cluster_info()
        token = self._get_eks_token()
        
        # Write CA certificate to file (unique per cluster)
        ca_path = self._get_ca_cert_path()
        with open(ca_path, "wb") as f:
            f.write(ca_data)
        
        # Configure Kubernetes client
        cfg = client.Configuration()
        cfg.host = endpoint
        cfg.api_key["authorization"] = token
        cfg.api_key_prefix["authorization"] = "Bearer"
        cfg.verify_ssl = True
        cfg.ssl_ca_cert = ca_path
        
        # Set token expiry (EKS tokens valid for 15 minutes)
        self._token_expiry = time.time() + self.settings.token_refresh_seconds
        
        self._api_client = client.ApiClient(cfg)
        logger.info(f"Created K8s client for cluster {self.eks_cluster_name} in {self.aws_region}")
        
        return self._api_client
    
    def _ensure_client(self) -> client.ApiClient:
        """Ensure we have a valid API client, refreshing if needed."""
        if self._api_client is None or self._is_token_expired():
            self._create_api_client()
            # Reset cached API instances
            self._custom_api = None
            self._core_api = None
        return self._api_client
    
    def get_custom_objects_api(self) -> client.CustomObjectsApi:
        """Get CustomObjectsApi for CRD operations."""
        self._ensure_client()
        if self._custom_api is None:
            self._custom_api = client.CustomObjectsApi(self._api_client)
        return self._custom_api
    
    def get_core_v1_api(self) -> client.CoreV1Api:
        """Get CoreV1Api for core Kubernetes resources."""
        self._ensure_client()
        if self._core_api is None:
            self._core_api = client.CoreV1Api(self._api_client)
        return self._core_api
    
    def get_apps_v1_api(self) -> client.AppsV1Api:
        """Get AppsV1Api for deployments, etc."""
        self._ensure_client()
        return client.AppsV1Api(self._api_client)
    
    def get_networking_v1_api(self) -> client.NetworkingV1Api:
        """Get NetworkingV1Api for ingress, etc."""
        self._ensure_client()
        return client.NetworkingV1Api(self._api_client)
    
    def health_check(self) -> bool:
        """Check if we can connect to the Kubernetes cluster."""
        try:
            api = self.get_core_v1_api()
            api.get_api_resources()
            return True
        except Exception as e:
            logger.error(f"Kubernetes health check failed: {e}")
            return False
    
    def get_cluster_info(self) -> dict:
        """Get cluster information."""
        try:
            endpoint, _ = self._get_eks_cluster_info()
            return {
                "cluster_name": self.eks_cluster_name,
                "endpoint": endpoint,
                "region": self.aws_region,
                "namespace": self.namespace,
                "gateway_name": self.gateway_name,
            }
        except Exception as e:
            logger.error(f"Failed to get cluster info: {e}")
            return {"error": str(e)}


# Cache for K8s client managers per gateway
_k8s_client_cache: Dict[str, K8sClientManager] = {}


def get_k8s_client(target_gateway: Optional[str] = None) -> K8sClientManager:
    """
    Get a K8s client manager for the specified target gateway.
    
    Args:
        target_gateway: Gateway identifier (e.g., 'us-envoy-1', 'eu-envoy-1').
                       If None, uses default settings.
    
    Returns:
        K8sClientManager configured for the target gateway/cluster
    """
    global _k8s_client_cache
    
    cache_key = target_gateway or "default"
    
    if cache_key not in _k8s_client_cache:
        if target_gateway:
            gateway_config = get_gateway_config(target_gateway)
            _k8s_client_cache[cache_key] = K8sClientManager(gateway_config=gateway_config)
        else:
            _k8s_client_cache[cache_key] = K8sClientManager()
    
    return _k8s_client_cache[cache_key]


def reset_k8s_client(target_gateway: Optional[str] = None):
    """Reset the K8s client cache (useful for testing)."""
    global _k8s_client_cache
    if target_gateway:
        cache_key = target_gateway
        if cache_key in _k8s_client_cache:
            del _k8s_client_cache[cache_key]
    else:
        _k8s_client_cache = {}
