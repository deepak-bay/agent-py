"""
Resource manager for Kubernetes and Envoy Gateway resources.
Supports multiple clusters/gateways.
"""

import logging
from typing import Optional, Dict, Any, List
from kubernetes.client.rest import ApiException

from .k8s_client import K8sClientManager, get_k8s_client
from ..config import get_settings, get_gateway_config, GatewayConfig

logger = logging.getLogger(__name__)


class ResourceManager:
    """
    Manages Kubernetes and Envoy Gateway resources.
    
    Provides high-level operations for creating, updating, deleting,
    and querying Gateway API and Envoy Gateway resources.
    
    Supports multi-cluster operations via target_gateway parameter.
    """
    
    # API Group and Version mappings
    GATEWAY_API_GROUP = "gateway.networking.k8s.io"
    GATEWAY_API_VERSION = "v1"
    
    ENVOY_API_GROUP = "gateway.envoyproxy.io"
    ENVOY_API_VERSION = "v1alpha1"
    
    # Resource plurals
    RESOURCE_PLURALS = {
        "Gateway": "gateways",
        "GatewayClass": "gatewayclasses",
        "HTTPRoute": "httproutes",
        "GRPCRoute": "grpcroutes",
        "TLSRoute": "tlsroutes",
        "TCPRoute": "tcproutes",
        "UDPRoute": "udproutes",
        "ReferenceGrant": "referencegrants",
        "Backend": "backends",
        "BackendTrafficPolicy": "backendtrafficpolicies",
        "SecurityPolicy": "securitypolicies",
        "ClientTrafficPolicy": "clienttrafficpolicies",
        "EnvoyPatchPolicy": "envoypatchpolicies",
        "EnvoyExtensionPolicy": "envoyextensionpolicies",
        "EnvoyProxy": "envoyproxies",
    }
    
    def __init__(self, target_gateway: Optional[str] = None, k8s_client: Optional[K8sClientManager] = None):
        """
        Initialize ResourceManager.
        
        Args:
            target_gateway: Gateway identifier (e.g., 'us-envoy-1', 'eu-envoy-1').
                           Determines which cluster to connect to.
            k8s_client: Optional pre-configured K8s client.
        """
        self.target_gateway = target_gateway
        
        if k8s_client:
            self.k8s = k8s_client
        else:
            self.k8s = get_k8s_client(target_gateway)
        
        self.settings = get_settings()
        
        # Use namespace from gateway config if target_gateway specified
        if target_gateway:
            gateway_config = get_gateway_config(target_gateway)
            self.namespace = gateway_config.k8s_namespace
            self.gateway_name = gateway_config.gateway_name
        else:
            self.namespace = self.settings.k8s_namespace
            self.gateway_name = self.settings.default_gateway_name
    
    def get_cluster_info(self) -> Dict[str, Any]:
        """Get information about the target cluster."""
        return self.k8s.get_cluster_info()
    
    def _get_api_info(self, kind: str) -> tuple[str, str, str]:
        """Get API group, version, and plural for a resource kind."""
        plural = self.RESOURCE_PLURALS.get(kind)
        if not plural:
            raise ValueError(f"Unknown resource kind: {kind}")
        
        # Gateway API resources
        if kind in ["Gateway", "GatewayClass", "HTTPRoute", "GRPCRoute", 
                    "TLSRoute", "TCPRoute", "UDPRoute", "ReferenceGrant"]:
            return self.GATEWAY_API_GROUP, self.GATEWAY_API_VERSION, plural
        
        # Envoy Gateway resources (including EnvoyProxy for logging)
        return self.ENVOY_API_GROUP, self.ENVOY_API_VERSION, plural
    
    # ==================== Generic CRUD Operations ====================
    
    def create_custom_resource(
        self,
        kind: str,
        name: str,
        spec: Dict[str, Any],
        namespace: Optional[str] = None,
        labels: Optional[Dict[str, str]] = None,
        annotations: Optional[Dict[str, str]] = None,
    ) -> Dict[str, Any]:
        """Create a custom resource."""
        ns = namespace or self.namespace
        group, version, plural = self._get_api_info(kind)
        
        body = {
            "apiVersion": f"{group}/{version}",
            "kind": kind,
            "metadata": {
                "name": name,
                "namespace": ns,
                "labels": labels or {},
                "annotations": annotations or {},
            },
            "spec": spec,
        }
        
        api = self.k8s.get_custom_objects_api()
        
        # GatewayClass is cluster-scoped
        if kind == "GatewayClass":
            return api.create_cluster_custom_object(group, version, plural, body)
        
        return api.create_namespaced_custom_object(group, version, ns, plural, body)
    
    def get_custom_resource(
        self,
        kind: str,
        name: str,
        namespace: Optional[str] = None,
    ) -> Optional[Dict[str, Any]]:
        """Get a custom resource by name."""
        ns = namespace or self.namespace
        group, version, plural = self._get_api_info(kind)
        api = self.k8s.get_custom_objects_api()
        
        try:
            if kind == "GatewayClass":
                return api.get_cluster_custom_object(group, version, plural, name)
            return api.get_namespaced_custom_object(group, version, ns, plural, name)
        except ApiException as e:
            if e.status == 404:
                return None
            raise
    
    def list_custom_resources(
        self,
        kind: str,
        namespace: Optional[str] = None,
        label_selector: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """List custom resources."""
        ns = namespace or self.namespace
        group, version, plural = self._get_api_info(kind)
        api = self.k8s.get_custom_objects_api()
        
        kwargs = {}
        if label_selector:
            kwargs["label_selector"] = label_selector
        
        if kind == "GatewayClass":
            result = api.list_cluster_custom_object(group, version, plural, **kwargs)
        else:
            result = api.list_namespaced_custom_object(group, version, ns, plural, **kwargs)
        
        return result.get("items", [])
    
    def update_custom_resource(
        self,
        kind: str,
        name: str,
        spec: Dict[str, Any],
        namespace: Optional[str] = None,
        labels: Optional[Dict[str, str]] = None,
        annotations: Optional[Dict[str, str]] = None,
    ) -> Dict[str, Any]:
        """Update a custom resource (patch). Optionally patches labels/annotations too."""
        ns = namespace or self.namespace
        group, version, plural = self._get_api_info(kind)
        api = self.k8s.get_custom_objects_api()
        
        patch_body = {"spec": spec}
        
        if labels is not None or annotations is not None:
            metadata = {}
            if labels is not None:
                metadata["labels"] = labels
            if annotations is not None:
                metadata["annotations"] = annotations
            patch_body["metadata"] = metadata
        
        if kind == "GatewayClass":
            return api.patch_cluster_custom_object(group, version, plural, name, patch_body)
        
        return api.patch_namespaced_custom_object(group, version, ns, plural, name, patch_body)
    
    def delete_custom_resource(
        self,
        kind: str,
        name: str,
        namespace: Optional[str] = None,
    ) -> bool:
        """Delete a custom resource."""
        ns = namespace or self.namespace
        group, version, plural = self._get_api_info(kind)
        api = self.k8s.get_custom_objects_api()
        
        try:
            if kind == "GatewayClass":
                api.delete_cluster_custom_object(group, version, plural, name)
            else:
                api.delete_namespaced_custom_object(group, version, ns, plural, name)
            return True
        except ApiException as e:
            if e.status == 404:
                return False
            raise
    
    def resource_exists(
        self,
        kind: str,
        name: str,
        namespace: Optional[str] = None,
    ) -> bool:
        """Check if a resource exists."""
        return self.get_custom_resource(kind, name, namespace) is not None
    
    # ==================== Service Operations ====================
    
    def create_service(
        self,
        name: str,
        spec: Dict[str, Any],
        namespace: Optional[str] = None,
        labels: Optional[Dict[str, str]] = None,
        annotations: Optional[Dict[str, str]] = None,
    ) -> Dict[str, Any]:
        """Create a Kubernetes Service."""
        from kubernetes import client as k8s_client
        
        ns = namespace or self.namespace
        api = self.k8s.get_core_v1_api()
        
        # Build service object
        metadata = k8s_client.V1ObjectMeta(
            name=name,
            namespace=ns,
            labels=labels or {},
            annotations=annotations or None,
        )
        
        ports = []
        for port_spec in spec.get("ports", []):
            port = k8s_client.V1ServicePort(
                name=port_spec.get("name"),
                port=port_spec["port"],
                target_port=port_spec.get("targetPort", port_spec["port"]),
                protocol=port_spec.get("protocol", "TCP"),
                app_protocol=port_spec.get("appProtocol"),
            )
            ports.append(port)
        
        service_spec = k8s_client.V1ServiceSpec(
            type=spec.get("type", "ClusterIP"),
            ports=ports,
            selector=spec.get("selector"),
            external_name=spec.get("externalName"),
            cluster_ip=spec.get("clusterIP"),
        )
        
        service = k8s_client.V1Service(
            api_version="v1",
            kind="Service",
            metadata=metadata,
            spec=service_spec,
        )
        
        result = api.create_namespaced_service(namespace=ns, body=service)
        return result.to_dict()
    
    def get_service(
        self,
        name: str,
        namespace: Optional[str] = None,
    ) -> Optional[Dict[str, Any]]:
        """Get a Service by name."""
        ns = namespace or self.namespace
        api = self.k8s.get_core_v1_api()
        
        try:
            result = api.read_namespaced_service(name=name, namespace=ns)
            return result.to_dict()
        except ApiException as e:
            if e.status == 404:
                return None
            raise
    
    def list_services(
        self,
        namespace: Optional[str] = None,
        label_selector: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """List Services."""
        ns = namespace or self.namespace
        api = self.k8s.get_core_v1_api()
        
        kwargs = {}
        if label_selector:
            kwargs["label_selector"] = label_selector
        
        result = api.list_namespaced_service(namespace=ns, **kwargs)
        return [item.to_dict() for item in result.items]
    
    def update_service(
        self,
        name: str,
        spec: Dict[str, Any],
        namespace: Optional[str] = None,
        annotations: Optional[Dict[str, str]] = None,
    ) -> Dict[str, Any]:
        """Update a Service."""
        from kubernetes import client as k8s_client
        
        ns = namespace or self.namespace
        api = self.k8s.get_core_v1_api()
        
        # Build patch body
        ports = []
        for port_spec in spec.get("ports", []):
            port = k8s_client.V1ServicePort(
                name=port_spec.get("name"),
                port=port_spec["port"],
                target_port=port_spec.get("targetPort", port_spec["port"]),
                protocol=port_spec.get("protocol", "TCP"),
            )
            ports.append(port)
        
        metadata = None
        if annotations is not None:
            metadata = k8s_client.V1ObjectMeta(annotations=annotations)
        
        patch_body = k8s_client.V1Service(
            metadata=metadata,
            spec=k8s_client.V1ServiceSpec(
                type=spec.get("type"),
                ports=ports if ports else None,
                selector=spec.get("selector"),
                external_name=spec.get("externalName"),
            )
        )
        
        result = api.patch_namespaced_service(name=name, namespace=ns, body=patch_body)
        return result.to_dict()
    
    def delete_service(
        self,
        name: str,
        namespace: Optional[str] = None,
    ) -> bool:
        """Delete a Service."""
        ns = namespace or self.namespace
        api = self.k8s.get_core_v1_api()
        
        try:
            api.delete_namespaced_service(name=name, namespace=ns)
            return True
        except ApiException as e:
            if e.status == 404:
                return False
            raise
    
    def service_exists(
        self,
        name: str,
        namespace: Optional[str] = None,
    ) -> bool:
        """Check if a service exists."""
        return self.get_service(name, namespace) is not None
    
    # ==================== Secret Operations ====================
    
    def create_secret(
        self,
        name: str,
        data: Dict[str, str],
        secret_type: str = "Opaque",
        namespace: Optional[str] = None,
        labels: Optional[Dict[str, str]] = None,
    ) -> Dict[str, Any]:
        """Create a Kubernetes Secret."""
        from kubernetes import client as k8s_client
        import base64
        
        ns = namespace or self.namespace
        api = self.k8s.get_core_v1_api()
        
        # Encode data to base64
        encoded_data = {k: base64.b64encode(v.encode()).decode() for k, v in data.items()}
        
        secret = k8s_client.V1Secret(
            api_version="v1",
            kind="Secret",
            metadata=k8s_client.V1ObjectMeta(
                name=name,
                namespace=ns,
                labels=labels or {},
            ),
            type=secret_type,
            data=encoded_data,
        )
        
        result = api.create_namespaced_secret(namespace=ns, body=secret)
        # Return without data for security
        result_dict = result.to_dict()
        result_dict.pop("data", None)
        return result_dict
    
    def get_secret(
        self,
        name: str,
        namespace: Optional[str] = None,
        include_data: bool = False,
    ) -> Optional[Dict[str, Any]]:
        """Get a Secret by name."""
        ns = namespace or self.namespace
        api = self.k8s.get_core_v1_api()
        
        try:
            result = api.read_namespaced_secret(name=name, namespace=ns)
            result_dict = result.to_dict()
            if not include_data:
                result_dict.pop("data", None)
            return result_dict
        except ApiException as e:
            if e.status == 404:
                return None
            raise
    
    def list_secrets(
        self,
        namespace: Optional[str] = None,
        label_selector: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """List Secrets (without data)."""
        ns = namespace or self.namespace
        api = self.k8s.get_core_v1_api()
        
        kwargs = {}
        if label_selector:
            kwargs["label_selector"] = label_selector
        
        result = api.list_namespaced_secret(namespace=ns, **kwargs)
        items = []
        for item in result.items:
            item_dict = item.to_dict()
            item_dict.pop("data", None)  # Remove data for security
            items.append(item_dict)
        return items
    
    def delete_secret(
        self,
        name: str,
        namespace: Optional[str] = None,
    ) -> bool:
        """Delete a Secret."""
        ns = namespace or self.namespace
        api = self.k8s.get_core_v1_api()
        
        try:
            api.delete_namespaced_secret(name=name, namespace=ns)
            return True
        except ApiException as e:
            if e.status == 404:
                return False
            raise
    
    # ==================== ConfigMap Operations ====================
    
    def create_configmap(
        self,
        name: str,
        data: Dict[str, str],
        namespace: Optional[str] = None,
        labels: Optional[Dict[str, str]] = None,
        annotations: Optional[Dict[str, str]] = None,
    ) -> Dict[str, Any]:
        """Create a Kubernetes ConfigMap.
        
        Args:
            name: ConfigMap name
            data: Key-value data (e.g., {'ca.crt': '-----BEGIN CERTIFICATE-----...'})
            namespace: Kubernetes namespace
            labels: Optional labels
            annotations: Optional annotations
            
        Returns:
            Created ConfigMap details
        """
        from kubernetes import client as k8s_client
        
        ns = namespace or self.namespace
        api = self.k8s.get_core_v1_api()
        
        configmap = k8s_client.V1ConfigMap(
            api_version="v1",
            kind="ConfigMap",
            metadata=k8s_client.V1ObjectMeta(
                name=name,
                namespace=ns,
                labels=labels or {},
                annotations=annotations or {},
            ),
            data=data,
        )
        
        result = api.create_namespaced_config_map(namespace=ns, body=configmap)
        return result.to_dict()
    
    def create_configmap_from_files(
        self,
        name: str,
        file_paths: Dict[str, str],
        namespace: Optional[str] = None,
        labels: Optional[Dict[str, str]] = None,
        annotations: Optional[Dict[str, str]] = None,
    ) -> Dict[str, Any]:
        """Create a ConfigMap from file paths.
        
        Args:
            name: ConfigMap name
            file_paths: Map of key names to file paths (e.g., {'ca.crt': '/path/to/ca.crt'})
            namespace: Kubernetes namespace
            labels: Optional labels
            annotations: Optional annotations
            
        Returns:
            Created ConfigMap details
        """
        data = {}
        for key, path in file_paths.items():
            with open(path, 'r') as f:
                data[key] = f.read()
        
        return self.create_configmap(
            name=name,
            data=data,
            namespace=namespace,
            labels=labels,
            annotations=annotations,
        )
    
    def get_configmap(
        self,
        name: str,
        namespace: Optional[str] = None,
    ) -> Optional[Dict[str, Any]]:
        """Get a ConfigMap by name."""
        ns = namespace or self.namespace
        api = self.k8s.get_core_v1_api()
        
        try:
            result = api.read_namespaced_config_map(name=name, namespace=ns)
            return result.to_dict()
        except ApiException as e:
            if e.status == 404:
                return None
            raise
    
    def list_configmaps(
        self,
        namespace: Optional[str] = None,
        label_selector: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """List ConfigMaps."""
        ns = namespace or self.namespace
        api = self.k8s.get_core_v1_api()
        
        kwargs = {}
        if label_selector:
            kwargs["label_selector"] = label_selector
        
        result = api.list_namespaced_config_map(namespace=ns, **kwargs)
        return [item.to_dict() for item in result.items]
    
    def update_configmap(
        self,
        name: str,
        data: Dict[str, str],
        namespace: Optional[str] = None,
        labels: Optional[Dict[str, str]] = None,
        annotations: Optional[Dict[str, str]] = None,
    ) -> Dict[str, Any]:
        """Update a ConfigMap."""
        from kubernetes import client as k8s_client
        
        ns = namespace or self.namespace
        api = self.k8s.get_core_v1_api()
        
        metadata = k8s_client.V1ObjectMeta()
        if labels is not None:
            metadata.labels = labels
        if annotations is not None:
            metadata.annotations = annotations
        
        patch_body = k8s_client.V1ConfigMap(
            metadata=metadata,
            data=data,
        )
        
        result = api.patch_namespaced_config_map(name=name, namespace=ns, body=patch_body)
        return result.to_dict()
    
    def delete_configmap(
        self,
        name: str,
        namespace: Optional[str] = None,
    ) -> bool:
        """Delete a ConfigMap."""
        ns = namespace or self.namespace
        api = self.k8s.get_core_v1_api()
        
        try:
            api.delete_namespaced_config_map(name=name, namespace=ns)
            return True
        except ApiException as e:
            if e.status == 404:
                return False
            raise
    
    def configmap_exists(
        self,
        name: str,
        namespace: Optional[str] = None,
    ) -> bool:
        """Check if a ConfigMap exists."""
        return self.get_configmap(name, namespace) is not None
    
    def create_tls_secret(
        self,
        name: str,
        tls_crt: str,
        tls_key: str,
        ca_crt: Optional[str] = None,
        namespace: Optional[str] = None,
        labels: Optional[Dict[str, str]] = None,
    ) -> Dict[str, Any]:
        """Create a TLS Secret for mTLS client certificates.
        
        Args:
            name: Secret name
            tls_crt: TLS certificate content (PEM)
            tls_key: TLS private key content (PEM)
            ca_crt: Optional CA certificate content (PEM)
            namespace: Kubernetes namespace
            labels: Optional labels
            
        Returns:
            Created Secret details (without data)
        """
        data = {
            "tls.crt": tls_crt,
            "tls.key": tls_key,
        }
        if ca_crt:
            data["ca.crt"] = ca_crt
        
        return self.create_secret(
            name=name,
            data=data,
            secret_type="kubernetes.io/tls",
            namespace=namespace,
            labels=labels,
        )
    
    def create_tls_secret_from_files(
        self,
        name: str,
        tls_crt_path: str,
        tls_key_path: str,
        ca_crt_path: Optional[str] = None,
        namespace: Optional[str] = None,
        labels: Optional[Dict[str, str]] = None,
    ) -> Dict[str, Any]:
        """Create a TLS Secret from file paths.
        
        Args:
            name: Secret name
            tls_crt_path: Path to tls.crt file
            tls_key_path: Path to tls.key file
            ca_crt_path: Optional path to ca.crt file
            namespace: Kubernetes namespace
            labels: Optional labels
            
        Returns:
            Created Secret details (without data)
        """
        with open(tls_crt_path, 'r') as f:
            tls_crt = f.read()
        with open(tls_key_path, 'r') as f:
            tls_key = f.read()
        
        ca_crt = None
        if ca_crt_path:
            with open(ca_crt_path, 'r') as f:
                ca_crt = f.read()
        
        return self.create_tls_secret(
            name=name,
            tls_crt=tls_crt,
            tls_key=tls_key,
            ca_crt=ca_crt,
            namespace=namespace,
            labels=labels,
        )
    
    # ==================== Helper Methods ====================
    
    def create_external_name_service(
        self,
        name: str,
        external_name: str,
        port: int = 80,
        namespace: Optional[str] = None,
        app_protocol: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Create an ExternalName service pointing to an external hostname."""
        port_spec = {"port": port, "targetPort": port}
        if app_protocol:
            port_spec["appProtocol"] = app_protocol
        
        spec = {
            "type": "ExternalName",
            "externalName": external_name,
            "ports": [port_spec],
        }
        return self.create_service(name, spec, namespace)
    
    def create_backend_for_route(
        self,
        name: str,
        backend_url: str,
        port: int,
        use_tls: bool = False,
        namespace: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Create a backend service for a route.
        
        Args:
            name: Backend service name
            backend_url: Backend hostname/FQDN
            port: Backend port
            use_tls: Whether backend uses TLS (sets appProtocol to https)
            namespace: Kubernetes namespace
            
        Returns:
            Created service details
        """
        app_protocol = "https" if use_tls else "http"
        return self.create_external_name_service(
            name=name,
            external_name=backend_url,
            port=port,
            namespace=namespace,
            app_protocol=app_protocol,
        )
    
    def get_gateway_status(
        self,
        name: str,
        namespace: Optional[str] = None,
    ) -> Optional[Dict[str, Any]]:
        """Get Gateway status including addresses and conditions."""
        gateway = self.get_custom_resource("Gateway", name, namespace)
        if gateway:
            return gateway.get("status")
        return None
    
    def get_route_status(
        self,
        kind: str,
        name: str,
        namespace: Optional[str] = None,
    ) -> Optional[Dict[str, Any]]:
        """Get route status including parent status."""
        route = self.get_custom_resource(kind, name, namespace)
        if route:
            return route.get("status")
        return None
