"""
Helper functions for the Envoy Gateway Agent API.
"""

from urllib.parse import urlparse
from typing import Optional, Dict, Any
import re


def extract_hostname(url: str) -> str:
    """Extract hostname from a URL."""
    parsed = urlparse(str(url))
    return parsed.hostname or url


def extract_port(url: str, default_port: int = 80) -> int:
    """Extract port from a URL, with smart defaults for scheme."""
    parsed = urlparse(str(url))
    if parsed.port:
        return parsed.port
    if parsed.scheme == "https":
        return 443
    return default_port


def extract_scheme(url: str) -> str:
    """Extract scheme from a URL."""
    parsed = urlparse(str(url))
    return parsed.scheme or "http"


def is_valid_k8s_name(name: str) -> bool:
    """
    Check if a name is valid for Kubernetes resources.
    Must be lowercase alphanumeric with dashes, max 253 chars.
    """
    if not name or len(name) > 253:
        return False
    pattern = r'^[a-z0-9]([-a-z0-9]*[a-z0-9])?$'
    return bool(re.match(pattern, name))


def sanitize_k8s_name(name: str) -> str:
    """
    Sanitize a string to be a valid Kubernetes resource name.
    """
    # Convert to lowercase
    name = name.lower()
    # Replace underscores and spaces with dashes
    name = re.sub(r'[_\s]+', '-', name)
    # Remove any character that's not alphanumeric or dash
    name = re.sub(r'[^a-z0-9-]', '', name)
    # Remove leading/trailing dashes
    name = name.strip('-')
    # Collapse multiple dashes
    name = re.sub(r'-+', '-', name)
    # Truncate to 253 characters
    return name[:253]


def build_target_ref(
    kind: str,
    name: str,
    group: str = "gateway.networking.k8s.io",
    namespace: Optional[str] = None,
    section_name: Optional[str] = None,
) -> Dict[str, Any]:
    """Build a targetRef object for policies."""
    ref = {
        "group": group,
        "kind": kind,
        "name": name,
    }
    if namespace:
        ref["namespace"] = namespace
    if section_name:
        ref["sectionName"] = section_name
    return ref


def build_backend_ref(
    name: str,
    port: int,
    group: str = "",
    kind: str = "Service",
    namespace: Optional[str] = None,
    weight: int = 1,
) -> Dict[str, Any]:
    """Build a backendRef object for routes."""
    ref = {
        "group": group,
        "kind": kind,
        "name": name,
        "port": port,
        "weight": weight,
    }
    if namespace:
        ref["namespace"] = namespace
    return ref


def build_parent_ref(
    name: str,
    group: str = "gateway.networking.k8s.io",
    kind: str = "Gateway",
    namespace: Optional[str] = None,
    section_name: Optional[str] = None,
    port: Optional[int] = None,
) -> Dict[str, Any]:
    """Build a parentRef object for routes."""
    ref = {
        "group": group,
        "kind": kind,
        "name": name,
    }
    if namespace:
        ref["namespace"] = namespace
    if section_name:
        ref["sectionName"] = section_name
    if port:
        ref["port"] = port
    return ref


def parse_duration(duration: str) -> Optional[int]:
    """
    Parse a duration string (e.g., '30s', '5m', '1h') to seconds.
    Returns None if parsing fails.
    """
    if not duration:
        return None
    
    pattern = r'^(\d+)(s|m|h|d)$'
    match = re.match(pattern, duration.lower())
    if not match:
        return None
    
    value = int(match.group(1))
    unit = match.group(2)
    
    multipliers = {'s': 1, 'm': 60, 'h': 3600, 'd': 86400}
    return value * multipliers[unit]


def format_duration(seconds: int) -> str:
    """Format seconds as a duration string."""
    if seconds >= 86400 and seconds % 86400 == 0:
        return f"{seconds // 86400}d"
    if seconds >= 3600 and seconds % 3600 == 0:
        return f"{seconds // 3600}h"
    if seconds >= 60 and seconds % 60 == 0:
        return f"{seconds // 60}m"
    return f"{seconds}s"


def merge_dicts(base: Dict[str, Any], override: Dict[str, Any]) -> Dict[str, Any]:
    """
    Deep merge two dictionaries.
    Values from override take precedence.
    """
    result = base.copy()
    for key, value in override.items():
        if key in result and isinstance(result[key], dict) and isinstance(value, dict):
            result[key] = merge_dicts(result[key], value)
        else:
            result[key] = value
    return result


def filter_none_values(d: Dict[str, Any]) -> Dict[str, Any]:
    """Remove None values from a dictionary recursively."""
    result = {}
    for key, value in d.items():
        if value is None:
            continue
        if isinstance(value, dict):
            filtered = filter_none_values(value)
            if filtered:  # Only add non-empty dicts
                result[key] = filtered
        elif isinstance(value, list):
            filtered_list = []
            for item in value:
                if isinstance(item, dict):
                    filtered_item = filter_none_values(item)
                    if filtered_item:
                        filtered_list.append(filtered_item)
                elif item is not None:
                    filtered_list.append(item)
            if filtered_list:
                result[key] = filtered_list
        else:
            result[key] = value
    return result
