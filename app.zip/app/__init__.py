"""
Envoy Gateway Agent API
A comprehensive API for managing Envoy Gateway resources on Kubernetes.
"""

__version__ = "1.0.0"
__author__ = "GKNQT (Ajay Vunnam)"
