"""
Production environment configuration.
Used for production deployments.

Set ENVOY_AGENT_ENV=prod to use this configuration.
"""

from typing import Dict
from .base import Settings, GatewayConfig


class ProdSettings(Settings):
    """Production environment settings."""
    
    env: str = "prod"
    debug: bool = False
    log_level: str = "WARNING"
    
    # Longer token refresh for production stability
    token_refresh_seconds: int = 600
    
    # Feature Flags - conservative for production
    enable_metrics: bool = True
    enable_tracing: bool = False  # Enable only if needed


# Production gateway configurations
# These point to production clusters
GATEWAY_CONFIGS: Dict[str, GatewayConfig] = {
    "us-envoy-1": GatewayConfig(
        aws_region="us-east-1",
        eks_cluster_name="envoy-eks-cluster",
        k8s_namespace="envoy-test",
        gateway_name="envoy-gateway",
        gateway_class="envoy-gateway"
    ),
    "eu-envoy-1": GatewayConfig(
        aws_region="eu-central-1",
        eks_cluster_name="envoy-eks-cluster-np",
        k8s_namespace="envoy-np",
        gateway_name="envoy-gateway",
        gateway_class="envoy-gateway"
    ),
}

# Create settings instance
settings = ProdSettings()
