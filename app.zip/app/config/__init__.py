"""
Configuration management for Envoy Gateway Agent API.
Loads environment-specific configuration based on ENVOY_AGENT_ENV variable.

Usage:
    from app.config import get_settings, get_gateway_config, get_available_gateways
"""

import os
from typing import Dict

from .base import Settings, GatewayConfig, BaseConfig

# Determine environment
ENV = os.getenv("ENVOY_AGENT_ENV", "dev").lower()

# Import environment-specific config
if ENV == "prod":
    from .prod import settings, GATEWAY_CONFIGS
elif ENV == "np":
    from .np import settings, GATEWAY_CONFIGS
elif ENV == "sbx":
    from .sbx import settings, GATEWAY_CONFIGS
else:
    from .dev import settings, GATEWAY_CONFIGS


def get_settings() -> Settings:
    """Get settings for current environment."""
    return settings


def get_gateway_config(target_gateway: str) -> GatewayConfig:
    """
    Get gateway configuration for a specific target gateway.
    
    Args:
        target_gateway: Gateway identifier (e.g., 'us-envoy-1', 'eu-envoy-1')
        
    Returns:
        GatewayConfig for the specified gateway
        
    Raises:
        ValueError: If target_gateway is not configured
    """
    if target_gateway not in GATEWAY_CONFIGS:
        available = ", ".join(GATEWAY_CONFIGS.keys())
        raise ValueError(f"Unknown target gateway: '{target_gateway}'. Available: {available}")
    return GATEWAY_CONFIGS[target_gateway]


def get_available_gateways() -> Dict[str, GatewayConfig]:
    """Get all available gateway configurations for current environment."""
    return GATEWAY_CONFIGS.copy()


def add_gateway_config(name: str, config: GatewayConfig):
    """Add a new gateway configuration dynamically."""
    GATEWAY_CONFIGS[name] = config


def get_current_env() -> str:
    """Get current environment name."""
    return ENV


__all__ = [
    "Settings",
    "GatewayConfig",
    "GATEWAY_CONFIGS",
    "get_settings",
    "get_gateway_config",
    "get_available_gateways",
    "add_gateway_config",
    "get_current_env",
    "ENV",
]
