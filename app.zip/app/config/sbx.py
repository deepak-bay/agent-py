"""
Sandbox environment configuration.
Used for testing and validation before deploying to dev.

Set ENVOY_AGENT_ENV=sbx to use this configuration.
"""

from typing import Dict
from .base import Settings, GatewayConfig


class SbxSettings(Settings):
    """Sandbox environment settings."""
    
    env: str = "sbx"
    debug: bool = True
    log_level: str = "DEBUG"
    
    # Sandbox uses shorter token refresh for testing
    token_refresh_seconds: int = 300
    
    # Feature Flags
    enable_metrics: bool = True
    enable_tracing: bool = True


# Sandbox gateway configurations
# These point to sandbox/test clusters for experimentation
GATEWAY_CONFIGS: Dict[str, GatewayConfig] = {
    "us-envoy-sbx": GatewayConfig(
        aws_region="us-east-1",
        eks_cluster_name="envoy-us-east-1-aws-sbx",
        k8s_namespace="envoy-gateway-sbx",
        gateway_name="envoy-gateway-dataplane-sbx",
        gateway_class="envoy-gateway-dataplane-controller"
    ),
    "eu-envoy-sbx": GatewayConfig(
        aws_region="eu-central-1",
        eks_cluster_name="envoy-eu-central-1-aws-sbx",
        k8s_namespace="envoy-gateway-sbx",
        gateway_name="envoy-gateway-dataplane-sbx",
        gateway_class="envoy-gateway-dataplane-controller"
    ),
}

# Create settings instance
settings = SbxSettings()
