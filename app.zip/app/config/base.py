"""
Base configuration classes and shared settings.
Environment-specific configs inherit from these base classes.
"""

from pydantic_settings import BaseSettings
from pydantic import BaseModel
from typing import Dict


class GatewayConfig(BaseModel):
    """Configuration for a specific gateway/cluster."""
    aws_region: str
    eks_cluster_name: str
    k8s_namespace: str
    gateway_name: str
    gateway_class: str = "envoy-gateway"


class Settings(BaseSettings):
    """Application settings loaded from environment variables."""
    
    # Environment
    env: str = "dev"
    
    # API Settings
    api_title: str = "Envoy Gateway Agent API"
    api_description: str = "Comprehensive API for managing Envoy Gateway resources"
    api_version: str = "1.0.0"
    api_prefix: str = "/api/v1"
    
    # Server Settings
    host: str = "0.0.0.0"
    port: int = 9080
    debug: bool = False
    
    # Default AWS/EKS Settings (used when no target gateway specified)
    aws_region: str = "us-east-1"
    eks_cluster_name: str = "envoy-eks-cluster"
    
    # Default Kubernetes Settings
    k8s_namespace: str = "envoy-test"
    default_gateway_name: str = "envoy-gateway"
    default_gateway_class: str = "envoy-gateway"
    
    # Token Settings
    token_refresh_seconds: int = 600  # Refresh token every 10 minutes (EKS tokens expire in 15)
    
    # TLS Settings
    ca_cert_path: str = "/tmp/eks-ca.crt"
    
    # Feature Flags
    enable_metrics: bool = True
    enable_tracing: bool = False
    
    # Logging
    log_level: str = "INFO"
    log_format: str = "json"
    
    class Config:
        env_prefix = "ENVOY_AGENT_"
        env_file = ".env"
        case_sensitive = False


class BaseConfig:
    """Base configuration with common gateway configs."""
    
    @staticmethod
    def get_base_gateway_configs() -> Dict[str, GatewayConfig]:
        """Get base gateway configurations (can be extended by env-specific configs)."""
        return {}
