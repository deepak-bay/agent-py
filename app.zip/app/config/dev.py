"""
Development environment configuration.
Used for local development and testing.

Set ENVOY_AGENT_ENV=dev to use this configuration.
"""

from typing import Dict
from .base import Settings, GatewayConfig


class DevSettings(Settings):
    """Development environment settings."""
    
    env: str = "dev"
    debug: bool = True
    log_level: str = "DEBUG"
    
    # Development uses shorter token refresh
    token_refresh_seconds: int = 300
    
    # Feature Flags
    enable_metrics: bool = True
    enable_tracing: bool = True


# Development gateway configurations
# These point to development/sandbox clusters
GATEWAY_CONFIGS: Dict[str, GatewayConfig] = {
    "us-envoy-1": GatewayConfig(
        aws_region="us-east-1",
        eks_cluster_name="envoy-eks-cluster",
        k8s_namespace="envoy-test",
        gateway_name="example-gateway",
        gateway_class="example-gateway-class"
    ),
    "eu-envoy-1": GatewayConfig(
        aws_region="eu-central-1",
        eks_cluster_name="envoy-eks-cluster-np",
        k8s_namespace="envoy-np",
        gateway_name="envoy-gateway",
        gateway_class="envoy-gateway"
    ),
}

# Create settings instance
settings = DevSettings()
