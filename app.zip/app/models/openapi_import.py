"""
Models for OpenAPI spec import functionality.
"""

from typing import Optional, Dict, List, Any
from pydantic import BaseModel, Field
from enum import Enum


class OpenAPIImportRequest(BaseModel):
    """Request to import routes from an OpenAPI specification."""
    
    target_gateway: str = Field(
        ..., 
        description="Target gateway identifier (e.g., 'us-envoy-1')",
        alias="targetGateway"
    )
    spec: Dict[str, Any] = Field(
        ..., 
        description="OpenAPI specification (JSON object)"
    )
    base_path: Optional[str] = Field(
        None, 
        description="Override base path for all routes",
        alias="basePath"
    )
    backend_url: str = Field(
        ..., 
        description="Backend URL for all routes",
        alias="backendUrl"
    )
    backend_port: int = Field(
        default=443, 
        description="Backend port",
        alias="backendPort"
    )
    backend_tls_enabled: bool = Field(
        default=True, 
        description="Enable TLS for backend",
        alias="backendTlsEnabled"
    )
    route_prefix: Optional[str] = Field(
        None, 
        description="Prefix for route names",
        alias="routePrefix"
    )
    hostnames: Optional[List[str]] = Field(
        None, 
        description="Hostnames for the routes"
    )
    labels: Optional[Dict[str, str]] = Field(
        None, 
        description="Labels to apply to all created routes"
    )
    dry_run: bool = Field(
        default=False, 
        description="If true, only return what would be created without actually creating",
        alias="dryRun"
    )
    
    class Config:
        populate_by_name = True


class OpenAPIImportFromURLRequest(BaseModel):
    """Request to import routes from an OpenAPI specification URL."""
    
    target_gateway: str = Field(
        ..., 
        description="Target gateway identifier",
        alias="targetGateway"
    )
    spec_url: str = Field(
        ..., 
        description="URL to the OpenAPI specification",
        alias="specUrl"
    )
    backend_url: str = Field(
        ..., 
        description="Backend URL for all routes",
        alias="backendUrl"
    )
    backend_port: int = Field(
        default=443, 
        description="Backend port",
        alias="backendPort"
    )
    backend_tls_enabled: bool = Field(
        default=True, 
        description="Enable TLS for backend",
        alias="backendTlsEnabled"
    )
    route_prefix: Optional[str] = Field(
        None, 
        description="Prefix for route names",
        alias="routePrefix"
    )
    hostnames: Optional[List[str]] = Field(
        None, 
        description="Hostnames for the routes"
    )
    labels: Optional[Dict[str, str]] = Field(
        None, 
        description="Labels to apply to all created routes"
    )
    dry_run: bool = Field(
        default=False, 
        description="If true, only return what would be created",
        alias="dryRun"
    )
    
    class Config:
        populate_by_name = True


class RouteFromSpec(BaseModel):
    """A route parsed from OpenAPI spec."""
    
    name: str
    path: str
    methods: List[str]
    summary: Optional[str] = None
    operation_id: Optional[str] = None
    tags: Optional[List[str]] = None


class OpenAPIImportResponse(BaseModel):
    """Response from OpenAPI import operation."""
    
    status: str
    message: str
    spec_title: Optional[str] = Field(None, alias="specTitle")
    spec_version: Optional[str] = Field(None, alias="specVersion")
    routes_created: int = Field(0, alias="routesCreated")
    routes_skipped: int = Field(0, alias="routesSkipped")
    routes: List[RouteFromSpec] = []
    errors: List[str] = []
    target_gateway: str = Field(..., alias="targetGateway")
    namespace: str
    dry_run: bool = Field(False, alias="dryRun")
    
    class Config:
        populate_by_name = True
