"""
API Management models for creating, updating, deleting, and retrieving APIs.
An API is a higher-level abstraction that orchestrates routes, backends, and policies.

policy-payload accepts a list of policy OBJECTS (not strings).
Each object must have a "type" field. "name" is optional (auto-generated if omitted).
No "targetRoute" is needed — it is derived from the API name.

Supported policy types:
  SecurityPolicy:       JWT-validation, cors, api-key, basic-auth, ip-allow, ip-block, external-auth
  BackendTrafficPolicy: rate-limit, circuit-breaker, retry
"""

from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any
from enum import Enum


class ApiType(str, Enum):
    """Supported API types."""
    HTTP = "http"
    TLS = "tls"


# ==================== Upstream (Backend) ====================

class Upstream(BaseModel):
    """
    Upstream backend configuration for the API.

    - url (required): The backend/upstream URL (e.g., http://test.com, https://api.example.com)
    - tls-certificate (optional): Name of an existing TLS secret for mTLS to the backend.
      Only needed when the upstream requires a client certificate.
    """
    url: str = Field(..., description="Backend/upstream URL (e.g., 'http://test.com')")
    tls_certificate: Optional[str] = Field(
        None,
        description="Name of existing TLS secret for backend mTLS (optional)",
        alias="tls-certificate",
    )

    class Config:
        populate_by_name = True


# ==================== API Gateway Config ====================

class ApiGatewayConfig(BaseModel):
    """
    API Gateway configuration section.

    Required fields: name, description, api-type, upstream, target-gateway, path.
    Optional fields: policy-payload, tags.
    """
    name: str = Field(..., description="API name (used as resource name)", min_length=1, max_length=253)
    description: str = Field(..., description="API description")
    api_type: ApiType = Field(..., description="API type: 'http' or 'tls'", alias="api-type")
    policy_payload: Optional[List[Dict[str, Any]]] = Field(
        default_factory=list,
        description=(
            "Optional list of policy objects. Each must have 'type' (required) and 'name' (optional). "
            "No 'targetRoute' needed — derived from API name.\n\n"
            "**Naming:** Policy names are auto-prefixed with the API name. "
            "E.g., name 'my-jwt' on API 'petstore-api' → resource 'petstore-api-my-jwt'. "
            "If name is omitted, defaults to '{api-name}-{type-suffix}'.\n\n"
            "**SecurityPolicy types (all optional):**\n"
            "- `JWT-validation` — issuer, jwksUri, audiences, claimToHeaders\n"
            "- `cors` — allowedOrigins (full URLs like https://example.com; bare domains auto-prefixed), allowedMethods, allowedHeaders, exposeHeaders, allowCredentials, maxAge\n"
            "- `api-key` — headerName, apiKeysSecret\n"
            "- `basic-auth` — usersSecret\n"
            "- `ip-allow` — allowedCidrs\n"
            "- `ip-block` — blockedCidrs\n"
            "- `external-auth` — authServiceName, authServicePort, authPath, headersToAuth, failureMode\n\n"
            "**BackendTrafficPolicy types (all optional):**\n"
            "- `rate-limit` — requests, unit\n"
            "- `circuit-breaker` — maxConnections, maxPendingRequests, maxParallelRequests\n"
            "- `retry` — numRetries, perRetryTimeout, retryOn5xx, retryOnConnectFailure"
        ),
        alias="policy-payload",
    )
    tags: Optional[List[str]] = Field(None, description="Optional tags for categorizing the API")
    upstream: Upstream = Field(..., description="Upstream backend configuration")
    target_gateway: str = Field(
        ...,
        description="Target gateway identifier (e.g., 'us-envoy-1')",
        alias="target-gateway",
    )
    path: str = Field(..., description="Path prefix for the API on the gateway")

    class Config:
        populate_by_name = True


# ==================== Create Request ====================

class ApiGatewayCreateRequest(BaseModel):
    """
    Request model for creating a new API.

    Creates route, backend, and attaches policies in a single operation.
    If a swagger/openapi spec is provided, all spec paths are consolidated as
    additional rules within the single main route (one K8s resource).

    Required fields in api-gateway: name, description, api-type, upstream, target-gateway, path.
    Optional fields in api-gateway: policy-payload, tags, swagger.
    """
    api_gateway: ApiGatewayConfig = Field(
        ..., description="API gateway configuration", alias="api-gateway"
    )
    swagger: Optional[Dict[str, Any]] = Field(
        None,
        description="Optional OpenAPI/Swagger specification. "
                    "If provided, spec paths are consolidated as additional rules "
                    "within the main route (single K8s resource).",
    )

    class Config:
        populate_by_name = True


# ==================== Update Request ====================

class ApiGatewayUpdateRequest(BaseModel):
    """
    Request model for updating an existing API.

    Uses diff-based approach: fetches existing state, compares, and only updates changed fields.
    Policies are diffed — stale ones removed, new ones added, unchanged ones kept.
    """
    api_gateway: ApiGatewayConfig = Field(
        ..., description="Updated API gateway configuration", alias="api-gateway"
    )
    swagger: Optional[Dict[str, Any]] = Field(
        None, description="Updated OpenAPI/Swagger specification"
    )

    class Config:
        populate_by_name = True


# ==================== Response Models ====================

class ApiCreatedResource(BaseModel):
    """Details of a resource created as part of the API."""
    resource_type: str = Field(..., description="Type of resource (e.g., HTTPRoute, SecurityPolicy, BackendTrafficPolicy)", alias="resourceType")
    resource_name: str = Field(..., description="Name of the resource", alias="resourceName")
    status: str = Field(..., description="Creation status (created, updated, deleted)")

    class Config:
        populate_by_name = True


class ApiGatewayResponse(BaseModel):
    """Response model for API operations."""
    status: str = Field(..., description="Operation status (created, updated, deleted, partial)")
    message: str = Field(..., description="Status message")
    api_name: str = Field(..., description="API name", alias="apiName")
    namespace: str = Field(..., description="Kubernetes namespace")
    target_gateway: str = Field(..., description="Target gateway", alias="targetGateway")
    resources_created: Optional[List[ApiCreatedResource]] = Field(
        None, description="List of created/deleted resources", alias="resourcesCreated"
    )
    errors: Optional[List[str]] = Field(None, description="Any errors during operation")
    details: Optional[Dict[str, Any]] = Field(None, description="Additional details")

    class Config:
        populate_by_name = True


class ApiGatewayDetailResponse(BaseModel):
    """Detailed response for a single API."""
    api_name: str = Field(..., description="API name", alias="apiName")
    description: Optional[str] = Field(None, description="API description")
    api_type: Optional[str] = Field(None, description="API type", alias="apiType")
    tags: Optional[List[str]] = Field(None, description="API tags")
    target_gateway: str = Field(..., description="Target gateway", alias="targetGateway")
    namespace: str = Field(..., description="Namespace")
    route: Optional[Dict[str, Any]] = Field(None, description="Main route resource")
    swagger_routes: Optional[List[Dict[str, Any]]] = Field(
        None, description="Swagger/OpenAPI paths consolidated as additional rules within the main route", alias="swaggerRoutes"
    )
    policies: Optional[List[Dict[str, Any]]] = Field(
        None, description="Attached policies (SecurityPolicy + BackendTrafficPolicy)"
    )
    backend: Optional[Dict[str, Any]] = Field(None, description="Backend service")
    update_payload: Optional[Dict[str, Any]] = Field(
        None,
        description="Ready-to-use payload for PUT /api/{name} — copy-paste this into an update request",
        alias="updatePayload",
    )

    class Config:
        populate_by_name = True


class ApiGatewayListResponse(BaseModel):
    """Response model for listing APIs."""
    items: List[Dict[str, Any]] = Field(..., description="List of APIs")
    total: int = Field(..., description="Total count")
    target_gateway: str = Field(..., description="Target gateway", alias="targetGateway")
    namespace: str = Field(..., description="Namespace")

    class Config:
        populate_by_name = True


class ApiSummaryItem(BaseModel):
    """A single row in the API summary table."""
    name: str = Field(..., description="API name")
    path: str = Field(..., description="API path on the gateway")
    api_type: str = Field("http", description="API type (http or tls)", alias="apiType")
    description: str = Field("", description="API description")

    class Config:
        populate_by_name = True


class ApiSummaryListResponse(BaseModel):
    """Lightweight tabular response listing API name and path."""
    items: List[ApiSummaryItem] = Field(..., description="List of API name/path entries")
    total: int = Field(..., description="Total count")
    target_gateway: str = Field(..., description="Target gateway", alias="targetGateway")
    namespace: str = Field(..., description="Namespace")

    class Config:
        populate_by_name = True


# ==================== Shared example payloads for OpenAPI docs ====================
# Used by both models and router Body(openapi_examples=...)

ALL_POLICIES_PAYLOAD = [
    {
        "type": "JWT-validation",
        "name": "my-jwt",
        "issuer": "https://auth.example.com",
        "jwksUri": "https://auth.example.com/.well-known/jwks.json",
        "audiences": ["api.example.com"],
        "claimToHeaders": {"sub": "x-user-id", "email": "x-user-email"},
    },
    {
        "type": "cors",
        "name": "my-cors",
        "allowedOrigins": ["https://app.example.com", "https://admin.example.com"],
        "allowedMethods": ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
        "allowedHeaders": ["Content-Type", "Authorization"],
        "exposeHeaders": ["X-Request-ID"],
        "allowCredentials": True,
        "maxAge": "24h",
    },
    {
        "type": "api-key",
        "name": "my-api-key",
        "headerName": "X-API-Key",
        "apiKeysSecret": "api-keys-secret",
    },
    {
        "type": "basic-auth",
        "name": "my-basic",
        "usersSecret": "basic-auth-users",
    },
    {
        "type": "ip-allow",
        "name": "office-ips",
        "allowedCidrs": ["10.0.0.0/8", "192.168.1.0/24"],
    },
    {
        "type": "ip-block",
        "name": "bad-actors",
        "blockedCidrs": ["1.2.3.0/24", "5.6.7.0/24"],
    },
    {
        "type": "external-auth",
        "name": "my-ext-auth",
        "authServiceName": "auth-service",
        "authServicePort": 9000,
        "authPath": "/authorize",
        "headersToAuth": ["Authorization", "X-Request-ID"],
        "failureMode": "DENY",
    },
    {
        "type": "rate-limit",
        "name": "my-rate-limit",
        "requests": 100,
        "unit": "Minute",
    },
    {
        "type": "circuit-breaker",
        "name": "my-cb",
        "maxConnections": 1024,
        "maxPendingRequests": 128,
        "maxParallelRequests": 128,
    },
    {
        "type": "retry",
        "name": "my-retry",
        "numRetries": 3,
        "perRetryTimeout": "5s",
        "retryOn5xx": True,
        "retryOnConnectFailure": True,
    },
]

SAMPLE_SWAGGER_SPEC = {
    "openapi": "3.0.0",
    "info": {
        "title": "Pet Store API",
        "description": "A sample Pet Store API",
        "version": "1.0.0",
        "contact": {"name": "API Support", "email": "support@example.com"},
    },
    "servers": [{"url": "https://petstore.example.com", "description": "Production"}],
    "paths": {
        "/pets": {
            "get": {
                "summary": "List all pets",
                "operationId": "listPets",
                "parameters": [
                    {"name": "limit", "in": "query", "required": False, "schema": {"type": "integer", "maximum": 100}},
                ],
                "responses": {"200": {"description": "A list of pets"}},
            },
            "post": {
                "summary": "Create a pet",
                "operationId": "createPet",
                "responses": {"201": {"description": "Pet created"}, "400": {"description": "Invalid input"}},
            },
        },
        "/pets/{petId}": {
            "get": {
                "summary": "Get a pet by ID",
                "operationId": "getPetById",
                "parameters": [{"name": "petId", "in": "path", "required": True, "schema": {"type": "string"}}],
                "responses": {"200": {"description": "A single pet"}, "404": {"description": "Pet not found"}},
            },
            "put": {
                "summary": "Update a pet",
                "operationId": "updatePet",
                "parameters": [{"name": "petId", "in": "path", "required": True, "schema": {"type": "string"}}],
                "responses": {"200": {"description": "Pet updated"}, "404": {"description": "Pet not found"}},
            },
            "delete": {
                "summary": "Delete a pet",
                "operationId": "deletePet",
                "parameters": [{"name": "petId", "in": "path", "required": True, "schema": {"type": "string"}}],
                "responses": {"204": {"description": "Pet deleted"}, "404": {"description": "Pet not found"}},
            },
        },
    },
    "components": {
        "schemas": {
            "Pet": {
                "type": "object",
                "required": ["name"],
                "properties": {
                    "id": {"type": "integer", "format": "int64"},
                    "name": {"type": "string"},
                    "species": {"type": "string", "enum": ["dog", "cat", "bird", "fish"]},
                    "status": {"type": "string", "enum": ["available", "adopted", "pending"]},
                },
            }
        }
    },
}
