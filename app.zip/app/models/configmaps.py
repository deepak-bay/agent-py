"""
ConfigMap models for CA certificates and TLS configurations.
Supports both no-mTLS (CA only) and mTLS (CA + client cert) scenarios.
"""

from pydantic import BaseModel, Field, field_validator
from typing import Optional, List, Dict, Any
from enum import Enum


class CACertificateRefKind(str, Enum):
    """Kind of resource for CA certificate reference."""
    CONFIG_MAP = "ConfigMap"
    SECRET = "Secret"


# ==================== ConfigMap Models ====================

class ConfigMapMetadata(BaseModel):
    """Metadata for ConfigMap."""
    name: str = Field(..., description="ConfigMap name", min_length=1, max_length=253)
    labels: Optional[Dict[str, str]] = Field(None, description="Labels")
    annotations: Optional[Dict[str, str]] = Field(None, description="Annotations")


class ConfigMapCreate(BaseModel):
    """Request model for creating a ConfigMap with file paths.
    
    Used for creating ConfigMaps from local file paths (e.g., CA certificates).
    """
    metadata: ConfigMapMetadata = Field(..., description="ConfigMap metadata")
    file_paths: Dict[str, str] = Field(
        ..., 
        alias="filePaths",
        description="Map of key names to file paths (e.g., {'ca.crt': '/path/to/ca-chain.crt'})"
    )

    class Config:
        populate_by_name = True


class ConfigMapCreateFromContent(BaseModel):
    """Request model for creating a ConfigMap with direct content.
    
    Used for creating ConfigMaps from content strings (e.g., base64 or raw PEM).
    """
    metadata: ConfigMapMetadata = Field(..., description="ConfigMap metadata")
    data: Dict[str, str] = Field(
        ..., 
        description="Map of key names to content (e.g., {'ca.crt': '-----BEGIN CERTIFICATE-----...'})"
    )


class ConfigMapResponse(BaseModel):
    """Response model for ConfigMap operations."""
    api_version: str = Field(default="v1", alias="apiVersion")
    kind: str = Field(default="ConfigMap")
    metadata: Dict[str, Any] = Field(..., description="ConfigMap metadata")
    data: Optional[Dict[str, str]] = Field(None, description="ConfigMap data")

    class Config:
        populate_by_name = True


# ==================== TLS Secret Models ====================

class TLSSecretCreate(BaseModel):
    """Request model for creating a TLS Secret from file paths.
    
    Used for mTLS scenarios where client certificates are needed.
    """
    metadata: ConfigMapMetadata = Field(..., description="Secret metadata")
    tls_crt_path: str = Field(
        ..., 
        alias="tlsCrtPath",
        description="Path to tls.crt file (client certificate)"
    )
    tls_key_path: str = Field(
        ..., 
        alias="tlsKeyPath",
        description="Path to tls.key file (client private key)"
    )
    ca_crt_path: Optional[str] = Field(
        None,
        alias="caCrtPath", 
        description="Optional path to ca.crt file"
    )

    class Config:
        populate_by_name = True


class TLSSecretCreateFromContent(BaseModel):
    """Request model for creating a TLS Secret with direct content."""
    metadata: ConfigMapMetadata = Field(..., description="Secret metadata")
    tls_crt: str = Field(..., alias="tlsCrt", description="TLS certificate content (PEM)")
    tls_key: str = Field(..., alias="tlsKey", description="TLS private key content (PEM)")
    ca_crt: Optional[str] = Field(None, alias="caCrt", description="CA certificate content (PEM)")

    class Config:
        populate_by_name = True


# ==================== Batch Operations for Scale (2000+ APIs) ====================

class BatchConfigMapItem(BaseModel):
    """Single item for batch ConfigMap creation."""
    name: str = Field(..., description="ConfigMap name")
    file_paths: Optional[Dict[str, str]] = Field(None, alias="filePaths", description="File paths")
    data: Optional[Dict[str, str]] = Field(None, description="Direct content data")
    labels: Optional[Dict[str, str]] = Field(None, description="Labels")
    annotations: Optional[Dict[str, str]] = Field(None, description="Annotations")

    class Config:
        populate_by_name = True

    @field_validator('data', 'file_paths')
    @classmethod
    def validate_has_data_or_paths(cls, v, info):
        return v


class BatchConfigMapCreate(BaseModel):
    """Request model for batch ConfigMap creation.
    
    Optimized for creating multiple ConfigMaps efficiently (2000+ APIs scenario).
    """
    items: List[BatchConfigMapItem] = Field(
        ..., 
        description="List of ConfigMaps to create",
        min_length=1,
        max_length=500  # Limit per batch for safety
    )
    fail_fast: bool = Field(
        default=False, 
        alias="failFast",
        description="Stop on first error (True) or continue and report all errors (False)"
    )

    class Config:
        populate_by_name = True


class BatchConfigMapResult(BaseModel):
    """Result for a single ConfigMap in batch operation."""
    name: str = Field(..., description="ConfigMap name")
    status: str = Field(..., description="Status: created, exists, failed")
    error: Optional[str] = Field(None, description="Error message if failed")


class BatchConfigMapResponse(BaseModel):
    """Response model for batch ConfigMap creation."""
    total: int = Field(..., description="Total items processed")
    created: int = Field(..., description="Successfully created count")
    exists: int = Field(..., description="Already exists count")
    failed: int = Field(..., description="Failed count")
    results: List[BatchConfigMapResult] = Field(..., description="Individual results")


# ==================== CA Certificate Reference Models ====================

class CACertificateRef(BaseModel):
    """Reference to a CA certificate (ConfigMap or Secret).
    
    For Backend TLS configuration:
    - group: "" (empty for core resources)
    - kind: "ConfigMap" or "Secret"
    - name: resource name
    """
    group: str = Field(default="", description="API group (empty for core resources)")
    kind: CACertificateRefKind = Field(default=CACertificateRefKind.CONFIG_MAP, description="Resource kind")
    name: str = Field(..., description="Resource name")

    class Config:
        populate_by_name = True


class ClientCertificateRef(BaseModel):
    """Reference to a client certificate Secret (for mTLS).
    
    For Backend mTLS configuration:
    - kind: "Secret" (TLS type with tls.crt + tls.key)
    - name: secret name
    """
    kind: str = Field(default="Secret", description="Resource kind (always Secret for client certs)")
    name: str = Field(..., description="Secret name")

    class Config:
        populate_by_name = True


# ==================== Backend TLS Configuration Models ====================

class BackendTLSConfig(BaseModel):
    """TLS configuration for Backend.
    
    Two modes:
    1. No mTLS (server verification only):
       - caCertificateRefs: ConfigMap with ca.crt
       
    2. mTLS (mutual TLS):
       - caCertificateRefs: ConfigMap/Secret with ca.crt
       - clientCertificateRef: Secret with tls.crt + tls.key
    """
    ca_certificate_refs: List[CACertificateRef] = Field(
        ..., 
        alias="caCertificateRefs",
        description="CA certificate references (ConfigMap or Secret)",
        min_length=1
    )
    client_certificate_ref: Optional[ClientCertificateRef] = Field(
        None, 
        alias="clientCertificateRef",
        description="Client certificate reference (Secret) - only for mTLS"
    )

    class Config:
        populate_by_name = True


# ==================== Simplified Backend with TLS ====================

class SimpleBackendWithTLS(BaseModel):
    """Simplified model for creating a Backend with TLS configuration.
    
    Supports both no-mTLS and mTLS scenarios.
    """
    name: str = Field(..., description="Backend name")
    hostname: str = Field(..., description="FQDN hostname")
    port: int = Field(..., description="Port number", ge=1, le=65535)
    
    # TLS Configuration
    ca_configmap_name: Optional[str] = Field(
        None, 
        alias="caConfigMapName",
        description="ConfigMap name containing ca.crt (for no-mTLS or mTLS)"
    )
    ca_secret_name: Optional[str] = Field(
        None,
        alias="caSecretName", 
        description="Secret name containing ca.crt (alternative to ConfigMap)"
    )
    client_cert_secret_name: Optional[str] = Field(
        None, 
        alias="clientCertSecretName",
        description="Secret name containing tls.crt + tls.key (for mTLS only)"
    )

    class Config:
        populate_by_name = True

    def build_tls_config(self) -> Optional[Dict[str, Any]]:
        """Build TLS configuration for Backend spec."""
        if not self.ca_configmap_name and not self.ca_secret_name:
            return None
        
        tls_config = {"caCertificateRefs": []}
        
        # Add CA reference
        if self.ca_configmap_name:
            tls_config["caCertificateRefs"].append({
                "group": "",
                "kind": "ConfigMap",
                "name": self.ca_configmap_name,
            })
        elif self.ca_secret_name:
            tls_config["caCertificateRefs"].append({
                "group": "",
                "kind": "Secret",
                "name": self.ca_secret_name,
            })
        
        # Add client cert reference for mTLS
        if self.client_cert_secret_name:
            tls_config["clientCertificateRef"] = {
                "kind": "Secret",
                "name": self.client_cert_secret_name,
            }
        
        return tls_config
