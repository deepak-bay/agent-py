"""
Common models shared across all resources.
"""

from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any
from enum import Enum
from datetime import datetime


class ResourceStatus(str, Enum):
    """Status of a Kubernetes resource."""
    PENDING = "Pending"
    READY = "Ready"
    FAILED = "Failed"
    UNKNOWN = "Unknown"


class ObjectMeta(BaseModel):
    """Kubernetes object metadata. Namespace is derived from targetGateway."""
    name: str = Field(..., description="Name of the resource", min_length=1, max_length=253)
    labels: Optional[Dict[str, str]] = Field(default_factory=dict, description="Resource labels")
    annotations: Optional[Dict[str, str]] = Field(default_factory=dict, description="Resource annotations")


class TargetRef(BaseModel):
    """Reference to a target resource for policies."""
    group: str = Field(default="gateway.networking.k8s.io", description="API group of the target")
    kind: str = Field(..., description="Kind of the target resource")
    name: str = Field(..., description="Name of the target resource")
    namespace: Optional[str] = Field(None, description="Namespace of the target")
    section_name: Optional[str] = Field(None, description="Section within the target", alias="sectionName")

    class Config:
        populate_by_name = True


class LocalObjectReference(BaseModel):
    """Reference to a local object."""
    group: Optional[str] = Field(default="", description="API group")
    kind: Optional[str] = Field(default="Secret", description="Kind of the object")
    name: str = Field(..., description="Name of the object")


class SecretObjectReference(BaseModel):
    """Reference to a secret."""
    group: Optional[str] = Field(default="", description="API group")
    kind: Optional[str] = Field(default="Secret", description="Kind (usually Secret)")
    name: str = Field(..., description="Name of the secret")
    namespace: Optional[str] = Field(None, description="Namespace of the secret")


class ResourceResponse(BaseModel):
    """Standard response for resource operations."""
    status: str = Field(..., description="Operation status")
    message: str = Field(..., description="Status message")
    resource_name: str = Field(..., description="Name of the affected resource")
    namespace: str = Field(..., description="Namespace of the resource")
    resource_type: str = Field(..., description="Type of the resource")
    details: Optional[Dict[str, Any]] = Field(None, description="Additional details")


class ResourceListResponse(BaseModel):
    """Response for listing resources."""
    items: List[Dict[str, Any]] = Field(..., description="List of resources")
    total: int = Field(..., description="Total count of resources")
    namespace: str = Field(..., description="Namespace queried")


class HealthResponse(BaseModel):
    """Health check response."""
    status: str = Field(..., description="Health status")
    version: str = Field(..., description="API version")
    kubernetes_connected: bool = Field(..., description="K8s connection status")
    cluster_name: Optional[str] = Field(None, description="Connected cluster name")
    timestamp: datetime = Field(default_factory=datetime.utcnow)


class ErrorResponse(BaseModel):
    """Error response model."""
    error: str = Field(..., description="Error type")
    message: str = Field(..., description="Error message")
    details: Optional[Dict[str, Any]] = Field(None, description="Error details")
    timestamp: datetime = Field(default_factory=datetime.utcnow)
