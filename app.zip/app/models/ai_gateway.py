"""
AI Gateway models for managing AI/LLM service backends, routes, and policies.
Supports providers like OpenAI, Azure OpenAI, AWS Bedrock, and custom AI services.
"""

from pydantic import BaseModel, Field, HttpUrl
from typing import Optional, List, Dict, Any
from enum import Enum
from .common import ObjectMeta


class AIProvider(str, Enum):
    """Supported AI/LLM providers."""
    OPENAI = "openai"
    AZURE_OPENAI = "azure-openai"
    AWS_BEDROCK = "aws-bedrock"
    CUSTOM = "custom"


class AIModel(str, Enum):
    """Common AI/LLM models."""
    GPT_4 = "gpt-4"
    GPT_4_TURBO = "gpt-4-turbo"
    GPT_4O = "gpt-4o"
    GPT_4O_MINI = "gpt-4o-mini"
    GPT_35_TURBO = "gpt-3.5-turbo"
    CLAUDE_3_OPUS = "claude-3-opus"
    CLAUDE_3_SONNET = "claude-3-sonnet"
    CLAUDE_3_HAIKU = "claude-3-haiku"
    CLAUDE_35_SONNET = "claude-3.5-sonnet"
    LLAMA_3 = "llama-3"
    CUSTOM = "custom"


class RateLimitUnit(str, Enum):
    """Rate limit time unit."""
    SECOND = "Second"
    MINUTE = "Minute"
    HOUR = "Hour"
    DAY = "Day"


# ==================== AI Service Backend ====================

class AIBackendCreate(BaseModel):
    """
    Create an AI service backend pointing to an AI/LLM provider.
    
    This creates:
    - A Backend resource pointing to the AI provider's API endpoint
    - Appropriate TLS and protocol configuration
    """
    name: str = Field(..., description="Backend name", min_length=1, max_length=253)
    target_gateway: str = Field(..., description="Target gateway identifier", alias="targetGateway")
    provider: AIProvider = Field(..., description="AI provider type")
    
    # Provider-specific settings
    api_endpoint: Optional[str] = Field(
        None,
        description="Custom API endpoint URL (auto-detected for known providers)",
        alias="apiEndpoint",
    )
    azure_deployment_name: Optional[str] = Field(
        None,
        description="Azure OpenAI deployment name (required for azure-openai provider)",
        alias="azureDeploymentName",
    )
    azure_api_version: Optional[str] = Field(
        default="2024-02-01",
        description="Azure OpenAI API version",
        alias="azureApiVersion",
    )
    aws_region: Optional[str] = Field(
        None,
        description="AWS region for Bedrock (required for aws-bedrock provider)",
        alias="awsRegion",
    )
    
    # Connection settings
    port: int = Field(default=443, description="Backend port", ge=1, le=65535)
    enable_tls: bool = Field(default=True, description="Enable TLS to backend", alias="enableTls")
    
    # Metadata
    labels: Optional[Dict[str, str]] = Field(None, description="Resource labels")

    class Config:
        populate_by_name = True
        json_schema_extra = {
            "example": {
                "name": "openai-backend",
                "targetGateway": "us-envoy-1",
                "provider": "openai",
                "enableTls": True,
            }
        }


class AIBackendResponse(BaseModel):
    """Response for AI backend operations."""
    status: str = Field(..., description="Operation status")
    message: str = Field(..., description="Status message")
    backend_name: str = Field(..., description="Backend resource name", alias="backendName")
    namespace: str = Field(..., description="Kubernetes namespace")
    target_gateway: str = Field(..., description="Target gateway", alias="targetGateway")
    provider: str = Field(..., description="AI provider")
    api_endpoint: str = Field(..., description="API endpoint hostname", alias="apiEndpoint")
    details: Optional[Dict[str, Any]] = Field(None, description="Additional details")

    class Config:
        populate_by_name = True


# ==================== AI Route ====================

class AIRouteCreate(BaseModel):
    """
    Create an HTTPRoute configured for AI/LLM traffic.
    
    Routes traffic from the gateway to an AI service backend
    with optional model-based routing and path configuration.
    """
    name: str = Field(..., description="Route name", min_length=1, max_length=253)
    target_gateway: str = Field(..., description="Target gateway identifier", alias="targetGateway")
    backend_name: str = Field(..., description="AI backend name (must exist)", alias="backendName")
    backend_port: int = Field(default=443, description="AI backend port", alias="backendPort", ge=1, le=65535)
    
    # Path configuration
    path: str = Field(
        default="/v1/chat/completions",
        description="Route path (e.g., /v1/chat/completions, /v1/embeddings)",
    )
    additional_paths: Optional[List[str]] = Field(
        None,
        description="Additional paths to route (e.g., /v1/completions, /v1/models)",
        alias="additionalPaths",
    )
    
    # Hostname
    hostnames: Optional[List[str]] = Field(None, description="Route hostnames for external access")
    
    # Model routing
    model: Optional[str] = Field(
        None,
        description="AI model to route to (added as request header x-ai-model)",
    )
    
    # Timeout
    timeout: Optional[str] = Field(
        default="120s",
        description="Request timeout (AI requests can be slow, default 120s)",
    )
    
    # Metadata
    labels: Optional[Dict[str, str]] = Field(None, description="Route labels")

    class Config:
        populate_by_name = True
        json_schema_extra = {
            "example": {
                "name": "openai-chat-route",
                "targetGateway": "us-envoy-1",
                "backendName": "openai-backend",
                "backendPort": 443,
                "path": "/v1/chat/completions",
                "model": "gpt-4o",
                "timeout": "120s",
            }
        }


class AIRouteResponse(BaseModel):
    """Response for AI route operations."""
    status: str = Field(..., description="Operation status")
    message: str = Field(..., description="Status message")
    route_name: str = Field(..., description="Route name", alias="routeName")
    backend_name: str = Field(..., description="Backend name", alias="backendName")
    namespace: str = Field(..., description="Kubernetes namespace")
    target_gateway: str = Field(..., description="Target gateway", alias="targetGateway")
    path: str = Field(..., description="Route path")
    model: Optional[str] = Field(None, description="AI model")
    details: Optional[Dict[str, Any]] = Field(None, description="Additional details")

    class Config:
        populate_by_name = True


# ==================== AI Token Rate Limiting ====================

class AITokenRateLimitCreate(BaseModel):
    """
    Create token-based rate limiting for AI routes.
    
    Limits AI usage based on token counts (input/output tokens)
    rather than simple request counts.
    """
    name: str = Field(..., description="Policy name", min_length=1, max_length=253)
    target_gateway: str = Field(..., description="Target gateway identifier", alias="targetGateway")
    target_route: str = Field(..., description="Target HTTPRoute name to apply policy to", alias="targetRoute")
    
    # Token-based limits
    input_tokens_per_minute: Optional[int] = Field(
        None,
        description="Max input tokens per minute",
        alias="inputTokensPerMinute",
        ge=1,
    )
    output_tokens_per_minute: Optional[int] = Field(
        None,
        description="Max output tokens per minute",
        alias="outputTokensPerMinute",
        ge=1,
    )
    total_tokens_per_minute: Optional[int] = Field(
        None,
        description="Max total tokens (input + output) per minute",
        alias="totalTokensPerMinute",
        ge=1,
    )
    
    # Request-based limits (fallback)
    requests_per_minute: Optional[int] = Field(
        None,
        description="Max requests per minute (simple rate limit)",
        alias="requestsPerMinute",
        ge=1,
    )
    
    # Metadata
    labels: Optional[Dict[str, str]] = Field(None, description="Policy labels")

    class Config:
        populate_by_name = True
        json_schema_extra = {
            "example": {
                "name": "openai-token-limit",
                "targetGateway": "us-envoy-1",
                "targetRoute": "openai-chat-route",
                "totalTokensPerMinute": 100000,
                "requestsPerMinute": 60,
            }
        }


# ==================== AI Model Routing ====================

class AIModelRouteRule(BaseModel):
    """A single model routing rule mapping a model to a backend."""
    model: str = Field(..., description="Model name to match (e.g., gpt-4o)")
    backend_name: str = Field(..., description="Backend to route to", alias="backendName")
    backend_port: int = Field(default=443, description="Backend port", alias="backendPort", ge=1, le=65535)
    weight: int = Field(default=1, description="Routing weight", ge=0, le=100)

    class Config:
        populate_by_name = True


class AIModelRoutingCreate(BaseModel):
    """
    Create model-based routing for AI requests.
    
    Routes requests to different AI backends based on the model
    specified in the request (via header or body).
    """
    name: str = Field(..., description="Route name", min_length=1, max_length=253)
    target_gateway: str = Field(..., description="Target gateway identifier", alias="targetGateway")
    path: str = Field(default="/v1/chat/completions", description="Base path for AI requests")
    hostnames: Optional[List[str]] = Field(None, description="Route hostnames")
    rules: List[AIModelRouteRule] = Field(
        ...,
        description="Model routing rules",
        min_length=1,
    )
    
    # Default backend (when no model header matches)
    default_backend_name: str = Field(
        ...,
        description="Default backend when no model matches",
        alias="defaultBackendName",
    )
    default_backend_port: int = Field(
        default=443,
        description="Default backend port",
        alias="defaultBackendPort",
        ge=1,
        le=65535,
    )
    
    timeout: Optional[str] = Field(default="120s", description="Request timeout")
    labels: Optional[Dict[str, str]] = Field(None, description="Route labels")

    class Config:
        populate_by_name = True
        json_schema_extra = {
            "example": {
                "name": "ai-model-router",
                "targetGateway": "us-envoy-1",
                "path": "/v1/chat/completions",
                "rules": [
                    {"model": "gpt-4o", "backendName": "openai-backend", "backendPort": 443},
                    {"model": "claude-3.5-sonnet", "backendName": "anthropic-backend", "backendPort": 443},
                ],
                "defaultBackendName": "openai-backend",
                "defaultBackendPort": 443,
            }
        }


# ==================== AI API Key Auth ====================

class AIAPIKeyAuthCreate(BaseModel):
    """
    Create API key authentication for AI routes.
    
    Secures AI endpoints by requiring valid API keys,
    preventing unauthorized access to expensive AI services.
    """
    name: str = Field(..., description="Policy name", min_length=1, max_length=253)
    target_gateway: str = Field(..., description="Target gateway identifier", alias="targetGateway")
    target_route: str = Field(..., description="Target AI route name", alias="targetRoute")
    
    # API key configuration
    api_keys_secret: str = Field(
        ...,
        description="Kubernetes Secret name containing valid API keys",
        alias="apiKeysSecret",
    )
    header_name: str = Field(
        default="x-api-key",
        description="Header name to extract API key from",
        alias="headerName",
    )
    
    labels: Optional[Dict[str, str]] = Field(None, description="Policy labels")

    class Config:
        populate_by_name = True
        json_schema_extra = {
            "example": {
                "name": "ai-api-key-auth",
                "targetGateway": "us-envoy-1",
                "targetRoute": "openai-chat-route",
                "apiKeysSecret": "ai-api-keys",
                "headerName": "x-api-key",
            }
        }
