"""
Backend models for services and Backend resources.
"""

from pydantic import BaseModel, Field, HttpUrl
from typing import Optional, List, Dict, Any
from enum import Enum
from .common import ObjectMeta


class ServiceType(str, Enum):
    """Kubernetes service types."""
    CLUSTER_IP = "ClusterIP"
    EXTERNAL_NAME = "ExternalName"
    NODE_PORT = "NodePort"
    LOAD_BALANCER = "LoadBalancer"


class AppProtocol(str, Enum):
    """Application protocol for backends.
    
    Note: For Envoy Gateway Backend CRD, only these are valid appProtocols:
    - gateway.envoyproxy.io/h2c (HTTP/2 cleartext)
    - gateway.envoyproxy.io/ws (WebSocket)
    - gateway.envoyproxy.io/wss (WebSocket Secure)
    
    For regular HTTPS, do NOT set appProtocols - use TLS config instead.
    """
    # Service appProtocol values (for Kubernetes Services)
    HTTP = "http"
    HTTPS = "https"
    HTTP2 = "kubernetes.io/h2c"
    GRPC = "grpc"
    WS = "ws"
    WSS = "wss"


class EnvoyBackendProtocol(str, Enum):
    """Valid appProtocol values for Envoy Gateway Backend CRD.
    
    For regular HTTP/HTTPS, do NOT set appProtocols.
    Only use these for special protocols.
    """
    H2C = "gateway.envoyproxy.io/h2c"  # HTTP/2 cleartext
    WS = "gateway.envoyproxy.io/ws"    # WebSocket
    WSS = "gateway.envoyproxy.io/wss"  # WebSocket Secure


# ==================== Service ====================

class ServicePort(BaseModel):
    """Service port configuration."""
    name: Optional[str] = Field(None, description="Port name")
    port: int = Field(..., description="Service port", ge=1, le=65535)
    target_port: Optional[int] = Field(None, description="Target port on pods", alias="targetPort", ge=1, le=65535)
    protocol: Optional[str] = Field(default="TCP", description="Protocol (TCP/UDP)")
    app_protocol: Optional[str] = Field(None, description="Application protocol", alias="appProtocol")

    class Config:
        populate_by_name = True


class ServiceSpec(BaseModel):
    """Kubernetes Service specification."""
    type: ServiceType = Field(default=ServiceType.CLUSTER_IP, description="Service type")
    ports: List[ServicePort] = Field(..., description="Service ports", min_length=1)
    selector: Optional[Dict[str, str]] = Field(None, description="Pod selector")
    external_name: Optional[str] = Field(None, description="External hostname (for ExternalName type)", alias="externalName")
    cluster_ip: Optional[str] = Field(None, description="Cluster IP", alias="clusterIP")
    external_ips: Optional[List[str]] = Field(None, description="External IPs", alias="externalIPs")
    session_affinity: Optional[str] = Field(None, description="Session affinity", alias="sessionAffinity")

    class Config:
        populate_by_name = True


class ServiceCreate(BaseModel):
    """Request model for creating a Service."""
    metadata: ObjectMeta = Field(..., description="Service metadata")
    spec: ServiceSpec = Field(..., description="Service specification")


class ServiceUpdate(BaseModel):
    """Request model for updating a Service."""
    spec: ServiceSpec = Field(..., description="Updated Service specification")


class ServiceResponse(BaseModel):
    """Response model for Service operations."""
    api_version: str = Field(default="v1", alias="apiVersion")
    kind: str = Field(default="Service")
    metadata: Dict[str, Any] = Field(..., description="Service metadata")
    spec: Dict[str, Any] = Field(..., description="Service specification")
    status: Optional[Dict[str, Any]] = Field(None, description="Service status")

    class Config:
        populate_by_name = True


# ==================== Backend (Envoy Gateway) ====================

class BackendEndpoint(BaseModel):
    """Backend endpoint configuration."""
    fqdn: Optional[Dict[str, Any]] = Field(None, description="FQDN endpoint")
    ip: Optional[Dict[str, str]] = Field(None, description="IP endpoint")
    unix: Optional[Dict[str, str]] = Field(None, description="Unix socket endpoint")


class BackendTLS(BaseModel):
    """Backend TLS configuration."""
    ca_certificate_refs: Optional[List[Dict[str, str]]] = Field(
        None, description="CA certificate references", alias="caCertificateRefs"
    )
    client_certificate_ref: Optional[Dict[str, str]] = Field(
        None, description="Client certificate reference", alias="clientCertificateRef"
    )

    class Config:
        populate_by_name = True


class BackendSpec(BaseModel):
    """Envoy Gateway Backend specification."""
    endpoints: List[BackendEndpoint] = Field(..., description="Backend endpoints")
    app_protocols: Optional[List[AppProtocol]] = Field(None, description="Application protocols", alias="appProtocols")
    tls: Optional[BackendTLS] = Field(None, description="TLS configuration")

    class Config:
        populate_by_name = True


class BackendCreate(BaseModel):
    """Request model for creating a Backend."""
    metadata: ObjectMeta = Field(..., description="Backend metadata")
    spec: BackendSpec = Field(..., description="Backend specification")


class BackendUpdate(BaseModel):
    """Request model for updating a Backend."""
    spec: BackendSpec = Field(..., description="Updated Backend specification")


class BackendResponse(BaseModel):
    """Response model for Backend operations."""
    api_version: str = Field(default="gateway.envoyproxy.io/v1alpha1", alias="apiVersion")
    kind: str = Field(default="Backend")
    metadata: Dict[str, Any] = Field(..., description="Backend metadata")
    spec: Dict[str, Any] = Field(..., description="Backend specification")
    status: Optional[Dict[str, Any]] = Field(None, description="Backend status")

    class Config:
        populate_by_name = True


# ==================== Simple Backend Creation ====================

class SimpleExternalBackend(BaseModel):
    """Simplified model for creating an external backend service."""
    name: str = Field(..., description="Backend name")
    url: HttpUrl = Field(..., description="External URL")
    port: int = Field(default=80, description="Service port", ge=1, le=65535)
    app_protocol: Optional[AppProtocol] = Field(None, description="Application protocol", alias="appProtocol")

    class Config:
        populate_by_name = True


class SimpleFQDNBackend(BaseModel):
    """Simplified model for creating a Backend with FQDN endpoint."""
    name: str = Field(..., description="Backend name")
    hostname: str = Field(..., description="FQDN hostname")
    port: int = Field(..., description="Port number", ge=1, le=65535)
    app_protocol: Optional[EnvoyBackendProtocol] = Field(
        None, 
        alias="appProtocol",
        description="Application protocol (only h2c/ws/wss). For HTTPS, use TLS config."
    )
    enable_tls: bool = Field(default=True, description="Enable TLS", alias="enableTls")
    ca_secret_name: Optional[str] = Field(None, description="CA certificate secret name", alias="caSecretName")

    class Config:
        populate_by_name = True


# ==================== Enhanced Backend with TLS (no-mTLS and mTLS) ====================

class CACertRefKind(str, Enum):
    """Kind of resource for CA certificate reference."""
    CONFIG_MAP = "ConfigMap"
    SECRET = "Secret"


class CACertificateReference(BaseModel):
    """Reference to a CA certificate for Backend TLS.
    
    For Backend TLS configuration (no-mTLS):
    - group: "" (empty for core resources)
    - kind: "ConfigMap" or "Secret"
    - name: resource name containing ca.crt
    """
    group: str = Field(default="", description="API group (empty for core resources)")
    kind: CACertRefKind = Field(default=CACertRefKind.CONFIG_MAP, description="Resource kind")
    name: str = Field(..., description="Resource name")

    class Config:
        populate_by_name = True


class ClientCertificateReference(BaseModel):
    """Reference to a client certificate Secret for mTLS.
    
    For Backend mTLS configuration:
    - kind: "Secret" (TLS type with tls.crt + tls.key)
    - name: secret name
    """
    kind: str = Field(default="Secret", description="Resource kind (always Secret)")
    name: str = Field(..., description="Secret name containing tls.crt and tls.key")

    class Config:
        populate_by_name = True


class EnhancedBackendTLS(BaseModel):
    """Enhanced TLS configuration for Backend.
    
    Supports two modes:
    
    1. **No mTLS** (server verification only):
       ```yaml
       tls:
         caCertificateRefs:
         - group: ""
           kind: ConfigMap
           name: mule-ca-cert
       ```
       
    2. **mTLS** (mutual TLS - server + client verification):
       ```yaml
       tls:
         caCertificateRefs:
         - group: ""
           kind: ConfigMap
           name: mule-ca-cert
         clientCertificateRef:
           kind: Secret
           name: mule-client-cert
       ```
    """
    ca_certificate_refs: List[CACertificateReference] = Field(
        ..., 
        alias="caCertificateRefs",
        description="CA certificate references for server verification",
        min_length=1
    )
    client_certificate_ref: Optional[ClientCertificateReference] = Field(
        None, 
        alias="clientCertificateRef",
        description="Client certificate reference for mTLS (optional)"
    )

    class Config:
        populate_by_name = True

    def to_spec_dict(self) -> Dict[str, Any]:
        """Convert to Backend spec TLS format."""
        result = {
            "caCertificateRefs": [
                {"group": ref.group, "kind": ref.kind.value, "name": ref.name}
                for ref in self.ca_certificate_refs
            ]
        }
        if self.client_certificate_ref:
            result["clientCertificateRef"] = {
                "kind": self.client_certificate_ref.kind,
                "name": self.client_certificate_ref.name,
            }
        return result


class SimpleFQDNBackendWithTLS(BaseModel):
    """Simplified model for creating a Backend with FQDN endpoint and TLS.
    
    Supports both no-mTLS and mTLS scenarios.
    
    **No mTLS Example:**
    ```json
    {
        "name": "mule-backend",
        "hostname": "mulesoft.example.com",
        "port": 443,
        "caConfigMapName": "mule-ca-cert"
    }
    ```
    
    **mTLS Example:**
    ```json
    {
        "name": "mule-backend",
        "hostname": "mulesoft.example.com",
        "port": 443,
        "caConfigMapName": "mule-ca-cert",
        "clientCertSecretName": "mule-client-cert"
    }
    ```
    """
    name: str = Field(..., description="Backend name")
    hostname: str = Field(..., description="FQDN hostname")
    port: int = Field(..., description="Port number", ge=1, le=65535)
    app_protocol: Optional[EnvoyBackendProtocol] = Field(
        None, 
        alias="appProtocol",
        description="Application protocol (only for h2c/ws/wss). For HTTPS, use TLS config instead."
    )
    
    # TLS Configuration
    ca_configmap_name: Optional[str] = Field(
        None, 
        alias="caConfigMapName",
        description="ConfigMap name containing ca.crt (for server verification)"
    )
    ca_secret_name: Optional[str] = Field(
        None,
        alias="caSecretName", 
        description="Secret name containing ca.crt (alternative to ConfigMap)"
    )
    client_cert_secret_name: Optional[str] = Field(
        None, 
        alias="clientCertSecretName",
        description="Secret name containing tls.crt + tls.key (for mTLS only)"
    )

    class Config:
        populate_by_name = True

    def build_tls_config(self) -> Optional[Dict[str, Any]]:
        """Build TLS configuration for Backend spec.
        
        Returns:
            TLS configuration dict or None if no TLS configured.
        """
        if not self.ca_configmap_name and not self.ca_secret_name:
            return None
        
        tls_config: Dict[str, Any] = {"caCertificateRefs": []}
        
        # Add CA reference (ConfigMap or Secret)
        if self.ca_configmap_name:
            tls_config["caCertificateRefs"].append({
                "group": "",
                "kind": "ConfigMap",
                "name": self.ca_configmap_name,
            })
        elif self.ca_secret_name:
            tls_config["caCertificateRefs"].append({
                "group": "",
                "kind": "Secret",
                "name": self.ca_secret_name,
            })
        
        # Add client cert reference for mTLS
        if self.client_cert_secret_name:
            tls_config["clientCertificateRef"] = {
                "kind": "Secret",
                "name": self.client_cert_secret_name,
            }
        
        return tls_config

    def to_backend_spec(self) -> Dict[str, Any]:
        """Build complete Backend spec.
        
        Returns:
            Backend spec dict ready for Kubernetes API.
        """
        spec: Dict[str, Any] = {
            "endpoints": [
                {
                    "fqdn": {
                        "hostname": self.hostname,
                        "port": self.port,
                    }
                }
            ],
        }
        
        # Only include appProtocols if explicitly provided (h2c, ws, wss)
        # For regular HTTPS, do NOT set appProtocols - use TLS config instead
        if self.app_protocol:
            spec["appProtocols"] = [self.app_protocol.value]
        
        tls_config = self.build_tls_config()
        if tls_config:
            spec["tls"] = tls_config
        
        return spec


# ==================== Backend TLS Config (for API payload) ====================

class BackendTLSPayload(BaseModel):
    """TLS configuration payload for Backend creation.
    
    Supports both no-mTLS (server verification only) and mTLS (mutual TLS).
    
    **No mTLS Example:**
    ```json
    {
        "enabled": true,
        "caSecret": "mule-ca-cert",
        "caKind": "ConfigMap"
    }
    ```
    
    **mTLS Example:**
    ```json
    {
        "enabled": true,
        "caSecret": "mule-ca-cert",
        "caKind": "ConfigMap",
        "clientCertSecret": "mule-client-cert"
    }
    ```
    """
    enabled: bool = Field(default=True, description="Enable TLS")
    ca_secret: str = Field(..., alias="caSecret", description="CA certificate resource name")
    ca_kind: CACertRefKind = Field(
        default=CACertRefKind.CONFIG_MAP, 
        alias="caKind",
        description="CA certificate resource kind (ConfigMap or Secret)"
    )
    client_cert_secret: Optional[str] = Field(
        None, 
        alias="clientCertSecret",
        description="Client certificate Secret name (for mTLS)"
    )
    insecure_skip_verify: bool = Field(
        default=False, 
        alias="insecureSkipVerify",
        description="Skip TLS verification (not recommended for production)"
    )

    class Config:
        populate_by_name = True

    def to_tls_spec(self) -> Optional[Dict[str, Any]]:
        """Convert to Backend TLS spec format."""
        if not self.enabled:
            return None
        
        tls_config: Dict[str, Any] = {
            "caCertificateRefs": [{
                "group": "",
                "kind": self.ca_kind.value,
                "name": self.ca_secret,
            }]
        }
        
        if self.client_cert_secret:
            tls_config["clientCertificateRef"] = {
                "kind": "Secret",
                "name": self.client_cert_secret,
            }
        
        return tls_config


class SimpleBackendCreate(BaseModel):
    """Simplified model for creating a Backend with TLS support.
    
    This model accepts the payload format:
    ```json
    {
        "name": "my-backend",
        "backendUrl": "example.com",
        "backendPort": 443,
        "backendTls": {
            "enabled": true,
            "caSecret": "my-ca-cert",
            "caKind": "ConfigMap"
        }
    }
    ```
    
    Note: For Envoy Gateway Backend CRD, appProtocols only supports:
    - gateway.envoyproxy.io/h2c
    - gateway.envoyproxy.io/ws  
    - gateway.envoyproxy.io/wss
    
    For regular HTTPS, use TLS config instead of appProtocols.
    """
    name: str = Field(..., description="Backend name")
    backend_url: str = Field(..., alias="backendUrl", description="Backend hostname/FQDN")
    backend_port: int = Field(..., alias="backendPort", description="Backend port", ge=1, le=65535)
    app_protocol: Optional[EnvoyBackendProtocol] = Field(
        None, 
        alias="appProtocol",
        description="Application protocol (only for h2c, ws, wss - leave empty for HTTP/HTTPS)"
    )
    backend_tls: Optional[BackendTLSPayload] = Field(
        None, 
        alias="backendTls",
        description="TLS configuration"
    )

    class Config:
        populate_by_name = True

    def to_backend_spec(self) -> Dict[str, Any]:
        """Build complete Backend spec.
        
        Note: appProtocols is only set for special protocols (h2c, ws, wss).
        For regular HTTPS, TLS config is used instead.
        """
        spec: Dict[str, Any] = {
            "endpoints": [{
                "fqdn": {
                    "hostname": self.backend_url,
                    "port": self.backend_port,
                }
            }],
        }
        
        # Only add appProtocols for special protocols (not for regular HTTP/HTTPS)
        if self.app_protocol:
            spec["appProtocols"] = [self.app_protocol.value]
        
        if self.backend_tls:
            tls_spec = self.backend_tls.to_tls_spec()
            if tls_spec:
                spec["tls"] = tls_spec
        
        return spec


