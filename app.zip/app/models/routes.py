"""
Simplified Route models for HTTPRoute, GRPCRoute, TLSRoute, TCPRoute, UDPRoute.
All routes automatically create backends.
"""

from pydantic import BaseModel, Field, HttpUrl
from typing import Optional, List, Dict, Any, Literal
from enum import Enum
from .common import ObjectMeta


class PathMatchType(str, Enum):
    """HTTP path match type."""
    EXACT = "Exact"
    PATH_PREFIX = "PathPrefix"


class HTTPMethodType(str, Enum):
    """HTTP method types."""
    GET = "GET"
    POST = "POST"
    PUT = "PUT"
    DELETE = "DELETE"
    PATCH = "PATCH"
    HEAD = "HEAD"
    OPTIONS = "OPTIONS"


class TargetGateway(str, Enum):
    """Available target gateways."""
    US_ENVOY_1 = "us-envoy-1"
    EU_ENVOY_1 = "eu-envoy-1"
    AP_ENVOY_1 = "ap-envoy-1"


# ==================== Header Modification ====================

class HeaderValue(BaseModel):
    """Header name-value pair."""
    name: str = Field(..., description="Header name")
    value: str = Field(..., description="Header value")


class RequestHeaderModifier(BaseModel):
    """Request header modification configuration."""
    set: Optional[List[HeaderValue]] = Field(None, description="Headers to set (overwrite)")
    add: Optional[List[HeaderValue]] = Field(None, description="Headers to add")
    remove: Optional[List[str]] = Field(None, description="Headers to remove")


class ResponseHeaderModifier(BaseModel):
    """Response header modification configuration."""
    set: Optional[List[HeaderValue]] = Field(None, description="Headers to set (overwrite)")
    add: Optional[List[HeaderValue]] = Field(None, description="Headers to add")
    remove: Optional[List[str]] = Field(None, description="Headers to remove")


# ==================== URL Rewrite Configuration  ====================
# Based on: https://gateway.envoyproxy.io/docs/tasks/traffic/http-urlrewrite/

class HostnameRewriteType(str, Enum):
    """Hostname rewrite type.
    
    Scenarios:
    - Static: Replace with a fixed hostname (simple string)
    - Header: Use value from a request header (requires HTTPRouteFilter CRD)
    - Backend: Use the backend's DNS hostname (requires HTTPRouteFilter CRD)
    """
    STATIC = "Static"
    HEADER = "Header"
    BACKEND = "Backend"


class HostnameRewrite(BaseModel):
    """Hostname rewrite configuration.
    
    **Scenario 1: Static Hostname** (Core Gateway API)
    ```json
    {"type": "Static", "staticValue": "backend.example.com"}
    ```
    
    **Scenario 2: Hostname from Header** (Extended - HTTPRouteFilter)
    ```json
    {"type": "Header", "header": "x-custom-host"}
    ```
    
    **Scenario 3: Backend Hostname** (Extended - HTTPRouteFilter)
    ```json
    {"type": "Backend"}
    ```
    """
    type: HostnameRewriteType = Field(
        default=HostnameRewriteType.STATIC, 
        description="Rewrite type"
    )
    static_value: Optional[str] = Field(
        None, 
        alias="staticValue",
        description="Static hostname (required when type is Static)"
    )
    header: Optional[str] = Field(
        None,
        description="Header name to get hostname from (required when type is Header)"
    )

    class Config:
        populate_by_name = True


class PathRewriteType(str, Enum):
    """Path rewrite type.
    
    Scenarios:
    - ReplacePrefixMatch: Replace path prefix (e.g., /get -> /replace)
    - ReplaceFullPath: Replace entire path (e.g., /get/anything -> /fixed/path)
    - ReplaceRegexMatch: Regex-based rewrite (requires HTTPRouteFilter CRD)
    """
    REPLACE_PREFIX_MATCH = "ReplacePrefixMatch"
    REPLACE_FULL_PATH = "ReplaceFullPath"
    REPLACE_REGEX_MATCH = "ReplaceRegexMatch"


class RegexRewrite(BaseModel):
    """Regex-based path rewrite configuration.
    
    Uses RE2-compatible regex for pattern matching and substitution.
    
    Example: Rewrite /service/foo/v1/api to /v1/api/instance/foo
    ```json
    {
        "pattern": "^/service/([^/]+)(/.*)$",
        "substitution": "\\2/instance/\\1"
    }
    ```
    """
    pattern: str = Field(..., description="RE2-compatible regex pattern")
    substitution: str = Field(..., description="Substitution string (use \\1, \\2 for capture groups)")

    class Config:
        populate_by_name = True


class PathRewrite(BaseModel):
    """Path rewrite configuration.
    
    **Scenario 1: Replace Prefix** (Core Gateway API)
    Rewrite /get/anything to /replace/anything
    ```json
    {"type": "ReplacePrefixMatch", "replacePrefixMatch": "/replace"}
    ```
    
    **Scenario 2: Replace Full Path** (Core Gateway API)
    Rewrite /get/anything to /fixed/path
    ```json
    {"type": "ReplaceFullPath", "replaceFullPath": "/fixed/path"}
    ```
    
    **Scenario 3: Regex Rewrite** (Extended - HTTPRouteFilter)
    Rewrite /service/foo/v1/api to /v1/api/instance/foo
    ```json
    {
        "type": "ReplaceRegexMatch",
        "replaceRegexMatch": {
            "pattern": "^/service/([^/]+)(/.*)$",
            "substitution": "\\2/instance/\\1"
        }
    }
    ```
    """
    type: PathRewriteType = Field(..., description="Path rewrite type")
    replace_prefix_match: Optional[str] = Field(
        None, 
        alias="replacePrefixMatch",
        description="Prefix to replace with (for ReplacePrefixMatch)"
    )
    replace_full_path: Optional[str] = Field(
        None, 
        alias="replaceFullPath",
        description="Full path to replace with (for ReplaceFullPath)"
    )
    replace_regex_match: Optional[RegexRewrite] = Field(
        None,
        alias="replaceRegexMatch",
        description="Regex pattern and substitution (for ReplaceRegexMatch)"
    )

    class Config:
        populate_by_name = True


class URLRewrite(BaseModel):
    """URL rewrite filter configuration (optional).
    
    Supports all Envoy Gateway URL rewrite scenarios:
    https://gateway.envoyproxy.io/docs/tasks/traffic/http-urlrewrite/
    
    **Scenario 1: Rewrite Hostname (Static)**
    ```json
    {
        "hostname": {"type": "Static", "staticValue": "backend.example.com"}
    }
    ```
    
    **Scenario 2: Rewrite Hostname from Header** (creates HTTPRouteFilter)
    ```json
    {
        "hostname": {"type": "Header", "header": "x-custom-host"}
    }
    ```
    
    **Scenario 3: Rewrite Path Prefix**
    ```json
    {
        "path": {"type": "ReplacePrefixMatch", "replacePrefixMatch": "/v2"}
    }
    ```
    
    **Scenario 4: Rewrite Full Path**
    ```json
    {
        "path": {"type": "ReplaceFullPath", "replaceFullPath": "/fixed/path"}
    }
    ```
    
    **Scenario 5: Rewrite Path with Regex** (creates HTTPRouteFilter)
    ```json
    {
        "path": {
            "type": "ReplaceRegexMatch",
            "replaceRegexMatch": {
                "pattern": "^/service/([^/]+)(/.*)$",
                "substitution": "\\2/instance/\\1"
            }
        }
    }
    ```
    
    **Scenario 6: Combined Hostname + Path**
    ```json
    {
        "hostname": {"type": "Static", "staticValue": "api.example.com"},
        "path": {"type": "ReplacePrefixMatch", "replacePrefixMatch": "/v2"}
    }
    ```
    """
    hostname: Optional[HostnameRewrite] = Field(
        None, 
        description="Hostname rewrite configuration"
    )
    path: Optional[PathRewrite] = Field(
        None, 
        description="Path rewrite configuration"
    )

    class Config:
        populate_by_name = True

    def requires_http_route_filter(self) -> bool:
        """Check if this rewrite requires HTTPRouteFilter CRD (extended features)."""
        if self.hostname and self.hostname.type in [HostnameRewriteType.HEADER, HostnameRewriteType.BACKEND]:
            return True
        if self.path and self.path.type == PathRewriteType.REPLACE_REGEX_MATCH:
            return True
        return False

    def to_filter_spec(self) -> Optional[Dict[str, Any]]:
        """Convert to HTTPRoute filter spec format (Core Gateway API).
        
        Returns:
            Filter spec dict or None if no rewrite configured.
            
        Note: For extended features (regex, header-based hostname), 
              use to_http_route_filter_spec() instead.
        """
        if not self.hostname and not self.path:
            return None
        
        # If requires HTTPRouteFilter, return ExtensionRef filter
        if self.requires_http_route_filter():
            return None  # Will be handled separately with HTTPRouteFilter CRD
        
        url_rewrite: Dict[str, Any] = {}
        
        if self.hostname:
            if self.hostname.type == HostnameRewriteType.STATIC and self.hostname.static_value:
                # Simple string hostname (Core Gateway API format)
                url_rewrite["hostname"] = self.hostname.static_value
        
        if self.path:
            path_spec: Dict[str, Any] = {"type": self.path.type.value}
            if self.path.type == PathRewriteType.REPLACE_FULL_PATH and self.path.replace_full_path:
                path_spec["replaceFullPath"] = self.path.replace_full_path
            elif self.path.type == PathRewriteType.REPLACE_PREFIX_MATCH and self.path.replace_prefix_match:
                path_spec["replacePrefixMatch"] = self.path.replace_prefix_match
            url_rewrite["path"] = path_spec
        
        if not url_rewrite:
            return None
            
        return {
            "type": "URLRewrite",
            "urlRewrite": url_rewrite,
        }

    def to_http_route_filter_spec(self) -> Optional[Dict[str, Any]]:
        """Convert to HTTPRouteFilter CRD spec (Extended Envoy Gateway features).
        
        Returns:
            HTTPRouteFilter spec dict for extended features (regex, header hostname).
        """
        if not self.requires_http_route_filter():
            return None
        
        spec: Dict[str, Any] = {"urlRewrite": {}}
        
        if self.hostname:
            if self.hostname.type == HostnameRewriteType.HEADER and self.hostname.header:
                spec["urlRewrite"]["hostname"] = {
                    "type": "Header",
                    "header": self.hostname.header,
                }
            elif self.hostname.type == HostnameRewriteType.BACKEND:
                spec["urlRewrite"]["hostname"] = {
                    "type": "Backend",
                }
        
        if self.path and self.path.type == PathRewriteType.REPLACE_REGEX_MATCH:
            if self.path.replace_regex_match:
                spec["urlRewrite"]["path"] = {
                    "type": "ReplaceRegexMatch",
                    "replaceRegexMatch": {
                        "pattern": self.path.replace_regex_match.pattern,
                        "substitution": self.path.replace_regex_match.substitution,
                    }
                }
        
        return spec

    def get_extension_ref_filter(self, filter_name: str) -> Dict[str, Any]:
        """Get ExtensionRef filter for HTTPRouteFilter CRD.
        
        Args:
            filter_name: Name of the HTTPRouteFilter resource
            
        Returns:
            ExtensionRef filter dict to use in HTTPRoute rules.
        """
        return {
            "type": "ExtensionRef",
            "extensionRef": {
                "group": "gateway.envoyproxy.io",
                "kind": "HTTPRouteFilter",
                "name": filter_name,
            }
        }


# ==================== Backend TLS Configuration ====================

class BackendTLSConfig(BaseModel):
    """TLS configuration for backend connection."""
    enabled: bool = Field(default=False, description="Enable TLS to backend")
    certificate_secret: Optional[str] = Field(
        None, 
        description="Name of TLS secret for client certificate (mTLS)",
        alias="certificateSecret"
    )
    ca_secret: Optional[str] = Field(
        None,
        description="Name of secret containing CA certificate for backend verification",
        alias="caSecret"
    )
    insecure_skip_verify: bool = Field(
        default=False,
        description="Skip TLS certificate verification (not recommended for production)",
        alias="insecureSkipVerify"
    )
    sni: Optional[str] = Field(
        None,
        description="Server Name Indication for TLS handshake"
    )

    class Config:
        populate_by_name = True


# ==================== Simplified Unified Route Model ====================

class SimpleHTTPRouteCreate(BaseModel):
    """
    Request model for creating an HTTPRoute with an existing backend service.
    
    The route will be created in the cluster/namespace determined by the target_gateway.
    
    **With URL Rewrite (optional):**
    ```json
    {
        "name": "users-route",
        "targetGateway": "us-envoy-1",
        "path": "/api/v1/users",
        "backendName": "users-backend",
        "backendPort": 443,
        "urlRewrite": {
            "hostname": {
                "type": "Static",
                "staticValue": "backend.example.com"
            }
        }
    }
    ```
    """
    name: str = Field(..., description="Route name", min_length=1, max_length=253)
    target_gateway: str = Field(..., description="Target gateway identifier", alias="targetGateway")
    path: str = Field(..., description="Route path (e.g., /api/v1/users)")
    backend_name: str = Field(..., description="Existing backend service name", alias="backendName")
    backend_port: int = Field(default=80, description="Backend port", alias="backendPort", ge=1, le=65535)
    path_type: PathMatchType = Field(default=PathMatchType.PATH_PREFIX, alias="pathType")
    hostnames: Optional[List[str]] = Field(None, description="Route hostnames")
    methods: Optional[List[HTTPMethodType]] = Field(None, description="Allowed HTTP methods")
    timeout: Optional[str] = Field(None, description="Request timeout (e.g., '30s')")
    url_rewrite: Optional[URLRewrite] = Field(
        None, 
        alias="urlRewrite",
        description="URL rewrite filter (optional - if not provided, no filter is added)"
    )
    labels: Optional[Dict[str, str]] = Field(None, description="Route labels")

    class Config:
        populate_by_name = True
        json_schema_extra = {
            "example": {
                "name": "users-route",
                "targetGateway": "us-envoy-1",
                "path": "/api/v1/users",
                "backendName": "users-service",
                "backendPort": 9080
            }
        }


class HTTPRouteUpdate(BaseModel):
    """Request model for updating an HTTPRoute."""
    path: Optional[str] = Field(None, description="Route path")
    path_type: Optional[PathMatchType] = Field(None, description="Path match type", alias="pathType")
    backend_url: Optional[str] = Field(None, description="Backend URL", alias="backendUrl")
    backend_port: Optional[int] = Field(None, description="Backend port", alias="backendPort", ge=1, le=65535)
    backend_tls: Optional[BackendTLSConfig] = Field(None, description="Backend TLS config", alias="backendTls")
    hostnames: Optional[List[str]] = Field(None, description="Route hostnames")
    methods: Optional[List[HTTPMethodType]] = Field(None, description="Allowed HTTP methods")
    timeout: Optional[str] = Field(None, description="Request timeout")
    # Header modification
    request_headers_to_add: Optional[List[HeaderValue]] = Field(None, alias="requestHeadersToAdd")
    request_headers_to_set: Optional[List[HeaderValue]] = Field(None, alias="requestHeadersToSet")
    request_headers_to_remove: Optional[List[str]] = Field(None, alias="requestHeadersToRemove")
    response_headers_to_add: Optional[List[HeaderValue]] = Field(None, alias="responseHeadersToAdd")
    response_headers_to_set: Optional[List[HeaderValue]] = Field(None, alias="responseHeadersToSet")
    response_headers_to_remove: Optional[List[str]] = Field(None, alias="responseHeadersToRemove")

    class Config:
        populate_by_name = True


class HTTPRouteResponse(BaseModel):
    """Response model for HTTPRoute creation."""
    status: str = Field(..., description="Operation status")
    message: str = Field(..., description="Status message")
    route_name: str = Field(..., description="Created route name", alias="routeName")
    backend_name: str = Field(..., description="Created backend name", alias="backendName")
    namespace: str = Field(..., description="Kubernetes namespace")
    target_gateway: str = Field(..., description="Target gateway", alias="targetGateway")
    cluster: str = Field(..., description="EKS cluster name")
    region: str = Field(..., description="AWS region")

    class Config:
        populate_by_name = True


class RouteListResponse(BaseModel):
    """Response model for listing routes."""
    items: List[Dict[str, Any]] = Field(..., description="List of routes")
    total: int = Field(..., description="Total count")
    target_gateway: str = Field(..., description="Target gateway", alias="targetGateway")
    namespace: str = Field(..., description="Namespace")

    class Config:
        populate_by_name = True


# ==================== GRPCRoute ====================

class GRPCRouteCreate(BaseModel):
    """Simplified request model for creating a GRPCRoute with backend."""
    name: str = Field(..., description="Route name")
    target_gateway: str = Field(..., description="Target gateway identifier", alias="targetGateway")
    service: Optional[str] = Field(None, description="GRPC service name to match")
    method: Optional[str] = Field(None, description="GRPC method name to match")
    backend_url: str = Field(..., description="Backend URL", alias="backendUrl")
    backend_port: int = Field(default=50051, description="Backend port", alias="backendPort")
    backend_tls: Optional[BackendTLSConfig] = Field(None, description="Backend TLS config", alias="backendTls")
    hostnames: Optional[List[str]] = Field(None, description="Route hostnames")
    labels: Optional[Dict[str, str]] = Field(None, description="Route labels")

    class Config:
        populate_by_name = True


# ==================== TLSRoute ====================

class TLSRouteCreate(BaseModel):
    """Simplified request model for creating a TLSRoute with backend."""
    name: str = Field(..., description="Route name")
    target_gateway: str = Field(..., description="Target gateway identifier", alias="targetGateway")
    hostnames: List[str] = Field(..., description="SNI hostnames to match")
    backend_url: str = Field(..., description="Backend URL", alias="backendUrl")
    backend_port: int = Field(..., description="Backend port", alias="backendPort")
    backend_tls: Optional[BackendTLSConfig] = Field(None, description="Backend TLS config", alias="backendTls")
    labels: Optional[Dict[str, str]] = Field(None, description="Route labels")

    class Config:
        populate_by_name = True


# ==================== TCPRoute ====================

class TCPRouteCreate(BaseModel):
    """Simplified request model for creating a TCPRoute with backend."""
    name: str = Field(..., description="Route name")
    target_gateway: str = Field(..., description="Target gateway identifier", alias="targetGateway")
    backend_url: str = Field(..., description="Backend URL", alias="backendUrl")
    backend_port: int = Field(..., description="Backend port", alias="backendPort")
    backend_tls: Optional[BackendTLSConfig] = Field(None, description="Backend TLS config", alias="backendTls")
    labels: Optional[Dict[str, str]] = Field(None, description="Route labels")

    class Config:
        populate_by_name = True


# ==================== UDPRoute ====================

class UDPRouteCreate(BaseModel):
    """Simplified request model for creating a UDPRoute with backend."""
    name: str = Field(..., description="Route name")
    target_gateway: str = Field(..., description="Target gateway identifier", alias="targetGateway")
    backend_url: str = Field(..., description="Backend URL", alias="backendUrl")
    backend_port: int = Field(..., description="Backend port", alias="backendPort")
    labels: Optional[Dict[str, str]] = Field(None, description="Route labels")

    class Config:
        populate_by_name = True


# ==================== Simple Header Modification ====================

class SimpleHeaderInjection(BaseModel):
    """Simplified header injection for existing route."""
    route_name: str = Field(..., description="Target HTTPRoute name", alias="routeName")
    target_gateway: str = Field(..., description="Target gateway identifier", alias="targetGateway")
    headers_to_add: List[HeaderValue] = Field(..., description="Headers to add", alias="headersToAdd")
    headers_to_set: Optional[List[HeaderValue]] = Field(None, description="Headers to set", alias="headersToSet")
    apply_to: str = Field(default="request", description="Apply to 'request' or 'response'", alias="applyTo")

    class Config:
        populate_by_name = True


class SimpleHeaderRemoval(BaseModel):
    """Simplified header removal for existing route."""
    route_name: str = Field(..., description="Target HTTPRoute name", alias="routeName")
    target_gateway: str = Field(..., description="Target gateway identifier", alias="targetGateway")
    headers_to_remove: List[str] = Field(..., description="Headers to remove", alias="headersToRemove")
    apply_to: str = Field(default="request", description="Apply to 'request' or 'response'", alias="applyTo")

    class Config:
        populate_by_name = True
