"""
Secret models for TLS certificates and credentials.
"""

from pydantic import BaseModel, Field, SecretStr
from typing import Optional, Dict, Any
from enum import Enum
from .common import ObjectMeta


class SecretType(str, Enum):
    """Kubernetes secret types."""
    OPAQUE = "Opaque"
    TLS = "kubernetes.io/tls"
    BASIC_AUTH = "kubernetes.io/basic-auth"
    SSH_AUTH = "kubernetes.io/ssh-auth"
    DOCKER_CONFIG = "kubernetes.io/dockerconfigjson"
    SERVICE_ACCOUNT = "kubernetes.io/service-account-token"


# ==================== TLS Secret ====================

class TLSSecretCreate(BaseModel):
    """Request model for creating a TLS secret."""
    name: str = Field(..., description="Secret name")
    tls_crt: str = Field(..., description="TLS certificate (base64 or PEM)", alias="tlsCrt")
    tls_key: str = Field(..., description="TLS private key (base64 or PEM)", alias="tlsKey")
    ca_crt: Optional[str] = Field(None, description="CA certificate (for mTLS)", alias="caCrt")
    labels: Optional[Dict[str, str]] = Field(None, description="Secret labels")

    class Config:
        populate_by_name = True


class TLSSecretUpdate(BaseModel):
    """Request model for updating a TLS secret."""
    tls_crt: Optional[str] = Field(None, description="TLS certificate", alias="tlsCrt")
    tls_key: Optional[str] = Field(None, description="TLS private key", alias="tlsKey")
    ca_crt: Optional[str] = Field(None, description="CA certificate", alias="caCrt")

    class Config:
        populate_by_name = True


# ==================== Basic Auth Secret ====================

class BasicAuthSecretCreate(BaseModel):
    """Request model for creating a basic auth secret."""
    name: str = Field(..., description="Secret name")
    username: str = Field(..., description="Username")
    password: SecretStr = Field(..., description="Password")
    labels: Optional[Dict[str, str]] = Field(None, description="Secret labels")


class BasicAuthSecretUpdate(BaseModel):
    """Request model for updating a basic auth secret."""
    username: Optional[str] = Field(None, description="Username")
    password: Optional[SecretStr] = Field(None, description="Password")


# ==================== Generic Secret ====================

class GenericSecretCreate(BaseModel):
    """Request model for creating a generic secret."""
    metadata: ObjectMeta = Field(..., description="Secret metadata")
    type: SecretType = Field(default=SecretType.OPAQUE, description="Secret type")
    data: Dict[str, str] = Field(..., description="Secret data (base64 encoded)")
    string_data: Optional[Dict[str, str]] = Field(None, description="String data (will be encoded)", alias="stringData")

    class Config:
        populate_by_name = True


class GenericSecretUpdate(BaseModel):
    """Request model for updating a generic secret."""
    data: Optional[Dict[str, str]] = Field(None, description="Secret data (base64 encoded)")
    string_data: Optional[Dict[str, str]] = Field(None, description="String data", alias="stringData")

    class Config:
        populate_by_name = True


# ==================== OIDC Secret ====================

class OIDCSecretCreate(BaseModel):
    """Request model for creating an OIDC client secret."""
    name: str = Field(..., description="Secret name")
    client_id: str = Field(..., description="OIDC client ID", alias="clientId")
    client_secret: SecretStr = Field(..., description="OIDC client secret", alias="clientSecret")
    labels: Optional[Dict[str, str]] = Field(None, description="Secret labels")

    class Config:
        populate_by_name = True


# ==================== API Key Secret ====================

class APIKeySecretCreate(BaseModel):
    """Request model for creating an API key secret."""
    name: str = Field(..., description="Secret name")
    api_keys: Dict[str, str] = Field(..., description="API keys (name -> key mapping)", alias="apiKeys")
    labels: Optional[Dict[str, str]] = Field(None, description="Secret labels")

    class Config:
        populate_by_name = True


# ==================== Secret Response ====================

class SecretResponse(BaseModel):
    """Response model for Secret operations."""
    api_version: str = Field(default="v1", alias="apiVersion")
    kind: str = Field(default="Secret")
    metadata: Dict[str, Any] = Field(..., description="Secret metadata")
    type: str = Field(..., description="Secret type")
    # Note: data is intentionally not included in response for security

    class Config:
        populate_by_name = True


class SecretListResponse(BaseModel):
    """Response model for listing secrets."""
    items: list[Dict[str, Any]] = Field(..., description="List of secrets (without data)")
    total: int = Field(..., description="Total count")
    namespace: str = Field(..., description="Namespace")
