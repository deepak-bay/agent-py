"""
BackendTrafficPolicy models for rate limiting, circuit breaker, retries, timeouts, etc.
"""

from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any
from enum import Enum
from ..common import TargetRef, ObjectMeta


class RateLimitUnit(str, Enum):
    """Rate limit time unit."""
    SECOND = "Second"
    MINUTE = "Minute"
    HOUR = "Hour"
    DAY = "Day"


class LoadBalancerType(str, Enum):
    """Load balancer algorithm type."""
    ROUND_ROBIN = "RoundRobin"
    RANDOM = "Random"
    LEAST_REQUEST = "LeastRequest"
    CONSISTENT_HASH = "ConsistentHash"


class ConsistentHashType(str, Enum):
    """Consistent hash type."""
    SOURCE_IP = "SourceIP"
    HEADER = "Header"
    COOKIE = "Cookie"


class CircuitBreakerTriggerType(str, Enum):
    """Circuit breaker trigger type."""
    CONSECUTIVE_ERRORS = "ConsecutiveErrors"
    CONSECUTIVE_5XX = "Consecutive5xx"
    CONSECUTIVE_GATEWAY_ERRORS = "ConsecutiveGatewayErrors"
    CONSECUTIVE_LOCAL_ORIGIN_FAILURES = "ConsecutiveLocalOriginFailures"


# ==================== Rate Limiting ====================

class RateLimitValue(BaseModel):
    """Rate limit value configuration."""
    requests: int = Field(..., description="Number of requests", ge=1)
    unit: RateLimitUnit = Field(..., description="Time unit")


class RateLimitHeaderMatch(BaseModel):
    """Rate limit header match configuration."""
    type: str = Field(default="Exact", description="Match type")
    name: str = Field(..., description="Header name")
    value: Optional[str] = Field(None, description="Header value")


class RateLimitClientSelector(BaseModel):
    """Rate limit client selector."""
    headers: Optional[List[RateLimitHeaderMatch]] = Field(None, description="Header selectors")
    source_cidr: Optional[Dict[str, str]] = Field(None, description="Source CIDR selector", alias="sourceCIDR")

    class Config:
        populate_by_name = True


class RateLimitRule(BaseModel):
    """Rate limit rule configuration."""
    client_selectors: Optional[List[RateLimitClientSelector]] = Field(
        None, description="Client selectors", alias="clientSelectors"
    )
    limit: RateLimitValue = Field(..., description="Rate limit value")

    class Config:
        populate_by_name = True


class GlobalRateLimit(BaseModel):
    """Global rate limit configuration."""
    rules: List[RateLimitRule] = Field(..., description="Rate limit rules")


class LocalRateLimit(BaseModel):
    """Local rate limit configuration."""
    rules: List[RateLimitRule] = Field(..., description="Rate limit rules")


class RateLimitConfig(BaseModel):
    """Rate limit configuration."""
    type: str = Field(default="Global", description="Rate limit type (Global/Local)")
    global_: Optional[GlobalRateLimit] = Field(None, description="Global rate limit config", alias="global")
    local: Optional[LocalRateLimit] = Field(None, description="Local rate limit config")

    class Config:
        populate_by_name = True


# ==================== Circuit Breaker ====================

class CircuitBreakerTrigger(BaseModel):
    """Circuit breaker trigger configuration."""
    type: CircuitBreakerTriggerType = Field(..., description="Trigger type")
    threshold: int = Field(default=5, description="Error threshold", ge=1)
    interval: Optional[str] = Field(default="10s", description="Detection interval")


class CircuitBreakerConfig(BaseModel):
    """Circuit breaker configuration."""
    max_connections: Optional[int] = Field(None, description="Max connections", alias="maxConnections", ge=1)
    max_pending_requests: Optional[int] = Field(None, description="Max pending requests", alias="maxPendingRequests", ge=1)
    max_parallel_requests: Optional[int] = Field(None, description="Max parallel requests", alias="maxParallelRequests", ge=1)
    max_parallel_retries: Optional[int] = Field(None, description="Max parallel retries", alias="maxParallelRetries", ge=1)
    max_requests_per_connection: Optional[int] = Field(None, description="Max requests per connection", alias="maxRequestsPerConnection", ge=1)

    class Config:
        populate_by_name = True


# ==================== Load Balancer ====================

class ConsistentHashConfig(BaseModel):
    """Consistent hash configuration."""
    type: ConsistentHashType = Field(..., description="Hash type")
    header: Optional[Dict[str, str]] = Field(None, description="Header config for Header type")
    cookie: Optional[Dict[str, Any]] = Field(None, description="Cookie config for Cookie type")


class LoadBalancerConfig(BaseModel):
    """Load balancer configuration."""
    type: LoadBalancerType = Field(default=LoadBalancerType.ROUND_ROBIN, description="LB algorithm")
    slow_start: Optional[Dict[str, str]] = Field(None, description="Slow start config", alias="slowStart")
    consistent_hash: Optional[ConsistentHashConfig] = Field(None, description="Consistent hash config", alias="consistentHash")

    class Config:
        populate_by_name = True


# ==================== Health Check ====================

class HTTPHealthCheck(BaseModel):
    """HTTP health check configuration."""
    path: str = Field(default="/healthz", description="Health check path")
    method: Optional[str] = Field(default="GET", description="HTTP method")
    expected_statuses: Optional[List[Dict[str, int]]] = Field(
        None, description="Expected status ranges", alias="expectedStatuses"
    )
    expected_response: Optional[Dict[str, Any]] = Field(None, description="Expected response", alias="expectedResponse")

    class Config:
        populate_by_name = True


class TCPHealthCheck(BaseModel):
    """TCP health check configuration."""
    send: Optional[Dict[str, str]] = Field(None, description="Data to send")
    receive: Optional[List[Dict[str, str]]] = Field(None, description="Expected receive data")


class HealthCheckConfig(BaseModel):
    """Health check configuration."""
    timeout: str = Field(default="5s", description="Health check timeout")
    interval: str = Field(default="10s", description="Health check interval")
    unhealthy_threshold: int = Field(default=3, description="Unhealthy threshold", alias="unhealthyThreshold", ge=1)
    healthy_threshold: int = Field(default=1, description="Healthy threshold", alias="healthyThreshold", ge=1)
    http: Optional[HTTPHealthCheck] = Field(None, description="HTTP health check config")
    tcp: Optional[TCPHealthCheck] = Field(None, description="TCP health check config")

    class Config:
        populate_by_name = True


# ==================== Retry ====================

class RetryOnConfig(BaseModel):
    """Retry on configuration."""
    triggers: Optional[List[str]] = Field(
        None, 
        description="Retry triggers (e.g., 'connect-failure', '5xx', 'reset')"
    )
    http_status_codes: Optional[List[int]] = Field(
        None, description="HTTP status codes to retry", alias="httpStatusCodes"
    )

    class Config:
        populate_by_name = True


class RetryConfig(BaseModel):
    """Retry configuration."""
    num_retries: int = Field(default=2, description="Number of retries", alias="numRetries", ge=0)
    retry_on: Optional[RetryOnConfig] = Field(None, description="Retry on config", alias="retryOn")
    per_retry: Optional[Dict[str, str]] = Field(None, description="Per retry config", alias="perRetry")

    class Config:
        populate_by_name = True


# ==================== Timeout ====================

class TimeoutConfig(BaseModel):
    """Timeout configuration."""
    tcp: Optional[Dict[str, str]] = Field(None, description="TCP timeout config")
    http: Optional[Dict[str, str]] = Field(None, description="HTTP timeout config")


# ==================== Connection ====================

class TCPKeepalive(BaseModel):
    """TCP keepalive configuration."""
    probes: Optional[int] = Field(None, description="Keepalive probes", ge=1)
    idle_time: Optional[str] = Field(None, description="Idle time before probes", alias="idleTime")
    interval: Optional[str] = Field(None, description="Probe interval")

    class Config:
        populate_by_name = True


class ConnectionConfig(BaseModel):
    """Connection configuration."""
    buffer_limit: Optional[str] = Field(None, description="Buffer limit", alias="bufferLimit")
    socket_buffer_limit: Optional[str] = Field(None, description="Socket buffer limit", alias="socketBufferLimit")

    class Config:
        populate_by_name = True


# ==================== BackendTrafficPolicy ====================

class BackendTrafficPolicySpec(BaseModel):
    """BackendTrafficPolicy specification."""
    target_ref: TargetRef = Field(..., description="Target reference", alias="targetRef")
    rate_limit: Optional[RateLimitConfig] = Field(None, description="Rate limit config", alias="rateLimit")
    circuit_breaker: Optional[CircuitBreakerConfig] = Field(None, description="Circuit breaker config", alias="circuitBreaker")
    load_balancer: Optional[LoadBalancerConfig] = Field(None, description="Load balancer config", alias="loadBalancer")
    health_check: Optional[HealthCheckConfig] = Field(None, description="Health check config", alias="healthCheck")
    retry: Optional[RetryConfig] = Field(None, description="Retry config")
    timeout: Optional[TimeoutConfig] = Field(None, description="Timeout config")
    connection: Optional[ConnectionConfig] = Field(None, description="Connection config")
    tcp_keepalive: Optional[TCPKeepalive] = Field(None, description="TCP keepalive config", alias="tcpKeepalive")
    use_client_protocol: Optional[bool] = Field(None, description="Use client protocol", alias="useClientProtocol")
    proxy_protocol: Optional[Dict[str, Any]] = Field(None, description="Proxy protocol config", alias="proxyProtocol")

    class Config:
        populate_by_name = True


class BackendTrafficPolicyCreate(BaseModel):
    """Request model for creating a BackendTrafficPolicy."""
    metadata: ObjectMeta = Field(..., description="Policy metadata")
    spec: BackendTrafficPolicySpec = Field(..., description="Policy specification")


class BackendTrafficPolicyUpdate(BaseModel):
    """Request model for updating a BackendTrafficPolicy."""
    spec: BackendTrafficPolicySpec = Field(..., description="Updated policy specification")


class BackendTrafficPolicyResponse(BaseModel):
    """Response model for BackendTrafficPolicy operations."""
    api_version: str = Field(default="gateway.envoyproxy.io/v1alpha1", alias="apiVersion")
    kind: str = Field(default="BackendTrafficPolicy")
    metadata: Dict[str, Any] = Field(..., description="Policy metadata")
    spec: Dict[str, Any] = Field(..., description="Policy specification")
    status: Optional[Dict[str, Any]] = Field(None, description="Policy status")

    class Config:
        populate_by_name = True


# ==================== Simple Policy Creation ====================

class SimpleRateLimitPolicy(BaseModel):
    """Simplified rate limit policy creation. Namespace is derived from targetGateway."""
    name: str = Field(..., description="Policy name")
    target_route: str = Field(..., description="Target HTTPRoute name", alias="targetRoute")
    requests: int = Field(..., description="Number of requests allowed", ge=1)
    unit: RateLimitUnit = Field(default=RateLimitUnit.MINUTE, description="Time unit")

    class Config:
        populate_by_name = True


class SimpleCircuitBreakerPolicy(BaseModel):
    """Simplified circuit breaker policy creation."""
    name: str = Field(..., description="Policy name")
    target_route: str = Field(..., description="Target HTTPRoute name", alias="targetRoute")
    max_connections: int = Field(default=100, description="Max connections", alias="maxConnections", ge=1)
    max_pending_requests: int = Field(default=100, description="Max pending requests", alias="maxPendingRequests", ge=1)
    max_parallel_requests: int = Field(default=100, description="Max parallel requests", alias="maxParallelRequests", ge=1)

    class Config:
        populate_by_name = True


class SimpleRetryPolicy(BaseModel):
    """Simplified retry policy creation."""
    name: str = Field(..., description="Policy name")
    target_route: str = Field(..., description="Target HTTPRoute name", alias="targetRoute")
    num_retries: int = Field(default=3, description="Number of retries", alias="numRetries", ge=0)
    retry_on_5xx: bool = Field(default=True, description="Retry on 5xx errors", alias="retryOn5xx")
    retry_on_connect_failure: bool = Field(default=True, description="Retry on connection failure", alias="retryOnConnectFailure")
    per_retry_timeout: str = Field(default="5s", description="Per retry timeout", alias="perRetryTimeout")

    class Config:
        populate_by_name = True
