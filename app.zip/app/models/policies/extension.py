"""
EnvoyPatchPolicy and EnvoyExtensionPolicy models.
"""

from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any
from enum import Enum
from ..common import TargetRef, ObjectMeta


class PatchType(str, Enum):
    """Envoy patch type."""
    JSON_PATCH = "JSONPatch"


class PatchOperation(str, Enum):
    """JSON patch operation."""
    ADD = "add"
    REMOVE = "remove"
    REPLACE = "replace"
    MOVE = "move"
    COPY = "copy"
    TEST = "test"


class EnvoyResourceType(str, Enum):
    """Envoy resource types that can be patched."""
    LISTENER = "Listener"
    ROUTE_CONFIGURATION = "RouteConfiguration"
    CLUSTER = "Cluster"
    VIRTUAL_HOST = "VirtualHost"
    HTTP_ROUTE = "HTTPRoute"
    ENDPOINT = "Endpoint"


class WasmCodeSource(str, Enum):
    """WASM code source type."""
    HTTP = "HTTP"
    IMAGE = "Image"


# ==================== EnvoyPatchPolicy ====================

class JSONPatchOperation(BaseModel):
    """JSON patch operation configuration."""
    op: PatchOperation = Field(..., description="Patch operation")
    path: str = Field(..., description="JSON path to patch")
    value: Optional[Any] = Field(None, description="Value for add/replace operations")
    from_path: Optional[str] = Field(None, description="Source path for move/copy", alias="from")

    class Config:
        populate_by_name = True


class EnvoyJSONPatch(BaseModel):
    """Envoy JSON patch configuration."""
    type: EnvoyResourceType = Field(..., description="Envoy resource type to patch")
    name: str = Field(..., description="Resource name pattern")
    operation: JSONPatchOperation = Field(..., description="Patch operation")


class EnvoyPatchPolicySpec(BaseModel):
    """EnvoyPatchPolicy specification."""
    target_ref: TargetRef = Field(..., description="Target reference", alias="targetRef")
    type: PatchType = Field(default=PatchType.JSON_PATCH, description="Patch type")
    json_patches: List[EnvoyJSONPatch] = Field(..., description="JSON patches", alias="jsonPatches")
    priority: Optional[int] = Field(None, description="Priority (lower = higher priority)", ge=0)

    class Config:
        populate_by_name = True


class EnvoyPatchPolicyCreate(BaseModel):
    """Request model for creating an EnvoyPatchPolicy."""
    metadata: ObjectMeta = Field(..., description="Policy metadata")
    spec: EnvoyPatchPolicySpec = Field(..., description="Policy specification")


class EnvoyPatchPolicyUpdate(BaseModel):
    """Request model for updating an EnvoyPatchPolicy."""
    spec: EnvoyPatchPolicySpec = Field(..., description="Updated policy specification")


class EnvoyPatchPolicyResponse(BaseModel):
    """Response model for EnvoyPatchPolicy operations."""
    api_version: str = Field(default="gateway.envoyproxy.io/v1alpha1", alias="apiVersion")
    kind: str = Field(default="EnvoyPatchPolicy")
    metadata: Dict[str, Any] = Field(..., description="Policy metadata")
    spec: Dict[str, Any] = Field(..., description="Policy specification")
    status: Optional[Dict[str, Any]] = Field(None, description="Policy status")

    class Config:
        populate_by_name = True


# ==================== EnvoyExtensionPolicy (WASM, Ext Proc) ====================

class WasmHTTPSource(BaseModel):
    """WASM HTTP source configuration."""
    url: str = Field(..., description="HTTP URL to WASM binary")
    sha256: Optional[str] = Field(None, description="SHA256 checksum")


class WasmImageSource(BaseModel):
    """WASM OCI image source configuration."""
    url: str = Field(..., description="OCI image URL")
    sha256: Optional[str] = Field(None, description="SHA256 checksum")
    pull_secret_ref: Optional[Dict[str, str]] = Field(None, description="Image pull secret", alias="pullSecretRef")

    class Config:
        populate_by_name = True


class WasmCode(BaseModel):
    """WASM code configuration."""
    type: WasmCodeSource = Field(..., description="Code source type")
    http: Optional[WasmHTTPSource] = Field(None, description="HTTP source")
    image: Optional[WasmImageSource] = Field(None, description="OCI image source")


class WasmConfig(BaseModel):
    """WASM extension configuration."""
    name: str = Field(..., description="WASM filter name")
    root_id: Optional[str] = Field(None, description="WASM root ID", alias="rootID")
    code: WasmCode = Field(..., description="WASM code source")
    config: Optional[Dict[str, Any]] = Field(None, description="WASM plugin configuration")
    fail_open: Optional[bool] = Field(None, description="Fail open on errors", alias="failOpen")

    class Config:
        populate_by_name = True


class ExtProcBackendRef(BaseModel):
    """External processor backend reference."""
    group: Optional[str] = Field(default="", description="API group")
    kind: Optional[str] = Field(default="Service", description="Kind")
    name: str = Field(..., description="Service name")
    namespace: Optional[str] = Field(None, description="Namespace")
    port: Optional[int] = Field(None, description="Port")


class ExtProcProcessingMode(BaseModel):
    """External processor processing mode."""
    request: Optional[Dict[str, str]] = Field(None, description="Request processing mode")
    response: Optional[Dict[str, str]] = Field(None, description="Response processing mode")


class ExtProcConfig(BaseModel):
    """External processor configuration."""
    backend_refs: List[ExtProcBackendRef] = Field(..., description="Backend references", alias="backendRefs")
    processing_mode: Optional[ExtProcProcessingMode] = Field(
        None, description="Processing mode", alias="processingMode"
    )
    failure_mode: Optional[str] = Field(None, description="Failure mode", alias="failureMode")
    message_timeout: Optional[str] = Field(None, description="Message timeout", alias="messageTimeout")

    class Config:
        populate_by_name = True


class EnvoyExtensionPolicySpec(BaseModel):
    """EnvoyExtensionPolicy specification."""
    target_ref: TargetRef = Field(..., description="Target reference", alias="targetRef")
    wasm: Optional[List[WasmConfig]] = Field(None, description="WASM extensions")
    ext_proc: Optional[List[ExtProcConfig]] = Field(None, description="External processors", alias="extProc")

    class Config:
        populate_by_name = True


class EnvoyExtensionPolicyCreate(BaseModel):
    """Request model for creating an EnvoyExtensionPolicy."""
    metadata: ObjectMeta = Field(..., description="Policy metadata")
    spec: EnvoyExtensionPolicySpec = Field(..., description="Policy specification")


class EnvoyExtensionPolicyUpdate(BaseModel):
    """Request model for updating an EnvoyExtensionPolicy."""
    spec: EnvoyExtensionPolicySpec = Field(..., description="Updated policy specification")


class EnvoyExtensionPolicyResponse(BaseModel):
    """Response model for EnvoyExtensionPolicy operations."""
    api_version: str = Field(default="gateway.envoyproxy.io/v1alpha1", alias="apiVersion")
    kind: str = Field(default="EnvoyExtensionPolicy")
    metadata: Dict[str, Any] = Field(..., description="Policy metadata")
    spec: Dict[str, Any] = Field(..., description="Policy specification")
    status: Optional[Dict[str, Any]] = Field(None, description="Policy status")

    class Config:
        populate_by_name = True


# ==================== Simple Extension Creation ====================

class SimpleWasmExtension(BaseModel):
    """Simplified WASM extension creation."""
    name: str = Field(..., description="Extension policy name")
    target_route: str = Field(..., description="Target HTTPRoute name", alias="targetRoute")
    wasm_name: str = Field(..., description="WASM filter name", alias="wasmName")
    wasm_url: str = Field(..., description="WASM binary URL (HTTP or OCI)", alias="wasmUrl")
    wasm_config: Optional[Dict[str, Any]] = Field(None, description="WASM plugin configuration", alias="wasmConfig")
    fail_open: bool = Field(default=False, description="Fail open on errors", alias="failOpen")

    class Config:
        populate_by_name = True


class SimpleExtProcExtension(BaseModel):
    """Simplified external processor extension creation."""
    name: str = Field(..., description="Extension policy name")
    target_route: str = Field(..., description="Target HTTPRoute name", alias="targetRoute")
    service_name: str = Field(..., description="External processor service name", alias="serviceName")
    service_port: int = Field(default=9001, description="Service port", alias="servicePort")
    process_request_headers: bool = Field(default=True, description="Process request headers", alias="processRequestHeaders")
    process_request_body: bool = Field(default=False, description="Process request body", alias="processRequestBody")
    process_response_headers: bool = Field(default=False, description="Process response headers", alias="processResponseHeaders")
    process_response_body: bool = Field(default=False, description="Process response body", alias="processResponseBody")
    failure_mode: str = Field(default="FailClosed", description="Failure mode", alias="failureMode")

    class Config:
        populate_by_name = True
