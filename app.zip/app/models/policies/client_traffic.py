"""
ClientTrafficPolicy models for client-side traffic settings.
"""

from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any
from enum import Enum
from ..common import TargetRef, ObjectMeta


class HTTP1CodecType(str, Enum):
    """HTTP/1 codec settings."""
    HTTP1 = "HTTP1"
    HTTP1_1 = "HTTP1.1"


class HTTP2CodecType(str, Enum):
    """HTTP/2 codec settings."""
    HTTP2 = "HTTP2"
    H2C = "H2C"


class TLSMinVersion(str, Enum):
    """Minimum TLS version."""
    TLS_1_0 = "1.0"
    TLS_1_1 = "1.1"
    TLS_1_2 = "1.2"
    TLS_1_3 = "1.3"


class TLSMaxVersion(str, Enum):
    """Maximum TLS version."""
    TLS_1_2 = "1.2"
    TLS_1_3 = "1.3"


class ALPNProtocol(str, Enum):
    """ALPN protocol."""
    HTTP_1_0 = "http/1.0"
    HTTP_1_1 = "http/1.1"
    H2 = "h2"


# ==================== Client TLS ====================

class ClientTLSConfig(BaseModel):
    """Client TLS configuration."""
    min_version: Optional[TLSMinVersion] = Field(None, description="Minimum TLS version", alias="minVersion")
    max_version: Optional[TLSMaxVersion] = Field(None, description="Maximum TLS version", alias="maxVersion")
    ciphers: Optional[List[str]] = Field(None, description="TLS cipher suites")
    alpn_protocols: Optional[List[ALPNProtocol]] = Field(None, description="ALPN protocols", alias="alpnProtocols")
    ecdh_curves: Optional[List[str]] = Field(None, description="ECDH curves", alias="ecdhCurves")
    signature_algorithms: Optional[List[str]] = Field(None, description="Signature algorithms", alias="signatureAlgorithms")

    class Config:
        populate_by_name = True


# ==================== HTTP Settings ====================

class HTTP1Settings(BaseModel):
    """HTTP/1 protocol settings."""
    enable_trailers: Optional[bool] = Field(None, description="Enable trailers", alias="enableTrailers")
    preserve_header_case: Optional[bool] = Field(None, description="Preserve header case", alias="preserveHeaderCase")
    http10: Optional[Dict[str, Any]] = Field(None, description="HTTP/1.0 settings")

    class Config:
        populate_by_name = True


class HTTP2Settings(BaseModel):
    """HTTP/2 protocol settings."""
    initial_stream_window_size: Optional[str] = Field(
        None, description="Initial stream window size", alias="initialStreamWindowSize"
    )
    initial_connection_window_size: Optional[str] = Field(
        None, description="Initial connection window size", alias="initialConnectionWindowSize"
    )
    max_concurrent_streams: Optional[int] = Field(
        None, description="Max concurrent streams", alias="maxConcurrentStreams", ge=1
    )
    on_invalid_message: Optional[str] = Field(None, description="Behavior on invalid message", alias="onInvalidMessage")

    class Config:
        populate_by_name = True


class HTTPSettings(BaseModel):
    """HTTP protocol settings."""
    http1: Optional[HTTP1Settings] = Field(None, description="HTTP/1 settings")
    http2: Optional[HTTP2Settings] = Field(None, description="HTTP/2 settings")


# ==================== Timeout Settings ====================

class TCPTimeoutConfig(BaseModel):
    """TCP timeout configuration."""
    connect_timeout: Optional[str] = Field(None, description="Connection timeout", alias="connectTimeout")

    class Config:
        populate_by_name = True


class HTTPTimeoutConfig(BaseModel):
    """HTTP timeout configuration."""
    request_received_timeout: Optional[str] = Field(
        None, description="Request received timeout", alias="requestReceivedTimeout"
    )
    idle_timeout: Optional[str] = Field(None, description="Idle timeout", alias="idleTimeout")

    class Config:
        populate_by_name = True


class ClientTimeoutConfig(BaseModel):
    """Client timeout configuration."""
    tcp: Optional[TCPTimeoutConfig] = Field(None, description="TCP timeout config")
    http: Optional[HTTPTimeoutConfig] = Field(None, description="HTTP timeout config")


# ==================== Connection Settings ====================

class ClientConnectionConfig(BaseModel):
    """Client connection configuration."""
    connection_limit: Optional[Dict[str, Any]] = Field(None, description="Connection limit", alias="connectionLimit")
    buffer_limit: Optional[str] = Field(None, description="Buffer limit", alias="bufferLimit")

    class Config:
        populate_by_name = True


# ==================== TCP Keepalive ====================

class ClientTCPKeepalive(BaseModel):
    """Client TCP keepalive configuration."""
    probes: Optional[int] = Field(None, description="Keepalive probes", ge=1)
    idle_time: Optional[str] = Field(None, description="Idle time before probes", alias="idleTime")
    interval: Optional[str] = Field(None, description="Probe interval")

    class Config:
        populate_by_name = True


# ==================== Header Settings ====================

class HeaderSettings(BaseModel):
    """Header handling settings."""
    enable_envoy_headers: Optional[bool] = Field(None, description="Enable Envoy headers", alias="enableEnvoyHeaders")
    disable_rate_limit_headers: Optional[bool] = Field(
        None, description="Disable rate limit headers", alias="disableRateLimitHeaders"
    )
    xff_num_trusted_hops: Optional[int] = Field(None, description="XFF trusted hops", alias="xffNumTrustedHops", ge=0)
    preserve_xff: Optional[bool] = Field(None, description="Preserve X-Forwarded-For", alias="preserveXFF")
    with_underscore_action: Optional[str] = Field(
        None, description="Headers with underscore action", alias="withUnderscoresAction"
    )

    class Config:
        populate_by_name = True


# ==================== IP Detection ====================

class ClientIPDetection(BaseModel):
    """Client IP detection configuration."""
    xff: Optional[Dict[str, Any]] = Field(None, description="XFF-based detection")
    custom_header: Optional[Dict[str, str]] = Field(None, description="Custom header detection", alias="customHeader")

    class Config:
        populate_by_name = True


# ==================== Path Settings ====================

class PathSettings(BaseModel):
    """Path handling settings."""
    escaped_slashes_action: Optional[str] = Field(
        None, description="Escaped slashes handling", alias="escapedSlashesAction"
    )
    disable_merge_slashes: Optional[bool] = Field(None, description="Disable merge slashes", alias="disableMergeSlashes")

    class Config:
        populate_by_name = True


# ==================== ClientTrafficPolicy ====================

class ClientTrafficPolicySpec(BaseModel):
    """ClientTrafficPolicy specification."""
    target_ref: TargetRef = Field(..., description="Target reference", alias="targetRef")
    tls: Optional[ClientTLSConfig] = Field(None, description="TLS configuration")
    http: Optional[HTTPSettings] = Field(None, description="HTTP settings")
    timeout: Optional[ClientTimeoutConfig] = Field(None, description="Timeout configuration")
    connection: Optional[ClientConnectionConfig] = Field(None, description="Connection configuration")
    tcp_keepalive: Optional[ClientTCPKeepalive] = Field(None, description="TCP keepalive config", alias="tcpKeepalive")
    headers: Optional[HeaderSettings] = Field(None, description="Header settings")
    client_ip_detection: Optional[ClientIPDetection] = Field(
        None, description="Client IP detection", alias="clientIPDetection"
    )
    path: Optional[PathSettings] = Field(None, description="Path settings")
    enable_proxy_protocol: Optional[bool] = Field(None, description="Enable proxy protocol", alias="enableProxyProtocol")

    class Config:
        populate_by_name = True


class ClientTrafficPolicyCreate(BaseModel):
    """Request model for creating a ClientTrafficPolicy."""
    metadata: ObjectMeta = Field(..., description="Policy metadata")
    spec: ClientTrafficPolicySpec = Field(..., description="Policy specification")


class ClientTrafficPolicyUpdate(BaseModel):
    """Request model for updating a ClientTrafficPolicy."""
    spec: ClientTrafficPolicySpec = Field(..., description="Updated policy specification")


class ClientTrafficPolicyResponse(BaseModel):
    """Response model for ClientTrafficPolicy operations."""
    api_version: str = Field(default="gateway.envoyproxy.io/v1alpha1", alias="apiVersion")
    kind: str = Field(default="ClientTrafficPolicy")
    metadata: Dict[str, Any] = Field(..., description="Policy metadata")
    spec: Dict[str, Any] = Field(..., description="Policy specification")
    status: Optional[Dict[str, Any]] = Field(None, description="Policy status")

    class Config:
        populate_by_name = True


# ==================== Simple Policy Creation ====================

class SimpleTLSPolicy(BaseModel):
    """Simplified TLS policy for client connections."""
    name: str = Field(..., description="Policy name")
    target_gateway: str = Field(..., description="Target Gateway name", alias="targetGateway")
    min_version: TLSMinVersion = Field(default=TLSMinVersion.TLS_1_2, description="Min TLS version", alias="minVersion")
    max_version: TLSMaxVersion = Field(default=TLSMaxVersion.TLS_1_3, description="Max TLS version", alias="maxVersion")
    ciphers: Optional[List[str]] = Field(None, description="Allowed cipher suites")

    class Config:
        populate_by_name = True


class SimpleTimeoutPolicy(BaseModel):
    """Simplified timeout policy."""
    name: str = Field(..., description="Policy name")
    target_gateway: str = Field(..., description="Target Gateway name", alias="targetGateway")
    connect_timeout: str = Field(default="10s", description="Connection timeout", alias="connectTimeout")
    request_timeout: str = Field(default="60s", description="Request timeout", alias="requestTimeout")
    idle_timeout: str = Field(default="300s", description="Idle timeout", alias="idleTimeout")

    class Config:
        populate_by_name = True


class SimpleHTTP2Policy(BaseModel):
    """Simplified HTTP/2 policy."""
    name: str = Field(..., description="Policy name")
    target_gateway: str = Field(..., description="Target Gateway name", alias="targetGateway")
    max_concurrent_streams: int = Field(default=100, description="Max concurrent streams", alias="maxConcurrentStreams", ge=1)
    initial_stream_window_size: str = Field(
        default="65536", description="Initial stream window size", alias="initialStreamWindowSize"
    )
    initial_connection_window_size: str = Field(
        default="1048576", description="Initial connection window size", alias="initialConnectionWindowSize"
    )

    class Config:
        populate_by_name = True
