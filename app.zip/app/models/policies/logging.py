"""
Access Logging policy models for Envoy Gateway.
"""

from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any
from enum import Enum
from ..common import ObjectMeta


class LogSinkType(str, Enum):
    """Log sink type."""
    FILE = "File"
    OPEN_TELEMETRY = "OpenTelemetry"
    ALS = "ALS"  # Access Log Service


class LogFormatType(str, Enum):
    """Log format type."""
    TEXT = "Text"
    JSON = "JSON"


class AccessLogType(str, Enum):
    """Access log type."""
    HTTP = "HTTP"
    TCP = "TCP"


# ==================== File Sink ====================

class FileSink(BaseModel):
    """File sink configuration."""
    path: str = Field(..., description="File path for logs (e.g., '/dev/stdout')")


# ==================== OpenTelemetry Sink ====================

class OpenTelemetrySink(BaseModel):
    """OpenTelemetry sink configuration."""
    host: str = Field(..., description="OTLP collector host")
    port: int = Field(default=4317, description="OTLP collector port")
    resources: Optional[Dict[str, str]] = Field(None, description="Resource attributes")


# ==================== ALS Sink ====================

class ALSBackendRef(BaseModel):
    """ALS backend reference."""
    name: str = Field(..., description="Service name")
    namespace: Optional[str] = Field(None, description="Service namespace")
    port: int = Field(..., description="Service port")


class ALSSink(BaseModel):
    """Access Log Service sink configuration."""
    backend_refs: List[ALSBackendRef] = Field(..., description="Backend references", alias="backendRefs")
    log_name: Optional[str] = Field(None, description="Log name", alias="logName")
    type: AccessLogType = Field(default=AccessLogType.HTTP, description="Log type (HTTP/TCP)")

    class Config:
        populate_by_name = True


# ==================== Log Format ====================

class TextLogFormat(BaseModel):
    """Text log format configuration."""
    text: str = Field(
        default='[%START_TIME%] "%REQ(:METHOD)% %REQ(X-ENVOY-ORIGINAL-PATH?:PATH)% %PROTOCOL%" %RESPONSE_CODE% %RESPONSE_FLAGS% %BYTES_RECEIVED% %BYTES_SENT% %DURATION% "%REQ(X-FORWARDED-FOR)%" "%REQ(USER-AGENT)%" "%REQ(X-REQUEST-ID)%" "%REQ(:AUTHORITY)%" "%UPSTREAM_HOST%"',
        description="Text format template"
    )


class JSONLogFormat(BaseModel):
    """JSON log format configuration."""
    json_format: Dict[str, str] = Field(
        default={
            "start_time": "%START_TIME%",
            "method": "%REQ(:METHOD)%",
            "path": "%REQ(X-ENVOY-ORIGINAL-PATH?:PATH)%",
            "protocol": "%PROTOCOL%",
            "response_code": "%RESPONSE_CODE%",
            "response_flags": "%RESPONSE_FLAGS%",
            "bytes_received": "%BYTES_RECEIVED%",
            "bytes_sent": "%BYTES_SENT%",
            "duration": "%DURATION%",
            "upstream_host": "%UPSTREAM_HOST%",
            "x_forwarded_for": "%REQ(X-FORWARDED-FOR)%",
            "user_agent": "%REQ(USER-AGENT)%",
            "request_id": "%REQ(X-REQUEST-ID)%",
            "authority": "%REQ(:AUTHORITY)%",
        },
        description="JSON format mapping",
        alias="json"
    )
    
    class Config:
        populate_by_name = True


# ==================== Access Log Settings ====================

class AccessLogSink(BaseModel):
    """Access log sink configuration."""
    type: LogSinkType = Field(..., description="Sink type")
    file: Optional[FileSink] = Field(None, description="File sink config")
    open_telemetry: Optional[OpenTelemetrySink] = Field(None, description="OpenTelemetry sink", alias="openTelemetry")
    als: Optional[ALSSink] = Field(None, description="ALS sink")

    class Config:
        populate_by_name = True


class AccessLogSettings(BaseModel):
    """Access log settings configuration."""
    disable: bool = Field(default=False, description="Disable access logging")
    sinks: Optional[List[AccessLogSink]] = Field(None, description="Log sinks")
    text: Optional[TextLogFormat] = Field(None, description="Text format config")
    json_format: Optional[JSONLogFormat] = Field(None, description="JSON format config", alias="json")
    
    class Config:
        populate_by_name = True


# ==================== EnvoyProxy Telemetry ====================

class TelemetryAccessLog(BaseModel):
    """Telemetry access log configuration."""
    disable: bool = Field(default=False, description="Disable access logging")
    settings: Optional[List[AccessLogSettings]] = Field(None, description="Access log settings")


class TelemetryMetrics(BaseModel):
    """Telemetry metrics configuration."""
    disable: bool = Field(default=False, description="Disable metrics")
    sinks: Optional[List[Dict[str, Any]]] = Field(None, description="Metrics sinks")
    enable_virtual_host_stats: bool = Field(default=False, description="Enable virtual host stats", alias="enableVirtualHostStats")

    class Config:
        populate_by_name = True


class TelemetryTracing(BaseModel):
    """Telemetry tracing configuration."""
    sampling_rate: Optional[float] = Field(None, description="Sampling rate (0-100)", alias="samplingRate", ge=0, le=100)
    provider: Optional[Dict[str, Any]] = Field(None, description="Tracing provider config")

    class Config:
        populate_by_name = True


class TelemetryConfig(BaseModel):
    """Telemetry configuration."""
    access_log: Optional[TelemetryAccessLog] = Field(None, description="Access log config", alias="accessLog")
    metrics: Optional[TelemetryMetrics] = Field(None, description="Metrics config")
    tracing: Optional[TelemetryTracing] = Field(None, description="Tracing config")

    class Config:
        populate_by_name = True


# ==================== EnvoyProxy Configuration ====================

class EnvoyProxySpec(BaseModel):
    """EnvoyProxy specification for logging configuration."""
    telemetry: Optional[TelemetryConfig] = Field(None, description="Telemetry configuration")
    merge_gateways: Optional[bool] = Field(None, description="Merge gateways", alias="mergeGateways")
    shutdown: Optional[Dict[str, Any]] = Field(None, description="Shutdown config")
    provider: Optional[Dict[str, Any]] = Field(None, description="Infrastructure provider config")

    class Config:
        populate_by_name = True


class EnvoyProxyCreate(BaseModel):
    """Request model for creating EnvoyProxy configuration."""
    metadata: ObjectMeta = Field(..., description="EnvoyProxy metadata")
    spec: EnvoyProxySpec = Field(..., description="EnvoyProxy specification")


class EnvoyProxyResponse(BaseModel):
    """Response model for EnvoyProxy."""
    api_version: str = Field(default="gateway.envoyproxy.io/v1alpha1", alias="apiVersion")
    kind: str = Field(default="EnvoyProxy")
    metadata: Dict[str, Any] = Field(..., description="EnvoyProxy metadata")
    spec: Dict[str, Any] = Field(..., description="EnvoyProxy specification")

    class Config:
        populate_by_name = True


# ==================== Simple Logging Configuration ====================

class SimpleAccessLogConfig(BaseModel):
    """Simplified access logging configuration."""
    name: str = Field(..., description="EnvoyProxy config name")
    enabled: bool = Field(default=True, description="Enable access logging")
    format: LogFormatType = Field(default=LogFormatType.JSON, description="Log format")
    output: str = Field(default="/dev/stdout", description="Output path (e.g., '/dev/stdout', '/var/log/envoy/access.log')")
    include_headers: Optional[List[str]] = Field(None, description="Headers to include in logs", alias="includeHeaders")

    class Config:
        populate_by_name = True


class SimpleOTLPLoggingConfig(BaseModel):
    """Simplified OpenTelemetry logging configuration."""
    name: str = Field(..., description="EnvoyProxy config name")
    otlp_host: str = Field(..., description="OTLP collector host", alias="otlpHost")
    otlp_port: int = Field(default=4317, description="OTLP collector port", alias="otlpPort")
    service_name: str = Field(default="envoy-gateway", description="Service name for logs", alias="serviceName")

    class Config:
        populate_by_name = True
