"""
SecurityPolicy models for JWT, OIDC, Basic Auth, External Auth, CORS, API Keys, IP Filtering.
"""

from pydantic import BaseModel, Field, HttpUrl
from typing import Optional, List, Dict, Any
from enum import Enum
from ..common import TargetRef, ObjectMeta, SecretObjectReference


class ExtAuthFailureMode(str, Enum):
    """External auth failure mode."""
    FAIL_OPEN = "FailOpen"
    FAIL_CLOSED = "FailClosed"


class ExtAuthProtocol(str, Enum):
    """External auth protocol."""
    GRPC = "GRPC"
    HTTP = "HTTP"


class AuthorizationAction(str, Enum):
    """Authorization action."""
    ALLOW = "Allow"
    DENY = "Deny"


# ==================== JWT Authentication ====================

class JWTClaimToHeader(BaseModel):
    """JWT claim to header mapping."""
    claim: str = Field(..., description="JWT claim name")
    header: str = Field(..., description="Header name to set")


class JWTProvider(BaseModel):
    """JWT provider configuration."""
    name: str = Field(..., description="JWT provider name (required by Envoy Gateway CRD)")
    issuer: str = Field(..., description="JWT issuer (iss claim)")
    audiences: Optional[List[str]] = Field(None, description="Allowed audiences")
    remote_jwks: Optional[Dict[str, Any]] = Field(None, description="Remote JWKS configuration", alias="remoteJWKS")
    local_jwks: Optional[Dict[str, str]] = Field(None, description="Local JWKS configuration", alias="localJWKS")
    claim_to_headers: Optional[List[JWTClaimToHeader]] = Field(
        None, description="Claims to extract to headers", alias="claimToHeaders"
    )
    extract_from: Optional[Dict[str, Any]] = Field(None, description="Token extraction config", alias="extractFrom")
    recompute_route: Optional[bool] = Field(None, description="Recompute route after validation", alias="recomputeRoute")

    class Config:
        populate_by_name = True


class JWTConfig(BaseModel):
    """JWT authentication configuration."""
    providers: List[JWTProvider] = Field(..., description="JWT providers")


# ==================== OIDC Authentication ====================

class OIDCProvider(BaseModel):
    """OIDC provider configuration."""
    issuer: HttpUrl = Field(..., description="OIDC issuer URL")
    authorization_endpoint: Optional[str] = Field(None, description="Authorization endpoint", alias="authorizationEndpoint")
    token_endpoint: Optional[str] = Field(None, description="Token endpoint", alias="tokenEndpoint")
    client_id: str = Field(..., description="OIDC client ID", alias="clientID")
    client_secret: SecretObjectReference = Field(..., description="Client secret reference", alias="clientSecret")
    scopes: Optional[List[str]] = Field(None, description="OIDC scopes")
    redirect_url: Optional[str] = Field(None, description="Redirect URL", alias="redirectURL")
    logout_path: Optional[str] = Field(None, description="Logout path", alias="logoutPath")
    forward_access_token: Optional[bool] = Field(None, description="Forward access token", alias="forwardAccessToken")
    default_token_ttl: Optional[str] = Field(None, description="Default token TTL", alias="defaultTokenTTL")
    refresh_token: Optional[bool] = Field(None, description="Enable refresh token", alias="refreshToken")

    class Config:
        populate_by_name = True


class OIDCConfig(BaseModel):
    """OIDC authentication configuration."""
    provider: OIDCProvider = Field(..., description="OIDC provider configuration")


# ==================== Basic Auth ====================

class BasicAuthConfig(BaseModel):
    """Basic authentication configuration."""
    users: SecretObjectReference = Field(..., description="Users secret reference (htpasswd format)")


# ==================== External Auth ====================

class ExtAuthHTTP(BaseModel):
    """HTTP external auth configuration."""
    backend_ref: Dict[str, Any] = Field(..., description="Backend service reference", alias="backendRef")
    backend_refs: Optional[List[Dict[str, Any]]] = Field(None, description="Multiple backend refs", alias="backendRefs")
    path: Optional[str] = Field(None, description="Auth path")
    headers_to_backend: Optional[List[str]] = Field(None, description="Headers to forward", alias="headersToBackend")

    class Config:
        populate_by_name = True


class ExtAuthGRPC(BaseModel):
    """GRPC external auth configuration."""
    backend_ref: Dict[str, Any] = Field(..., description="Backend service reference", alias="backendRef")
    backend_refs: Optional[List[Dict[str, Any]]] = Field(None, description="Multiple backend refs", alias="backendRefs")

    class Config:
        populate_by_name = True


class ExtAuthConfig(BaseModel):
    """External authentication configuration."""
    http: Optional[ExtAuthHTTP] = Field(None, description="HTTP auth service config")
    grpc: Optional[ExtAuthGRPC] = Field(None, description="GRPC auth service config")
    headers_to_ext_auth: Optional[List[str]] = Field(None, description="Headers to send", alias="headersToExtAuth")
    failure_mode: ExtAuthFailureMode = Field(
        default=ExtAuthFailureMode.FAIL_CLOSED, description="Failure mode", alias="failureMode"
    )

    class Config:
        populate_by_name = True


# ==================== CORS ====================

class CORSConfig(BaseModel):
    """CORS configuration."""
    allow_origins: Optional[List[str]] = Field(None, description="Allowed origins (list of origin strings)", alias="allowOrigins")
    allow_methods: Optional[List[str]] = Field(None, description="Allowed methods", alias="allowMethods")
    allow_headers: Optional[List[str]] = Field(None, description="Allowed headers", alias="allowHeaders")
    expose_headers: Optional[List[str]] = Field(None, description="Exposed headers", alias="exposeHeaders")
    max_age: Optional[str] = Field(None, description="Max age (e.g., '24h')", alias="maxAge")
    allow_credentials: Optional[bool] = Field(None, description="Allow credentials", alias="allowCredentials")

    class Config:
        populate_by_name = True


# ==================== API Keys ====================

class APIKeySource(BaseModel):
    """API key extraction source."""
    headers: Optional[List[str]] = Field(None, description="Headers to check for API key")
    params: Optional[List[str]] = Field(None, description="Query params to check for API key")
    cookies: Optional[List[str]] = Field(None, description="Cookies to check for API key")


class APIKeyConfig(BaseModel):
    """API key authentication configuration."""
    extract_from: APIKeySource = Field(..., description="Where to extract API key from", alias="extractFrom")
    credentials: List[SecretObjectReference] = Field(..., description="Secret references containing API keys")

    class Config:
        populate_by_name = True


# ==================== Authorization (IP Filtering) ====================

class PrincipalMatch(BaseModel):
    """Principal matching configuration."""
    client_cidrs: Optional[List[str]] = Field(None, description="Client CIDR ranges (e.g., ['10.0.0.0/8', '192.168.1.0/24'])", alias="clientCIDRs")

    class Config:
        populate_by_name = True


class AuthorizationRule(BaseModel):
    """Authorization rule configuration."""
    name: Optional[str] = Field(None, description="Rule name")
    action: AuthorizationAction = Field(default=AuthorizationAction.ALLOW, description="Action (Allow/Deny)")
    principal: PrincipalMatch = Field(..., description="Principal matcher")


class AuthorizationConfig(BaseModel):
    """Authorization configuration for IP filtering."""
    default_action: AuthorizationAction = Field(default=AuthorizationAction.DENY, description="Default action", alias="defaultAction")
    rules: List[AuthorizationRule] = Field(..., description="Authorization rules")

    class Config:
        populate_by_name = True


# ==================== SecurityPolicy ====================

class SecurityPolicySpec(BaseModel):
    """SecurityPolicy specification."""
    target_ref: TargetRef = Field(..., description="Target reference", alias="targetRef")
    jwt: Optional[JWTConfig] = Field(None, description="JWT authentication config")
    oidc: Optional[OIDCConfig] = Field(None, description="OIDC authentication config")
    basic_auth: Optional[BasicAuthConfig] = Field(None, description="Basic auth config", alias="basicAuth")
    ext_auth: Optional[ExtAuthConfig] = Field(None, description="External auth config", alias="extAuth")
    cors: Optional[CORSConfig] = Field(None, description="CORS config")
    api_key: Optional[APIKeyConfig] = Field(None, description="API key config", alias="apiKey")
    authorization: Optional[AuthorizationConfig] = Field(None, description="Authorization/IP filtering config")

    class Config:
        populate_by_name = True


class SecurityPolicyCreate(BaseModel):
    """Request model for creating a SecurityPolicy."""
    metadata: ObjectMeta = Field(..., description="Policy metadata")
    spec: SecurityPolicySpec = Field(..., description="Policy specification")


class SecurityPolicyUpdate(BaseModel):
    """Request model for updating a SecurityPolicy."""
    spec: SecurityPolicySpec = Field(..., description="Updated policy specification")


class SecurityPolicyResponse(BaseModel):
    """Response model for SecurityPolicy operations."""
    api_version: str = Field(default="gateway.envoyproxy.io/v1alpha1", alias="apiVersion")
    kind: str = Field(default="SecurityPolicy")
    metadata: Dict[str, Any] = Field(..., description="Policy metadata")
    spec: Dict[str, Any] = Field(..., description="Policy specification")
    status: Optional[Dict[str, Any]] = Field(None, description="Policy status")

    class Config:
        populate_by_name = True


# ==================== Simple Policy Creation ====================

class SimpleJWTPolicy(BaseModel):
    """Simplified JWT policy creation."""
    name: str = Field(..., description="Policy name")
    target_route: str = Field(..., description="Target HTTPRoute name", alias="targetRoute")
    issuer: str = Field(..., description="JWT issuer")
    jwks_uri: HttpUrl = Field(..., description="JWKS URI", alias="jwksUri")
    audiences: Optional[List[str]] = Field(None, description="Allowed audiences")
    claim_to_headers: Optional[Dict[str, str]] = Field(
        None, description="Claim to header mapping (claim -> header)", alias="claimToHeaders"
    )

    class Config:
        populate_by_name = True


class SimpleOIDCPolicy(BaseModel):
    """Simplified OIDC policy creation."""
    name: str = Field(..., description="Policy name")
    target_route: str = Field(..., description="Target HTTPRoute name", alias="targetRoute")
    issuer: HttpUrl = Field(..., description="OIDC issuer URL")
    client_id: str = Field(..., description="OIDC client ID", alias="clientId")
    client_secret_name: str = Field(..., description="Secret name containing client secret", alias="clientSecretName")
    scopes: List[str] = Field(default=["openid", "profile", "email"], description="OIDC scopes")
    redirect_url: str = Field(..., description="Redirect URL after auth", alias="redirectUrl")

    class Config:
        populate_by_name = True


class SimpleCORSPolicy(BaseModel):
    """Simplified CORS policy creation."""
    name: str = Field(..., description="Policy name")
    target_route: str = Field(..., description="Target HTTPRoute name", alias="targetRoute")
    allowed_origins: List[str] = Field(
        ...,
        description="Allowed origins — use full URLs (e.g., 'https://example.com') or '*'. Bare domains are auto-prefixed with 'https://'",
        alias="allowedOrigins",
    )
    allowed_methods: List[str] = Field(
        default=["GET", "POST", "PUT", "DELETE", "OPTIONS"],
        description="Allowed methods",
        alias="allowedMethods"
    )
    allowed_headers: List[str] = Field(
        default=["Content-Type", "Authorization"],
        description="Allowed headers",
        alias="allowedHeaders"
    )
    expose_headers: Optional[List[str]] = Field(None, description="Headers to expose", alias="exposeHeaders")
    allow_credentials: bool = Field(default=True, description="Allow credentials", alias="allowCredentials")
    max_age: str = Field(default="24h", description="Max age", alias="maxAge")

    class Config:
        populate_by_name = True


class SimpleAPIKeyPolicy(BaseModel):
    """Simplified API key policy creation."""
    name: str = Field(..., description="Policy name")
    target_route: str = Field(..., description="Target HTTPRoute name", alias="targetRoute")
    header_name: str = Field(default="X-API-Key", description="Header name for API key", alias="headerName")
    api_keys_secret: str = Field(..., description="Secret name containing API keys", alias="apiKeysSecret")

    class Config:
        populate_by_name = True


class SimpleBasicAuthPolicy(BaseModel):
    """Simplified basic auth policy creation."""
    name: str = Field(..., description="Policy name")
    target_route: str = Field(..., description="Target HTTPRoute name", alias="targetRoute")
    users_secret: str = Field(..., description="Secret name containing htpasswd users", alias="usersSecret")

    class Config:
        populate_by_name = True


class SimpleIPAllowlistPolicy(BaseModel):
    """Simplified IP allowlist policy creation."""
    name: str = Field(..., description="Policy name")
    target_route: str = Field(..., description="Target HTTPRoute name", alias="targetRoute")
    allowed_cidrs: List[str] = Field(..., description="Allowed CIDR ranges (e.g., ['192.168.1.0/24', '10.0.0.0/8'])", alias="allowedCidrs")

    class Config:
        populate_by_name = True


class SimpleIPBlocklistPolicy(BaseModel):
    """Simplified IP blocklist policy creation."""
    name: str = Field(..., description="Policy name")
    target_route: str = Field(..., description="Target HTTPRoute name", alias="targetRoute")
    blocked_cidrs: List[str] = Field(..., description="Blocked CIDR ranges (e.g., ['192.168.1.0/24'])", alias="blockedCidrs")

    class Config:
        populate_by_name = True


class SimpleExternalAuthPolicy(BaseModel):
    """Simplified external auth policy creation."""
    name: str = Field(..., description="Policy name")
    target_route: str = Field(..., description="Target HTTPRoute name", alias="targetRoute")
    auth_service_name: str = Field(..., description="Auth service name", alias="authServiceName")
    auth_service_port: int = Field(default=9001, description="Auth service port", alias="authServicePort")
    auth_path: str = Field(default="/auth/verify", description="Auth path", alias="authPath")
    headers_to_auth: List[str] = Field(
        default=["Authorization", "Cookie"],
        description="Headers to forward to auth service",
        alias="headersToAuth"
    )
    failure_mode: ExtAuthFailureMode = Field(default=ExtAuthFailureMode.FAIL_CLOSED, description="Failure mode", alias="failureMode")

    class Config:
        populate_by_name = True
